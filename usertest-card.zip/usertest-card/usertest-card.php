<?php
/**
 * Plugin Name: Site Editor user test
 * Description: A small card of tasks for a tester, over the core WordPress Site Editor. The same seven tasks and the same store as the gogh user test, so the two can be compared.
 * Version: 1.1.0
 * Author: Jamie Marsland
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'UTC_VERSION', '1.1.0' );

function utc_helper_url() {
	return apply_filters( 'utc_helper_url', 'https://gogh-helper.jamesmarsland.workers.dev' );
}

// The seven tasks, word for word the gogh test's; only the hints know
// which editor they are in.
function utc_tasks() {
	$opt = get_option( 'ut_card' );
	if ( is_array( $opt ) && ! empty( $opt['tasks'] ) && is_array( $opt['tasks'] ) ) {
		return apply_filters( 'utc_tasks', $opt['tasks'] );
	}
	$tasks = array(
		array( 'id' => 'name',    'title' => 'Change the site name to your business name.',
			'hint' => 'Press Edit Site at the top. In the Design menu on the left choose Identity, change the Site title, then press Save at the bottom left.' ),
		array( 'id' => 'words',   'title' => 'Change the big headline on the home page so it says what you do.',
			'hint' => 'Go to the home page and press Edit Page at the top. Click the headline, type over it, then press Save at the top right.' ),
		array( 'id' => 'picture', 'title' => 'Swap one photo for a different one.',
			'hint' => 'While editing the page, click a photo. In the toolbar above it press Replace, then upload a picture or choose one from the media library. Save.' ),
		array( 'id' => 'look',    'title' => 'Give the site a different look, colours or fonts, and keep one you like.',
			'hint' => 'Press Edit Site at the top. Choose Styles on the left, pick one of the colour or font sets, then Save.' ),
		array( 'id' => 'contact', 'title' => 'Add a way for visitors to get in touch with you.',
			'hint' => 'While editing a page, press the + at the top left, search for Contact Form 7, add it and choose Contact form 1. Save.' ),
		array( 'id' => 'page',    'title' => 'Add a new page called Prices, put something on it, and make sure visitors can find it.',
			'hint' => 'Press Edit Site at the top, choose Pages on the left, then Add new page. Name it Prices, write something, Save. To put it in the menu, choose Navigation on the left, open the menu and add the page.' ),
		array( 'id' => 'phone',   'title' => 'Check how the site looks on a phone, then publish and look at it the way a visitor would.',
			'hint' => 'While editing, press the screen icon at the top right and choose Mobile. Save, then press the site name at the top left to see the site.' ),
	);
	return apply_filters( 'utc_tasks', $tasks );
}

function utc_enqueue() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	$session = get_option( 'ut_card_session', '' );
	if ( ! preg_match( '/^[a-z0-9]{8,32}$/', (string) $session ) ) {
		$session = strtolower( wp_generate_password( 12, false ) );
		update_option( 'ut_card_session', $session, false );
	}
	$opt = get_option( 'ut_card' );
	wp_enqueue_script( 'utc-card', plugins_url( 'usertest-card.js', __FILE__ ), array(), UTC_VERSION, true );
	wp_localize_script( 'utc-card', 'GOGH_UT', array(
		'session' => $session,
		'helpUrl' => utc_helper_url(),
		'version' => 'wp-' . get_bloginfo( 'version' ),
		'tasks'   => array_values( utc_tasks() ),
		'persona' => is_array( $opt ) && isset( $opt['persona'] ) ? sanitize_text_field( $opt['persona'] ) : 'photographer',
		'suite'   => is_array( $opt ) && isset( $opt['suite'] ) ? sanitize_key( $opt['suite'] ) : 'core',
	) );
}
// the tester walks between the Site Editor, the page editor and the site
// itself; the card is on all three
add_action( 'wp_enqueue_scripts', 'utc_enqueue', 20 );
add_action( 'admin_enqueue_scripts', 'utc_enqueue', 20 );

// Where and how the card sits: bottom left, clear of the editor's Save,
// settings sidebar and toolbar at the top right (James: 'it's covering
// important stuff'), and dark, so it reads as the test's own thing and not a
// piece of the pale site ('too similar to the website'). The editor's
// breadcrumb bar owns the bottom 40px, so the card floats above it.
function utc_card_css() {
	return '<style id="utc-card-css">'
		. '.gogh-ut,.gogh-ut-pill{z-index:2147483000 !important;top:auto !important;right:auto !important;left:16px !important;bottom:60px !important}'
		. '.gogh-ut{background:#16181c !important;color:#f4f1ec !important;border-color:rgba(255,255,255,.14) !important;box-shadow:0 18px 50px rgba(0,0,0,.45) !important;width:300px !important}'
		. '.gogh-ut-head{border-bottom-color:rgba(255,255,255,.12) !important}'
		. '.gogh-ut-lab{color:#eab038 !important}'
		. '.gogh-ut-hide,.gogh-ut-hintbtn,.gogh-ut-p,.gogh-ut-foot,.gogh-ut-q{color:rgba(244,241,236,.72) !important}'
		. '.gogh-ut-hide:hover{background:rgba(255,255,255,.1) !important}'
		. '.gogh-ut-hint{background:rgba(255,255,255,.1) !important;color:#f4f1ec !important}'
		. '.gogh-ut textarea,.gogh-ut input[type=text]{background:rgba(255,255,255,.08) !important;color:#f4f1ec !important;border-color:rgba(255,255,255,.2) !important}'
		. '.gogh-ut textarea::placeholder,.gogh-ut input::placeholder{color:rgba(244,241,236,.5)}'
		. '.gogh-ut-btn{border-color:rgba(255,255,255,.28) !important;color:#f4f1ec !important}'
		. '.gogh-ut-btn.is-primary{background:#eab038 !important;color:#16181c !important;border-color:#eab038 !important}'
		. '.gogh-ut-scale button{border-color:rgba(255,255,255,.28) !important;color:#f4f1ec !important}'
		. '.gogh-ut-scale button.is-on{background:#eab038 !important;color:#16181c !important;border-color:#eab038 !important}'
		. '.gogh-ut-pill{background:#eab038 !important;color:#16181c !important}'
		. '@media (max-width:700px){.gogh-ut{left:12px !important;right:12px !important;bottom:52px !important;width:auto !important}}'
		. '</style>';
}
add_action( 'admin_head', function () { echo utc_card_css(); } );
add_action( 'wp_head', function () { echo utc_card_css(); } );
