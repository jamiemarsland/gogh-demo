<?php
/**
 * Plugin Name: Gogh Abilities (probe)
 * Description: Offers gogh's pages to agents as a WordPress Ability, to see whether Spacefast lists and runs a plugin's own Abilities. One read-only ability for now.
 * Version: 0.1.1
 * Requires at least: 6.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_abilities_api_categories_init', function () {
	wp_register_ability_category( 'gogh', array(
		'label'       => 'Gogh',
		'description' => 'Design and build pages with gogh.',
	) );
} );

add_action( 'wp_abilities_api_init', function () {
	wp_register_ability( 'gogh/page-overview', array(
		'label'               => 'Gogh page overview',
		'description'         => 'Lists the pages built with gogh: id, title, address, status and how many gogh sections each has.',
		'category'            => 'gogh',
		'output_schema'       => array(
			'type'  => 'array',
			'items' => array(
				'type'       => 'object',
				'properties' => array(
					'id'       => array( 'type' => 'integer' ),
					'title'    => array( 'type' => 'string' ),
					'slug'     => array( 'type' => 'string' ),
					'status'   => array( 'type' => 'string' ),
					'link'     => array( 'type' => 'string' ),
					'sections' => array( 'type' => 'integer' ),
				),
			),
		),
		'execute_callback'    => function () {
			$pages = get_posts( array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => 100,
				'orderby'        => 'menu_order title',
				'order'          => 'ASC',
			) );
			$out = array();
			foreach ( $pages as $p ) {
				$n = substr_count( $p->post_content, '<!-- wp:gogh/section' );
				if ( ! $n ) {
					continue;
				}
				$out[] = array(
					'id'       => $p->ID,
					'title'    => get_the_title( $p ),
					'slug'     => $p->post_name,
					'status'   => $p->post_status,
					'link'     => get_permalink( $p ),
					'sections' => $n,
				);
			}
			return $out;
		},
		'permission_callback' => function () {
			return current_user_can( 'edit_pages' );
		},
		'meta'                => array(
			'show_in_rest' => true,
			// not marked readonly: WordPress then demands GET, and `sf zero call` always POSTs
			'annotations'  => array(
				'destructive' => false,
				'idempotent'  => true,
			),
			'mcp'          => array( 'public' => true ),
		),
	) );
} );
