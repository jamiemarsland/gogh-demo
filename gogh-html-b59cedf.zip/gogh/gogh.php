<?php
/**
 * Plugin Name: Gogh Editor
 * Description: A freeform canvas for WordPress — drag anything anywhere on your live page; Gogh publishes it back as clean, responsive core blocks that keep working even if the plugin is deactivated.
 * Version: 0.99.650
 * Author: Jamie Marsland
 * Author URI: https://pootlepress.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Text Domain: gogh-editor
 */

defined( 'ABSPATH' ) || exit;

define( 'GOGH_VERSION', '0.99.650' );

/**
 * gogh/section — a first-class block. STATIC save (no render_callback), so
 * pages keep rendering identically if the plugin is ever deactivated.
 */
add_action( 'init', function () {
	wp_register_script(
		'gogh-block',
		plugins_url( 'gogh-block.js', __FILE__ ),
		array( 'wp-blocks', 'wp-element', 'wp-block-editor' ),
		'0.99.650-chrome',
		true
	);
	register_block_type( 'gogh/section', array(
		'editor_script'   => 'gogh-block',
		// SPIKE (attrs-as-truth): v3 sections store { model, cssT } as block
		// attributes and derive presentation here. Legacy (v2) sections carry
		// no attributes and pass through verbatim — fully static, unchanged.
		'render_callback' => 'gogh_render_section',
	) );
} );

/**
 * explore/html-only: when on, a section's static pieces publish as plain
 * WordPress-flavoured HTML (no block comments) and only live parts stay
 * blocks. Off by default; GOGH_HTML_ONLY or the gogh_html_only option turns
 * it on, so the same pages can be published both ways and compared.
 */
function gogh_html_only() {
	if ( defined( 'GOGH_HTML_ONLY' ) ) {
		return (bool) GOGH_HTML_ONLY;
	}
	return (bool) get_option( 'gogh_html_only', false );
}

/**
 * explore/html-only: the page keeps what it shows; the model lives beside it.
 * The editor still sends whole sections. On save, each section's model and
 * compiled stylesheet move into the post's _gogh_models meta and the block
 * keeps only { v: 4, scope, ref }; the baked <style> stays in the page, so it
 * still renders with the plugin off. Drawing a section, the editor's reads
 * (REST, edit context) and the search-data builders put them back. A first
 * save of a brand-new post keeps them in place (no ID yet to park them on).
 */
function gogh_html_park_models( $data, $postarr ) {
	if ( ! gogh_html_only() || empty( $postarr['ID'] ) || 'revision' === ( $data['post_type'] ?? '' ) ) {
		return $data;
	}
	if ( empty( $data['post_content'] ) || false === strpos( $data['post_content'], 'wp:gogh/section {' ) ) {
		return $data;
	}
	$id      = (int) $postarr['ID'];
	$blocks  = parse_blocks( wp_unslash( $data['post_content'] ) );
	$park    = array();
	$changed = false;
	foreach ( $blocks as &$b ) {
		if ( 'gogh/section' !== ( $b['blockName'] ?? '' ) || empty( $b['attrs']['model'] ) || empty( $b['attrs']['scope'] ) ) {
			continue;
		}
		$scope          = preg_replace( '/[^a-z0-9-]/', '', (string) $b['attrs']['scope'] );
		$park[ $scope ] = array(
			'model' => $b['attrs']['model'],
			'cssT'  => isset( $b['attrs']['cssT'] ) ? (string) $b['attrs']['cssT'] : '',
		);
		$b['attrs']     = array( 'v' => 4, 'scope' => $scope, 'ref' => $id );
		$changed        = true;
	}
	unset( $b );
	if ( ! $changed ) {
		return $data;
	}
	update_post_meta( $id, '_gogh_models', wp_slash( $park ) );
	$blocks               = gogh_html_share_css( gogh_html_promote_h1( $blocks ) );
	$data['post_content'] = wp_slash( serialize_blocks( $blocks ) );
	return $data;
}

/**
 * explore/html-only: one stylesheet per page. Every section bakes the same
 * plumbing (its grid, button and embed basics) under its own scope; a rule
 * every section carries is written once, at the top of the first section's
 * stylesheet, for any section ([data-gogh-scope] keeps the specificity of the
 * scope class it replaces). The rest stays where it was.
 */
/**
 * explore/html-only: the page's first heading candidate (a section's first
 * sized heading, marked gogh-h1 by the editor) becomes its <h1>. Editors read
 * it back as the h2 the editor wrote (gogh_html_unpark_content).
 */
function gogh_html_promote_h1( $blocks ) {
	foreach ( $blocks as $bi => $b ) {
		if ( 'gogh/section' !== ( $b['blockName'] ?? '' ) || empty( $b['innerBlocks'] ) ) {
			continue;
		}
		foreach ( $b['innerBlocks'] as $ii => $ib ) {
			if ( 'core/html' !== ( $ib['blockName'] ?? '' ) || false === strpos( (string) $ib['innerHTML'], 'wp-block-heading gogh-h1 ' ) ) {
				continue;
			}
			$swap = function ( $html ) {
				return preg_replace( '#<h2 class="wp-block-heading gogh-h1 ([^"]*)">(.*?)</h2>#s', '<h1 class="wp-block-heading gogh-h1 $1">$2</h1>', (string) $html, 1 );
			};
			$blocks[ $bi ]['innerBlocks'][ $ii ]['innerHTML'] = $swap( $ib['innerHTML'] );
			foreach ( $ib['innerContent'] as $ci => $chunk ) {
				if ( is_string( $chunk ) ) {
					$blocks[ $bi ]['innerBlocks'][ $ii ]['innerContent'][ $ci ] = $swap( $chunk );
				}
			}
			return $blocks; // one per page
		}
	}
	return $blocks;
}
/**
 * explore/html-only: a page as one standalone HTML file — the bridge to gogh
 * outside WordPress. ?gogh-export=1 on a page (people who can edit it, while
 * the switch is on) renders it as visitors see it, then makes it stand alone:
 * scripts out (search data stays), every stylesheet inlined, fonts embedded,
 * links absolute. &images=1 embeds the site's own pictures too; &download=1
 * hands it over as a file.
 */
add_action( 'template_redirect', function () {
	if ( empty( $_GET['gogh-export'] ) || ! gogh_html_only() || ! is_singular() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	$id = get_queried_object_id();
	if ( ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	add_filter( 'show_admin_bar', '__return_false' );
	$images = ! empty( $_GET['images'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! empty( $_GET['download'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$slug = get_post_field( 'post_name', $id );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( ( $slug ? $slug : 'page' ) . '.html' ) . '"' );
	}
	ob_start( function ( $html ) use ( $images ) {
		return gogh_html_export_page( $html, $images );
	} );
}, 0 );

// a URL on this site → its file on disk (only inside the site's own folders)
function gogh_html_export_path( $url ) {
	$url = strtok( html_entity_decode( (string) $url ), '?#' );
	foreach ( array( content_url() => WP_CONTENT_DIR, includes_url() => ABSPATH . WPINC . '/', site_url( '/' ) => ABSPATH ) as $base => $dir ) {
		$base = untrailingslashit( $base );
		if ( 0 === strpos( $url, $base . '/' ) ) {
			$path = realpath( untrailingslashit( $dir ) . '/' . ltrim( substr( $url, strlen( $base ) ), '/' ) );
			$root = realpath( ABSPATH );
			if ( $path && $root && 0 === strpos( $path, $root ) && is_file( $path ) ) {
				return $path;
			}
			return '';
		}
	}
	return '';
}
function gogh_html_export_data_uri( $url, $remote = false ) {
	$path = gogh_html_export_path( $url );
	if ( '' === $path ) {
		// a picture the page borrows from elsewhere (an Unsplash photo): with
		// everything inside, it is fetched once and carried too
		if ( ! $remote || ! preg_match( '#^https?://#i', (string) $url ) ) {
			return '';
		}
		$r    = wp_safe_remote_get( html_entity_decode( (string) $url ), array( 'timeout' => 15, 'limit_response_size' => 6 * MB_IN_BYTES ) );
		$type = is_wp_error( $r ) ? '' : strtolower( strtok( (string) wp_remote_retrieve_header( $r, 'content-type' ), ';' ) );
		$body = is_wp_error( $r ) ? '' : wp_remote_retrieve_body( $r );
		if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) || 0 !== strpos( $type, 'image/' ) || '' === $body ) {
			return '';
		}
		return 'data:' . $type . ';base64,' . base64_encode( $body );
	}
	$ext   = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	$types = array( 'woff2' => 'font/woff2', 'woff' => 'font/woff', 'ttf' => 'font/ttf', 'otf' => 'font/otf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp', 'avif' => 'image/avif', 'svg' => 'image/svg+xml' );
	if ( ! isset( $types[ $ext ] ) ) {
		return '';
	}
	return 'data:' . $types[ $ext ] . ';base64,' . base64_encode( (string) file_get_contents( $path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
}
function gogh_html_export_page( $html, $images ) {
	$origin = untrailingslashit( home_url() );
	// scripts out; the page's search data (JSON-LD) describes it and stays
	$html = preg_replace( '#<script\b(?![^>]*application/ld\+json)[^>]*>.*?</script>#is', '', $html );
	// the admin's and gogh's own tools never travel
	$html = preg_replace( '#<link\b[^>]*id=["\'](?:admin-bar|dashicons|gogh-editor|gogh-front)[^"\']*["\'][^>]*>#i', '', $html );
	// hints for a live server (preloads, the scripts that are gone) mean nothing in a file
	$html = preg_replace( '#<link\b[^>]*rel=["\'](?:https://api\.w\.org/|EditURI|alternate|preconnect|dns-prefetch|shortlink|wlwmanifest|preload|modulepreload|prefetch)["\'][^>]*>#i', '', $html );
	// every stylesheet of this site inlined, its relative urls made whole
	$html = preg_replace_callback( '#<link\b[^>]*rel=["\']stylesheet["\'][^>]*>#i', function ( $m ) {
		if ( ! preg_match( '#href=["\']([^"\']+)["\']#', $m[0], $h ) ) {
			return $m[0];
		}
		$url  = html_entity_decode( $h[1] );
		$path = gogh_html_export_path( $url );
		if ( '' === $path ) {
			return $m[0]; // another site's stylesheet (a font service) stays linked
		}
		$dir = trailingslashit( dirname( strtok( $url, '?#' ) ) );
		$css = preg_replace_callback( '#url\((["\']?)(?!data:|https?:|/|\#)([^)"\']+)\1\)#i', function ( $u ) use ( $dir ) {
			return 'url(' . $u[1] . $dir . $u[2] . $u[1] . ')';
		}, (string) file_get_contents( $path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return '<style>' . str_replace( '</style', '<\/style', $css ) . '</style>';
	}, $html );
	// fonts this page uses travel inside it; faces it never names are dropped
	$used = array();
	if ( preg_match_all( '#font-family\s*:\s*([^;}]+)#i', preg_replace( '#@font-face\s*\{[^}]*\}#i', '', $html ), $fm ) ) {
		foreach ( $fm[1] as $decl ) {
			foreach ( explode( ',', $decl ) as $name ) {
				$used[ strtolower( trim( $name, " \t\n\r\"'" ) ) ] = true;
			}
		}
	}
	$vars = array();
	if ( preg_match_all( '#--wp--preset--font-family--([a-z0-9-]+)\s*:\s*([^;}]+)#i', $html, $vm ) ) {
		foreach ( $vm[1] as $k => $slug ) {
			$vars[ $slug ] = $vm[2][ $k ];
		}
	}
	foreach ( $vars as $slug => $stack ) {
		if ( false !== strpos( $html, 'var(--wp--preset--font-family--' . $slug . ')' ) ) {
			foreach ( explode( ',', $stack ) as $name ) {
				$used[ strtolower( trim( $name, " \t\n\r\"'" ) ) ] = true;
			}
		}
	}
	$html = preg_replace_callback( '#@font-face\s*\{[^}]*\}#i', function ( $f ) use ( $used ) {
		if ( preg_match( '#font-family\s*:\s*["\']?([^;"\']+)#i', $f[0], $n ) && empty( $used[ strtolower( trim( $n[1] ) ) ] ) ) {
			return '';
		}
		return preg_replace_callback( '#url\((["\']?)([^)"\']+\.(?:woff2?|ttf|otf))\1\)#i', function ( $u ) {
			$d = gogh_html_export_data_uri( $u[2] );
			return $d ? 'url(' . $d . ')' : $u[0];
		}, $f[0] );
	}, $html );
	// &images=1: this site's own pictures inside the file (another site's stay linked)
	if ( $images ) {
		$html = preg_replace( '#\s(?:srcset|sizes)=(["\'])[^"\']*\1#i', '', $html );
		$html = preg_replace_callback( '#<(img|video)\b[^>]*>#i', function ( $tag ) {
			return preg_replace_callback( '#\b(src|poster)=(["\'])([^"\']+)\2#i', function ( $m ) {
				$d = gogh_html_export_data_uri( $m[3], true );
				return $d ? $m[1] . '=' . $m[2] . $d . $m[2] : $m[0];
			}, $tag[0] );
		}, $html );
		// pictures named in stylesheets (a section's background photo)
		$html = preg_replace_callback( '#url\((["\']?)((?:https?:)?//[^)"\']+|' . preg_quote( content_url(), '#' ) . '[^)"\']+)\1\)#i', function ( $u ) {
			if ( preg_match( '#\.(woff2?|ttf|otf)(\?|$)#i', $u[2] ) ) {
				return $u[0];
			}
			$d = gogh_html_export_data_uri( $u[2], true );
			return $d ? 'url(' . $d . ')' : $u[0];
		}, $html );
	}
	// links that start at the site's root work from a file too
	$html = preg_replace( '#\b(href|src|action|poster)=(["\'])/(?!/)#i', '$1=$2' . $origin . '/', $html );
	return preg_replace( '#<head>#i', "<head>\n<!-- A standalone copy of " . esc_url( $origin ) . ", saved by gogh. -->", $html, 1 );
}
/**
 * explore/html-only: the whole site as a folder a static host can serve.
 * Every page, post, posts page and category archive is fetched as a signed-
 * out visitor sees it, then: scripts out (search data stays), WordPress's
 * query links (?name=…, ?page_id=…) become real addresses, every file the
 * page uses (pictures, fonts, stylesheets and what they point at) is copied
 * to the same path, borrowed pictures are downloaded into /media/, and the
 * site's address becomes $target. Each address is written as
 * <path>/index.html; the feed as /feed.xml. Returns a receipt.
 */
function gogh_html_export_site( $dir, $target, $spacefast = false ) {
	$dir    = untrailingslashit( $dir );
	$origin = untrailingslashit( home_url() );
	$target = untrailingslashit( $target );
	$urls   = array( home_url( '/' ) );
	foreach ( get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids' ) ) as $pid ) {
		$urls[] = get_permalink( $pid );
	}
	foreach ( get_categories( array( 'hide_empty' => true ) ) as $cat ) {
		$urls[] = get_category_link( $cat );
	}
	foreach ( get_users( array( 'has_published_posts' => array( 'post' ), 'fields' => 'ID' ) ) as $uid ) {
		$urls[] = get_author_posts_url( (int) $uid );
	}
	$urls   = array_values( array_unique( $urls ) );
	$copy   = array(); // site path => true
	$media  = array(); // borrowed url => local path
	$pages  = 0;
	$forms  = 0;
	$failed = array();
	// fetched as the static copy (gogh-static=1): a file can't take comments,
	// so the pages are drawn with comments closed
	$fetch  = function ( $url ) {
		$r = wp_remote_get( add_query_arg( 'gogh-static', '1', $url ), array( 'timeout' => 30, 'redirection' => 3, 'cookies' => array() ) );
		$h = ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) ? null : wp_remote_retrieve_body( $r );
		return null === $h ? null : preg_replace( '#([?&])gogh-static=1(&amp;|&|\#038;)?#', '$1', $h );
	};
	foreach ( $urls as $url ) {
		$html = $fetch( $url );
		if ( null === $html ) {
			$failed[] = $url;
			continue;
		}
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$rel  = '/' . ( '' === $path ? '' : $path . '/' );
		// on Spacefast a gogh form posts to the site's own /api/message, and the
		// page's thank-you state (WordPress draws it at ?gogh-thanks=1) is a page too
		$has_form = $spacefast && false !== strpos( $html, 'value="gogh_form_message"' );
		$html     = gogh_html_export_rewrite( $html, $origin, $target, $copy, $media, $dir );
		if ( $has_form ) {
			$html   = gogh_html_export_form( $html, $rel );
			$thanks = $fetch( add_query_arg( 'gogh-thanks', '1', $url ) );
			if ( null !== $thanks ) {
				$thanks = gogh_html_export_form( gogh_html_export_rewrite( $thanks, $origin, $target, $copy, $media, $dir ), $rel );
				wp_mkdir_p( $dir . $rel . 'thanks' );
				file_put_contents( $dir . $rel . 'thanks/index.html', $thanks ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_put_contents_file_put_contents
			}
			$forms++;
		}
		$file = $dir . $rel . 'index.html';
		wp_mkdir_p( dirname( $file ) );
		file_put_contents( $file, $html ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_put_contents_file_put_contents
		$pages++;
	}
	// the feed, for readers: one file at the root
	$feed = $fetch( home_url( '/feed/' ) );
	if ( null !== $feed ) {
		$feed = preg_replace( '#\s*<(wfw:commentRss|comments|slash:comments)>.*?</\1>#s', '', $feed );
		file_put_contents( $dir . '/feed.xml', str_replace( array( $origin . '/feed/', $origin ), array( $target . '/feed.xml', $target ), $feed ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_put_contents_file_put_contents
	}
	// browsers ask every site for /favicon.ico: the site icon, or WordPress's own
	$icon = get_site_icon_url( 64 );
	$icon = $icon ? gogh_html_export_path( $icon ) : '';
	if ( '' === $icon ) {
		$icon = ABSPATH . WPINC . '/images/w-logo-blue-white-bg.png';
	}
	if ( is_file( $icon ) ) {
		copy( $icon, $dir . '/favicon.ico' );
	}
	// every file the pages use, and the files their stylesheets point at
	$done  = array();
	$queue = array_keys( $copy );
	while ( $queue ) {
		$p = array_shift( $queue );
		if ( isset( $done[ $p ] ) ) {
			continue;
		}
		$done[ $p ] = true;
		$src        = gogh_html_export_path( $origin . $p );
		if ( '' === $src ) {
			continue;
		}
		wp_mkdir_p( dirname( $dir . $p ) );
		copy( $src, $dir . $p );
		if ( preg_match( '#\.css$#i', $p ) ) {
			preg_match_all( '#url\((["\']?)(?!data:|https?:|/|\#)([^)"\'?\#]+)#i', (string) file_get_contents( $src ), $um ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			foreach ( $um[2] as $rel ) {
				$queue[] = gogh_html_export_join( dirname( $p ) . '/', $rel );
			}
		}
	}
	$bytes = 0;
	$files = 0;
	foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) ) as $f ) {
		if ( false === strpos( $f->getPathname(), '/.spacefast' ) ) {
			$bytes += $f->getSize();
			$files++;
		}
	}
	if ( $spacefast && $forms ) {
		gogh_html_export_spacefast_runtime( $dir );
	}
	return array( 'pages' => $pages, 'forms' => $forms, 'files' => $files, 'bytes' => $bytes, 'borrowed' => count( $media ), 'failed' => $failed );
}

// a gogh form on a static Spacefast site: posts to /api/message, no WordPress fields
function gogh_html_export_form( $html, $rel ) {
	return preg_replace_callback( '#<form method="post" action="[^"]*admin-post\.php">(.*?)</form>#s', function ( $m ) use ( $rel ) {
		$inner = preg_replace( '#<input type="hidden"[^>]*name="(?:action|_gogh_form|_wp_http_referer|fm_page)"[^>]*/>#', '', $m[1] );
		return '<form method="post" action="/api/message"><input type="hidden" name="fm_back" value="' . esc_attr( $rel ) . '" />' . $inner . '</form>';
	}, $html );
}

// the Spacefast side of the form: a worker that keeps messages in the site's
// own database, and a page that lists them (keep /messages/ team-only)
function gogh_html_export_spacefast_runtime( $dir ) {
	wp_mkdir_p( $dir . '/functions/api' );
	wp_mkdir_p( $dir . '/functions/messages' );
	$files = array(
		'/sf.jsonc'                     => '{ "$schema": "https://spacefast.com/schemas/sf.json", "runtime": { "kind": "functions", "compatibilityDate": "2026-07-01" } }' . "\n",
		'/functions/_messages.ts'       => <<<'TS'
// gogh's contact form on a static site: messages live in the space's own database
export async function ensure(db: any) {
  await db.prepare("CREATE TABLE IF NOT EXISTS gogh_messages (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200), email VARCHAR(200), message TEXT, page VARCHAR(255), at VARCHAR(40))").run();
}
export function esc(s: unknown) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] as string));
}
TS
		,
		'/functions/api/message.ts'     => <<<'TS'
import { ensure } from "../_messages";
export async function POST(req: Request, context: { env: any }) {
  const form = await req.formData();
  const back = String(form.get("fm_back") || "/");
  const safe = /^\/[a-z0-9\/_-]*$/i.test(back) && !back.startsWith("//") ? back : "/";
  const go = (path: string) => new Response(null, { status: 303, headers: { location: path } });
  // the same honeypot WordPress checks: a person never fills it
  if (String(form.get("fm_website") || "")) return go(safe + "thanks/#gogh-form");
  const name = String(form.get("fm_name") || "").trim().slice(0, 200);
  const email = String(form.get("fm_email") || "").trim().slice(0, 200);
  const message = String(form.get("fm_message") || "").trim().slice(0, 5000);
  if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !message) return go(safe + "#gogh-form");
  const db = context.env.DB;
  await ensure(db);
  await db.prepare("INSERT INTO gogh_messages (name, email, message, page, at) VALUES (?, ?, ?, ?, ?)").bind(name, email, message, safe, new Date().toISOString()).run();
  return go(safe + "thanks/#gogh-form");
}
TS
		,
		'/functions/messages/index.ts' => <<<'TS'
import { ensure, esc } from "../_messages";
export async function GET(_req: Request, context: { env: any }) {
  const db = context.env.DB;
  await ensure(db);
  const rows = ((await db.prepare("SELECT name, email, message, page, at FROM gogh_messages ORDER BY id DESC LIMIT 200").all()).results || []) as any[];
  const list = rows.map((r) => `<article><h2>${esc(r.name)} <a href="mailto:${esc(r.email)}">${esc(r.email)}</a></h2><p>${esc(r.message).replace(/\n/g, "<br>")}</p><small>${esc(r.at)} · from ${esc(r.page)}</small></article>`).join("");
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Messages</title>
<style>body{margin:0;background:#f6f5f1;color:#1d1d1b;font:16px/1.5 system-ui,sans-serif}main{max-width:720px;margin:0 auto;padding:56px 20px}h1{font-size:32px;margin:0 0 24px}article{background:#fff;border:1px solid #e4e2dc;border-radius:12px;padding:18px 20px;margin:0 0 14px}h2{font-size:16px;margin:0 0 8px}h2 a{font-weight:400;color:#6a6f74;margin-left:6px}p{margin:0 0 10px}small{color:#6a6f74}</style></head>
<body><main><h1>Messages</h1>${list || "<p>No messages yet.</p>"}</main></body></html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}
TS
		,
	);
	foreach ( $files as $rel => $code ) {
		file_put_contents( $dir . $rel, $code ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_put_contents_file_put_contents
	}
}
add_action( 'init', function () {
	if ( isset( $_GET['gogh-static'] ) && gogh_html_only() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation only
		add_filter( 'comments_open', '__return_false' );
		add_filter( 'pings_open', '__return_false' );
		// the page's own content between two markers, so a host that edits
		// the page later (gogh on Spacefast) can swap new content into the shell
		add_filter( 'the_content', function ( $c ) {
			return in_the_loop() && is_singular() && get_queried_object_id() === get_the_ID() ? '<!--gogh:content-->' . $c . '<!--/gogh:content-->' : $c;
		}, PHP_INT_MAX );
	}
} );

// A host that serves files in front of WordPress and never lets it draw a
// page (Spacefast) asks gogh for a page instead: GET gogh/v1/page-html?path=
// draws that address the way a visit would, theme and all, and hands back the
// HTML. Visitors get the public page; a signed-in editor (WordPress's own
// login cookie) gets it as they would see it, gogh's editor included.
add_action( 'rest_api_init', function () {
	register_rest_route( 'gogh/v1', '/page-html', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => array(
			'path' => array( 'type' => 'string', 'required' => true ),
		),
		'callback'            => function ( $req ) {
			$path = '/' . ltrim( (string) $req->get_param( 'path' ), '/' );
			if ( preg_match( '#^//|[\s<>"]#', $path ) || 0 === strpos( $path, '/wp-json' ) || 0 === strpos( $path, '/wp-admin' ) ) {
				return new WP_Error( 'gogh_page_path', 'Not a page address.', array( 'status' => 400 ) );
			}
			return gogh_draw_address( $path );
		},
	) );
} );
// building a site from a definition: an admin, or on a managed host (where the
// person signed in may change the site's look and pages but not its settings)
// whoever may do both of those (explore branch: Spacefast's "Spacefast user")
function gogh_can_build_site() {
	return current_user_can( 'manage_options' ) || ( current_user_can( 'edit_theme_options' ) && current_user_can( 'edit_pages' ) );
}
// the same drawing as a page to open in a browser, its links and addresses
// pointed at whichever host it was opened on (a managed host's WordPress can
// live on a host of its own, where the editor's login cookie is)
add_action( 'rest_api_init', function () {
	register_rest_route( 'gogh/v1', '/canvas', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => array(
			'path' => array( 'type' => 'string', 'default' => '/' ),
		),
		'callback'            => function ( $req ) {
			$path = '/' . ltrim( (string) $req->get_param( 'path' ), '/' );
			if ( preg_match( '#^//|[\s<>"]#', $path ) || 0 === strpos( $path, '/wp-json' ) || 0 === strpos( $path, '/wp-admin' ) ) {
				return new WP_Error( 'gogh_page_path', 'Not a page address.', array( 'status' => 400 ) );
			}
			$r    = gogh_draw_address( $path );
			$html = $r['html'];
			$home = untrailingslashit( home_url() );
			$here = ( is_ssl() ? 'https://' : 'http://' ) . sanitize_text_field( wp_unslash( isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : '' ) );
			if ( $here && wp_parse_url( $home, PHP_URL_HOST ) !== wp_parse_url( $here, PHP_URL_HOST ) ) {
				$html = str_replace( array( $home, str_replace( '/', '\\/', $home ) ), array( $here, str_replace( '/', '\\/', $here ) ), $html );
			}
			$status = $r['status'];
			add_filter( 'rest_pre_serve_request', function () use ( $html, $status ) {
				status_header( $status );
				header( 'Content-Type: text/html; charset=utf-8' );
				header( 'Cache-Control: no-store' );
				echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a whole page WordPress just drew
				return true;
			} );
			return null;
		},
	) );
} );
function gogh_draw_address( $uri ) {
	global $wp, $wp_query, $wp_the_query;
	// REST signs a cookie visitor out unless a nonce came along; a page view
	// carries no nonce, so the login cookie itself says who is looking
	if ( ! get_current_user_id() && defined( 'LOGGED_IN_COOKIE' ) && ! empty( $_COOKIE[ LOGGED_IN_COOKIE ] ) ) {
		$uid = wp_validate_auth_cookie( wp_unslash( $_COOKIE[ LOGGED_IN_COOKIE ] ), 'logged_in' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated by WordPress
		if ( $uid ) {
			wp_set_current_user( $uid );
		}
	}
	// the visit, as WordPress would parse and query it
	$parts = wp_parse_url( $uri );
	$query = array();
	if ( ! empty( $parts['query'] ) ) {
		wp_parse_str( $parts['query'], $query );
	}
	$_SERVER['REQUEST_URI'] = $uri;
	$_SERVER['PHP_SELF']    = '/index.php';
	$_SERVER['PATH_INFO']   = isset( $parts['path'] ) ? $parts['path'] : '/';
	$_SERVER['QUERY_STRING'] = isset( $parts['query'] ) ? $parts['query'] : '';
	$_GET                   = $query; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the drawn address's own query
	$_REQUEST               = $query;
	$wp_query               = new WP_Query(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- a fresh main query for the drawn address
	$wp_the_query           = $wp_query; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	$wp->query_vars         = array();
	$wp->query_string       = '';
	$wp->request            = '';
	$wp->matched_rule       = null;
	$wp->matched_query      = '';
	$wp->parse_request();
	// WordPress never treats a REST request's main query as the home page,
	// so the site's own front page is named outright
	if ( ! array_filter( $wp->query_vars ) && 'page' === get_option( 'show_on_front' ) && get_option( 'page_on_front' ) ) {
		$wp->query_vars = array( 'page_id' => (int) get_option( 'page_on_front' ) );
	}
	$wp->query_posts();
	$wp->handle_404();
	$wp->register_globals();
	// nothing may send this request elsewhere: it is a drawing, not a visit
	remove_action( 'template_redirect', 'redirect_canonical' );
	remove_action( 'template_redirect', 'wp_old_slug_redirect' );
	remove_action( 'template_redirect', 'wp_redirect_admin_locations', 1000 );
	add_filter( 'wp_redirect', '__return_false', PHP_INT_MAX );
	// some hosts answer REST without passing through index.php, which is
	// where WordPress turns its theme on
	add_filter( 'wp_using_themes', '__return_true' );
	$drawn_with = '';
	add_filter( 'template_include', function ( $t ) use ( &$drawn_with ) {
		$drawn_with = basename( (string) $t );
		return $t;
	}, PHP_INT_MAX );
	ob_start();
	include ABSPATH . WPINC . '/template-loader.php';
	$html = ob_get_clean();
	return array(
		'status' => is_404() ? 404 : 200,
		'title'  => wp_get_document_title(),
		'drawn'  => $drawn_with,
		'html'   => $html,
	);
}

function gogh_html_export_join( $base, $rel ) {
	$parts = array();
	foreach ( explode( '/', $base . $rel ) as $seg ) {
		if ( '..' === $seg ) {
			array_pop( $parts );
		} elseif ( '.' !== $seg && '' !== $seg ) {
			$parts[] = $seg;
		}
	}
	return '/' . implode( '/', $parts );
}
function gogh_html_export_rewrite( $html, $origin, $target, &$copy, &$media, $dir ) {
	$html = preg_replace( '#<script\b(?![^>]*application/ld\+json)[^>]*>.*?</script>#is', '', $html );
	$html = preg_replace( '#<link\b[^>]*rel=["\'](?:https://api\.w\.org/|EditURI|alternate|preconnect|dns-prefetch|shortlink|wlwmanifest|preload|modulepreload|prefetch)["\'][^>]*>#i', '', $html );
	// WordPress's own addresses (?name=…, ?page_id=…, ?p=…) mean nothing to a
	// static host: they become the permalink they stand for
	$o    = preg_quote( $origin, '#' );
	// (read the query itself: url_to_postid takes '/?name=…' for the front page)
	$html = preg_replace_callback( '#(href=["\'])(' . $o . ')?/\?((?:name|page_id|p|pagename)=[^"\'\#]+)#i', function ( $m ) {
		parse_str( html_entity_decode( $m[3] ), $q );
		$id = 0;
		if ( ! empty( $q['p'] ) || ! empty( $q['page_id'] ) ) {
			$id = (int) ( ! empty( $q['p'] ) ? $q['p'] : $q['page_id'] );
		} elseif ( ! empty( $q['name'] ) || ! empty( $q['pagename'] ) ) {
			$hit = get_posts( array( 'name' => sanitize_title( ! empty( $q['name'] ) ? $q['name'] : $q['pagename'] ), 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids' ) );
			$id  = $hit ? (int) $hit[0] : 0;
		}
		return ( $id && 'publish' === get_post_status( $id ) ) ? $m[1] . get_permalink( $id ) : $m[0];
	}, $html );
	// the front page also answers at its own slug (/home/); the static site has it at /
	$front = (int) get_option( 'page_on_front' );
	if ( $front && 'page' === get_option( 'show_on_front' ) ) {
		$uri = get_page_uri( $front );
		if ( $uri ) {
			$html = str_replace( $origin . '/' . $uri . '/', $origin . '/', $html );
		}
	}
	// borrowed pictures come home to /media/
	$html = preg_replace_callback( '#https://images\.unsplash\.com/[^"\'\s)<>]+#i', function ( $m ) use ( &$media, $dir, $target ) {
		$url = html_entity_decode( $m[0] );
		if ( ! isset( $media[ $url ] ) ) {
			$name = '/media/' . substr( md5( $url ), 0, 12 ) . '.jpg';
			$r    = wp_safe_remote_get( $url, array( 'timeout' => 20 ) );
			if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
				return $m[0];
			}
			wp_mkdir_p( $dir . '/media' );
			file_put_contents( $dir . $name, wp_remote_retrieve_body( $r ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_put_contents_file_put_contents
			$media[ $url ] = $name;
		}
		return $target . $media[ $url ];
	}, $html );
	// every file of this site the page names is copied to the same path
	if ( preg_match_all( '#' . $o . '(/(?:wp-content|wp-includes)/[^"\'\s)<>?\#,]+)#', $html, $fm ) ) {
		foreach ( $fm[1] as $p ) {
			$copy[ html_entity_decode( $p ) ] = true;
		}
	}
	// the feed is one file now (written whole, or from the site's root)
	$html = str_replace( array( $origin . '/feed/', '="/feed/"' ), array( $target . '/feed.xml', '="/feed.xml"' ), $html );
	// and the site has its new address (JSON in the search data writes \/)
	return str_replace( array( $origin, str_replace( '/', '\/', $origin ) ), array( $target, str_replace( '/', '\/', $target ) ), $html );
}

add_action( 'admin_bar_menu', function ( $bar ) {
	if ( is_admin() || ! gogh_html_only() || ! is_singular() || ! current_user_can( 'edit_post', get_queried_object_id() ) ) {
		return;
	}
	$bar->add_node( array(
		'id'    => 'gogh-export-html',
		'title' => 'Download as HTML',
		'href'  => add_query_arg( array( 'gogh-export' => 1, 'download' => 1 ), get_permalink( get_queried_object_id() ) ),
	) );
}, 90 );

function gogh_html_css_rules( $css ) {
	$out   = array();
	$depth = 0;
	$start = 0;
	$len   = strlen( $css );
	for ( $i = 0; $i < $len; $i++ ) {
		if ( '{' === $css[ $i ] ) {
			$depth++;
		} elseif ( '}' === $css[ $i ] ) {
			$depth--;
			if ( 0 === $depth ) {
				$r = trim( substr( $css, $start, $i + 1 - $start ) );
				if ( '' !== $r ) {
					$out[] = $r;
				}
				$start = $i + 1;
			}
		}
	}
	return $out;
}
function gogh_html_share_css( $blocks ) {
	$sentinel = '/* generated by gogh */';
	$found    = array(); // block index => [ scope, rules ]
	foreach ( $blocks as $bi => $b ) {
		if ( 'gogh/section' !== ( $b['blockName'] ?? '' ) || empty( $b['attrs']['scope'] ) || ! is_string( $b['innerContent'][0] ?? null ) ) {
			continue;
		}
		if ( ! preg_match( '#<style class="gogh-style">(.*?)</style>#s', $b['innerContent'][0], $m ) ) {
			continue;
		}
		$scope         = (string) $b['attrs']['scope'];
		$css           = trim( str_replace( $sentinel, '', $m[1] ) );
		$found[ $bi ]  = array( $scope, gogh_html_css_rules( $css ) );
	}
	if ( ! $found ) {
		return $blocks;
	}
	// WordPress loads core/button's stylesheet only when it renders that
	// block, and a button here is plain HTML: without these rules a button
	// lost its pill and its centred label (with gogh on or off). Only the
	// rules a gogh button uses, carried by the page that has buttons.
	$core = '';
	foreach ( $found as $bi => $f ) {
		// the HTML, not the stylesheet riding in it (which names the class anyway)
		if ( preg_match( '#class="[^"]*\bwp-block-button__link\b#', (string) preg_replace( '#<style\b.*?</style>#s', '', serialize_block( $blocks[ $bi ] ) ) ) ) {
			$core = '.wp-block-button__link{align-content:center;box-sizing:border-box;cursor:pointer;display:inline-block;height:100%;text-align:center;word-break:break-word} :where(.wp-block-button__link){border-radius:9999px;box-shadow:none;padding:calc(.667em + 2px) calc(1.333em + 2px);text-decoration:none} .wp-block-buttons{box-sizing:border-box} .wp-block-buttons>.wp-block-button{display:inline-block;margin:0} ';
			break;
		}
	}
	// gogh-sec-1 must not match inside gogh-sec-10
	$norm  = function ( $rule, $scope ) {
		return preg_replace( '/' . preg_quote( $scope, '/' ) . '(?![0-9])/', 'GOGHSCOPE', $rule );
	};
	$sets = array();
	foreach ( $found as $f ) {
		$sets[] = array_unique( array_map( function ( $r ) use ( $f, $norm ) { return $norm( $r, $f[0] ); }, $f[1] ) );
	}
	$shared = count( $sets ) > 1 ? call_user_func_array( 'array_intersect', $sets ) : array();
	if ( ! $shared && '' === $core ) {
		return $blocks;
	}
	$shared_css = $core;
	foreach ( $shared as $r ) {
		$r           = str_replace( array( '.gogh-section.GOGHSCOPE', '.GOGHSCOPE' ), array( '.gogh-section[data-gogh-scope]', '[data-gogh-scope]' ), $r );
		$shared_css .= $r . ' ';
	}
	$first = true;
	foreach ( $found as $bi => $f ) {
		$own = array();
		foreach ( $f[1] as $r ) {
			if ( ! in_array( $norm( $r, $f[0] ), $shared, true ) ) {
				$own[] = $r;
			}
		}
		$css   = $sentinel . ' ' . ( $first ? $shared_css : '' ) . implode( ' ', $own );
		$first = false;
		// '<' alone could close the tag; '>' is CSS's child combinator and stays
		$tag   = '<style class="gogh-style">' . str_replace( '<', '', $css ) . '</style>';
		foreach ( array( 'innerHTML' ) as $k ) {
			$blocks[ $bi ][ $k ] = preg_replace_callback( '#<style class="gogh-style">.*?</style>#s', function () use ( $tag ) { return $tag; }, $blocks[ $bi ][ $k ], 1 );
		}
		$blocks[ $bi ]['innerContent'][0] = preg_replace_callback( '#<style class="gogh-style">.*?</style>#s', function () use ( $tag ) { return $tag; }, $blocks[ $bi ]['innerContent'][0], 1 );
	}
	return $blocks;
}
add_filter( 'wp_insert_post_data', 'gogh_html_park_models', 30, 2 );

function gogh_html_unpark_attrs( $attrs ) {
	if ( empty( $attrs['ref'] ) || empty( $attrs['scope'] ) || ! empty( $attrs['model'] ) ) {
		return $attrs;
	}
	$m = get_post_meta( (int) $attrs['ref'], '_gogh_models', true );
	$s = (string) $attrs['scope'];
	if ( is_array( $m ) && isset( $m[ $s ]['model'] ) ) {
		$attrs = array(
			'v'     => 4, // a parked section is an HTML-only one: a <section>
			'scope' => $s,
			'model' => $m[ $s ]['model'],
			'cssT'  => isset( $m[ $s ]['cssT'] ) ? (string) $m[ $s ]['cssT'] : '',
		);
	}
	return $attrs;
}
function gogh_html_unpark_content( $content ) {
	if ( false === strpos( (string) $content, 'wp:gogh/section {"v":4' ) ) {
		return $content;
	}
	$blocks = parse_blocks( $content );
	foreach ( $blocks as &$b ) {
		if ( 'gogh/section' === ( $b['blockName'] ?? '' ) && ! empty( $b['attrs']['ref'] ) ) {
			$b['attrs'] = gogh_html_unpark_attrs( $b['attrs'] );
			// an editor wants each section whole: its own full stylesheet back
			// in place of the page's shared one (the block's save() writes it so)
			// exactly what the block's save() writes (cssT with its scope), so the
			// block editor matches it; '<' is the only character that could
			// close the tag, and gogh's stylesheets never contain one
			$css = isset( $b['attrs']['cssT'] ) ? str_replace( array( 'GOGHSCOPE', '<' ), array( preg_replace( '/[^a-z0-9-]/', '', (string) $b['attrs']['scope'] ), '' ), (string) $b['attrs']['cssT'] ) : '';
			if ( '' !== $css && is_string( $b['innerContent'][0] ?? null ) ) {
				$tag                  = '<style class="gogh-style">' . $css . '</style>';
				$b['innerHTML']       = preg_replace_callback( '#<style class="gogh-style">.*?</style>#s', function () use ( $tag ) { return $tag; }, $b['innerHTML'], 1 );
				$b['innerContent'][0] = preg_replace_callback( '#<style class="gogh-style">.*?</style>#s', function () use ( $tag ) { return $tag; }, $b['innerContent'][0], 1 );
			}
		}
	}
	unset( $b );
	// the <h1> the server promoted goes back to the h2 the editor wrote
	return preg_replace( '#<h1 class="wp-block-heading gogh-h1 ([^"]*)">(.*?)</h1>#s', '<h2 class="wp-block-heading gogh-h1 $1">$2</h2>', serialize_blocks( $blocks ) );
}
add_filter( 'render_block_data', function ( $block ) {
	if ( 'gogh/section' === ( $block['blockName'] ?? '' ) && ! empty( $block['attrs']['ref'] ) ) {
		$block['attrs'] = gogh_html_unpark_attrs( $block['attrs'] );
	}
	return $block;
} );
foreach ( array( 'page', 'post', 'wp_template_part', 'wp_template', 'wp_block' ) as $gogh_rest_type ) {
	add_filter( 'rest_prepare_' . $gogh_rest_type, function ( $response, $post, $request ) {
		if ( 'edit' === $request['context'] && isset( $response->data['content']['raw'] ) ) {
			$response->data['content']['raw'] = gogh_html_unpark_content( $response->data['content']['raw'] );
		}
		return $response;
	}, 10, 3 );
}

/**
 * SPIKE: emit a v3 section. PHP does scoping + emission ONLY — the layout
 * engine stays in the editor; cssT arrives fully compiled with a GOGHSCOPE
 * placeholder.
 *
 * SECURITY: block attributes are writable by users WITHOUT unfiltered_html
 * (KSES does not police attribute JSON), so everything emitted from them is
 * sanitized here: the scope is slug-cast and the CSS may not contain the
 * characters that could open an element or comment. Without this, cssT would
 * be a stored-XSS bypass around KSES.
 */
function gogh_css_from_attrs( $attrs ) {
	if ( empty( $attrs['cssT'] ) || empty( $attrs['scope'] ) ) {
		return '';
	}
	$scope = preg_replace( '/[^a-z0-9-]/', '', (string) $attrs['scope'] );
	if ( '' === $scope ) {
		return '';
	}
	$css = str_replace( 'GOGHSCOPE', $scope, (string) $attrs['cssT'] );
	// CSS never needs these characters; their absence makes markup injection impossible
	return str_replace( array( '<', '>', '\\' ), '', $css );
}

/**
 * When KSES strips a baked <style> TAG it leaves the CSS behind as loose
 * text. Our stylesheets all open with a sentinel comment and never contain
 * '<', so the residue is precisely delimited and safe to sweep.
 */
function gogh_sweep_css_residue( $html ) {
	return preg_replace( '/\/\* generated by gogh \*\/[^<]*/', '', $html );
}

// the Store API (mini-cart, cart, checkout) hands product descriptions to
// an HTML formatter that drops <style> and <script> TAGS and keeps their
// words — '/* generated by gogh */ .gogh-wrap {…' read as prose in James's
// mini-cart. Over the Store API a section renders as plain content.
function gogh_is_store_api() {
	if ( ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return false;
	}
	$route = '';
	if ( isset( $GLOBALS['wp'] ) && isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
		$route = (string) $GLOBALS['wp']->query_vars['rest_route'];
	}
	if ( '' === $route && isset( $_SERVER['REQUEST_URI'] ) ) {
		$route = (string) $_SERVER['REQUEST_URI'];
	}
	return false !== strpos( $route, 'wc/store' );
}
function gogh_render_section( $attrs, $content ) {
	$attrs = is_array( $attrs ) ? $attrs : array();
	if ( function_exists( 'gogh_in_collection' ) && gogh_in_collection() ) {
		return ''; // a product grid never carries a product's page
	}
	if ( gogh_is_store_api() ) {
		$plain = preg_replace( '#<(style|script)\b[^>]*>.*?</\1>#is', '', (string) $content );
		return gogh_sweep_css_residue( $plain );
	}
	$css   = gogh_css_from_attrs( $attrs );
	if ( '' === $css ) {
		return $content; // legacy v2: static markup is already complete
	}
	if ( false === strpos( $content, 'class="gogh-style"' ) ) {
		$content = gogh_sweep_css_residue( $content );
		$style   = '<style class="gogh-style">' . $css . '</style>';
		$out     = preg_replace( '/(<div class="wp-block-gogh-section[^"]*">)/', '$1' . $style, $content, 1, $n );
		$content = $n ? $out : $style . $content;
	}
	return gogh_inject_embeds( $attrs, gogh_inject_experiences( $attrs, gogh_faq_schema( $attrs ) . $content ) );
}

/**
 * A map link stored as a plain anchor becomes a frame at render time — the
 * same contract as experiences: the saved markup is kses-safe and works with
 * the plugin off (a link), the plugin draws the window.
 */
function gogh_map_embed_url( $url ) {
	$u = trim( (string) $url );
	if ( '' === $u ) {
		return '';
	}
	// a short link resolves to the long one (cached — one lookup a day)
	if ( preg_match( '#^https?://maps\.app\.goo\.gl/#i', $u ) ) {
		$key  = 'gogh_map_' . md5( $u );
		$long = get_transient( $key );
		if ( false === $long ) {
			$r    = wp_remote_head( $u, array( 'redirection' => 0, 'timeout' => 4 ) );
			$long = is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_header( $r, 'location' );
			set_transient( $key, $long, DAY_IN_SECONDS );
		}
		if ( '' === $long ) {
			return '';
		}
		$u = $long;
	}
	if ( preg_match( '#^https?://(www\.)?google\.[a-z.]+/maps/embed#i', $u ) || preg_match( '#[?&]output=embed#i', $u ) ) {
		return $u;
	}
	if ( preg_match( '#^https?://(www\.)?openstreetmap\.org/export/embed#i', $u ) ) {
		return $u;
	}
	if ( preg_match( '#^https?://(www\.)?openstreetmap\.org/.*\#map=(\d+)/(-?[\d.]+)/(-?[\d.]+)#i', $u, $m ) ) {
		$lat  = (float) $m[3];
		$lng  = (float) $m[4];
		$span = 0.02 * pow( 2, 14 - min( 19, (int) $m[2] ) );
		return 'https://www.openstreetmap.org/export/embed.html?bbox=' . ( $lng - $span ) . ',' . ( $lat - $span / 2 ) . ',' . ( $lng + $span ) . ',' . ( $lat + $span / 2 ) . '&layer=mapnik&marker=' . $lat . ',' . $lng;
	}
	if ( ! preg_match( '#^https?://((www|maps)\.)?google\.[a-z.]+/maps#i', $u ) ) {
		return '';
	}
	if ( preg_match( '#/maps/(place|search)/([^/?\#]+)#i', $u, $m ) ) {
		return 'https://www.google.com/maps?q=' . rawurlencode( rawurldecode( str_replace( '+', ' ', $m[2] ) ) ) . '&output=embed';
	}
	if ( preg_match( '#[?&]q=([^&\#]+)#i', $u, $m ) ) {
		return 'https://www.google.com/maps?q=' . $m[1] . '&output=embed';
	}
	if ( preg_match( '#/maps/@(-?[\d.]+),(-?[\d.]+),(\d+)z#i', $u, $m ) ) {
		return 'https://www.google.com/maps?q=' . $m[1] . ',' . $m[2] . '&z=' . $m[3] . '&output=embed';
	}
	return '';
}
function gogh_inject_embeds( $attrs, $content ) {
	if ( false === strpos( $content, 'gogh-embed-map' ) ) {
		return $content;
	}
	$els = isset( $attrs['model']['elements'] ) && is_array( $attrs['model']['elements'] )
		? $attrs['model']['elements'] : array();
	foreach ( $els as $i => $e ) {
		if ( empty( $e['type'] ) || 'embed' !== $e['type'] ) {
			continue;
		}
		$url = ! empty( $e['url'] ) ? (string) $e['url'] : '';
		// pages published before the model kept the link (v0.99.650) still
		// carry it in the markup: read it back so their maps frame too
		if ( '' === $url && preg_match( '/<div class="[^"]*\bgogh-el-' . ( $i + 1 ) . '\b[^"]*\bgogh-embed-map\b[^"]*">\s*<a class="gogh-embed-link" href="([^"]+)"/', $content, $mm ) ) {
			$url = html_entity_decode( $mm[1], ENT_QUOTES );
		}
		if ( '' === $url ) {
			continue;
		}
		$src = gogh_map_embed_url( $url );
		if ( '' === $src ) {
			continue;
		}
		$iframe  = '<iframe src="' . esc_url( $src ) . '" title="Map" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen style="width:100%;height:100%;border:0;display:block;position:absolute;inset:0"></iframe>';
		$content = preg_replace_callback(
			'/(<div class="[^"]*\bgogh-el-' . ( $i + 1 ) . '\b[^"]*\bgogh-embed-map\b[^"]*">).*?<\/div>/s',
			function ( $m ) use ( $iframe ) {
				return $m[1] . $iframe . '</div>';
			},
			$content,
			1
		);
	}
	return $content;
}

/**
 * FAQ sections carry their questions as DATA in the model — so the render
 * can speak schema.org fluently: one FAQPage JSON-LD script per FAQ
 * section, generated fresh on every render (never stored, never kses'd).
 */
function gogh_faq_schema( $attrs ) {
	$els = isset( $attrs['model']['elements'] ) && is_array( $attrs['model']['elements'] )
		? $attrs['model']['elements'] : array();
	$qa = array();
	foreach ( $els as $e ) {
		if ( empty( $e['faq'] ) || ! is_array( $e['faq'] ) ) {
			continue;
		}
		foreach ( $e['faq'] as $item ) {
			if ( empty( $item['q'] ) || empty( $item['a'] ) ) {
				continue;
			}
			$qa[] = array(
				'@type'          => 'Question',
				'name'           => wp_strip_all_tags( $item['q'] ),
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => wp_strip_all_tags( $item['a'] ),
				),
			);
		}
	}
	if ( ! $qa ) {
		return '';
	}
	$schema = array(
		'@context'   => 'https://schema.org',
		'@type'      => 'FAQPage',
		'mainEntity' => $qa,
	);
	return '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
}

/**
 * Experiences: stored markup carries only a plain link (kses-safe, and the
 * plugin-off fallback). At render time it becomes a sandboxed iframe. The
 * src is NEVER taken from attributes — only the attachment ID is, and the
 * URL is resolved server-side after checking the attachment really is an
 * uploaded text/html file (uploads of which are capability-gated below).
 * allow-scripts WITHOUT allow-same-origin = opaque origin: the uploaded
 * code cannot read cookies or reach the embedding page.
 */
function gogh_inject_experiences( $attrs, $content ) {
	$els = isset( $attrs['model']['elements'] ) && is_array( $attrs['model']['elements'] )
		? $attrs['model']['elements'] : array();
	foreach ( $els as $i => $e ) {
		if ( empty( $e['type'] ) || 'exp' !== $e['type'] || empty( $e['expId'] ) ) {
			continue;
		}
		$id = intval( $e['expId'] );
		if ( $id <= 0 || 'text/html' !== get_post_mime_type( $id ) ) {
			continue;
		}
		$src = wp_get_attachment_url( $id );
		if ( ! $src ) {
			continue;
		}
		$iframe  = '<iframe src="' . esc_url( $src ) . '" sandbox="allow-scripts" title="Interactive experience" loading="lazy" style="width:100%;height:100%;border:0;display:block"></iframe>';
		// the class list gains render-time extras (layout support), so match
		// by our two authored classes rather than the exact attribute value
		$content = preg_replace_callback(
			'/(<div class="[^"]*\bgogh-el-' . ( $i + 1 ) . '\b[^"]*\bgogh-exp\b[^"]*">).*?<\/div>/s',
			function ( $m ) use ( $iframe ) {
				return $m[1] . $iframe . '</div>';
			},
			$content,
			1
		);
	}
	return $content;
}

/**
 * Page styles: a gogh-provided "Blank canvas" template — post content only,
 * no site header or footer. Registered as a plugin block template (WP 6.7+);
 * on older WordPress the option simply doesn't appear.
 */
add_action( 'init', function () {
	if ( ! function_exists( 'register_block_template' ) ) {
		return;
	}
	register_block_template( 'gogh//blank-canvas', array(
		'title'       => __( 'Blank canvas', 'gogh-editor' ),
		'description' => __( 'Just your content, no site header or footer.', 'gogh-editor' ),
		'post_types'  => array( 'page', 'gogh_panel' ),
		'content'     => '<!-- wp:group {"tagName":"main","layout":{"type":"default"},"style":{"spacing":{"blockGap":"0","margin":{"top":"0","bottom":"0"}}}} --><main class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:post-content /--></main><!-- /wp:group -->',
	) );
} );

/**
 * Gogh's own patterns: a few pattern-directory favourites captured as plugin
 * patterns (they aren't registered locally by any theme), so every theme gets
 * a decent shelf in the section picker.
 */
add_action( 'init', function () {
	$pats = array(
		'fullscreen-cover-image-gallery' => array( __( 'Fullscreen cover image gallery', 'gogh-editor' ), array( 'gallery', 'banner' ) ),
		'fullwidth-headline-right'       => array( __( 'Fullwidth headline and description', 'gogh-editor' ), array( 'banner' ) ),
		'simple-call-to-action'          => array( __( 'Simple call to action', 'gogh-editor' ), array( 'call-to-action' ) ),
		'three-column-pricing-table'     => array( __( 'Three column pricing table', 'gogh-editor' ), array( 'call-to-action' ) ),
	);
	foreach ( $pats as $slug => $info ) {
		$file = __DIR__ . '/patterns/' . $slug . '.html';
		if ( ! is_readable( $file ) ) {
			continue;
		}
		register_block_pattern( 'gogh/' . $slug, array(
			'title'      => $info[0],
			'categories' => $info[1],
			'content'    => file_get_contents( $file ),
		) );
	}

	// gogh's own headers and footers: a curated shelf for the Change
	// header/footer flicker, so every site gets good choices regardless of
	// what the theme ships. Built from core blocks with theme preset
	// colours — they re-dress when the site style changes.
	$chrome = array(
		'gogh-header-classic' => array( __( 'Classic header — logo left, menu right', 'gogh-editor' ), 'header' ),
		'gogh-header-centred' => array( __( 'Centred header — stacked and calm', 'gogh-editor' ), 'header' ),
		'gogh-header-minimal' => array( __( 'Minimal header — one quiet line', 'gogh-editor' ), 'header' ),
		'gogh-header-bold'    => array( __( 'Bold header — a solid band', 'gogh-editor' ), 'header' ),
		'gogh-header-split'   => array( __( 'Split header — menu centred, search right', 'gogh-editor' ), 'header' ),
		// James: 'i want an option where folks just have a hamburger menu in
		// desktop view' — a LAYOUT, not a buried toggle
		'gogh-header-hamburger' => array( __( 'Hamburger header — everything behind ☰', 'gogh-editor' ), 'header' ),
		'gogh-header-overlay' => array( __( 'Transparent header — floats over your hero', 'gogh-editor' ), 'header' ),
		// NOT on the shelf: sticky is a property every layout can have, and it
		// has a switch of its own in the header room ("we can make any layout
		// sticky"). The pattern file stays — site definitions read it straight
		// off disk for one-page sites and set chrome.sticky alongside it.
		'gogh-footer-simple'  => array( __( 'Simple footer — everything centred', 'gogh-editor' ), 'footer' ),
		'gogh-footer-columns' => array( __( 'Columns footer — brand, menu, small print', 'gogh-editor' ), 'footer' ),
		'gogh-footer-bold'    => array( __( 'Bold footer — a solid band', 'gogh-editor' ), 'footer' ),
	);
	foreach ( $chrome as $slug => $info ) {
		$file = __DIR__ . '/patterns/' . $slug . '.html';
		if ( ! is_readable( $file ) ) {
			continue;
		}
		register_block_pattern( 'gogh/' . $slug, array(
			'title'       => $info[0],
			'categories'  => array( $info[1] ),
			'blockTypes'  => array( 'core/template-part/' . $info[1] ),
			'viewportWidth' => 1200,
			'content'     => file_get_contents( $file ),
		) );
	}
} );

/**
 * Starter sites: whole sites (pages + menu + front page) shipped as
 * manifests + block-markup files under starters/<slug>/. Pages register as
 * hidden patterns so the preview route can render them; applying a starter
 * is one REST call that trashes current pages (restorable), creates the new
 * set, rebuilds the menu, and wires the front and posts pages.
 */
// the test fixture recreates itself: it reads as junk in the Pages list
// and keeps getting trashed (twice now). Visiting any page with
// ?gogh-test=1 restores or rebuilds it from the bundled copy.
add_action( 'init', function () {
	if ( ! isset( $_GET['gogh-test'] ) || ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	$fixture = get_page_by_path( 'gogh-test-fixture' );
	if ( $fixture && 'publish' === $fixture->post_status ) {
		return;
	}
	if ( $fixture && 'trash' === $fixture->post_status ) {
		wp_untrash_post( $fixture->ID );
		wp_update_post( array( 'ID' => $fixture->ID, 'post_status' => 'publish', 'post_name' => 'gogh-test-fixture' ) );
		return;
	}
	$file = __DIR__ . '/tests-fixture.html';
	if ( is_readable( $file ) ) {
		wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'gogh test fixture',
			'post_name'    => 'gogh-test-fixture',
			'post_content' => file_get_contents( $file ),
		) );
	}
} );

// ---------- gogh as the front door ----------
// With gogh installed, gogh IS the page-building and writing experience:
// Add Page lands on the canvas, Add New Post in the write room, and Edit
// follows — for everything gogh can faithfully edit. Three laws (James,
// 2026-09-03): take over the doors not the bodies; only claim what gogh
// can faithfully edit; always leave the back door (a labelled WordPress
// editor row action, and the gogh_default_editor filter kills the whole
// takeover).
function gogh_default_editor() {
	return (bool) apply_filters( 'gogh_default_editor', true );
}
// can gogh faithfully edit this? New and empty: yes. Built by gogh: yes.
// A post that is prose (the write room's vocabulary): yes. Foreign
// builders, unknown blocks, classic content: the WordPress editor keeps
// it — gogh never opens what it would mangle.
function gogh_claims_post( $post ) {
	$post = get_post( $post );
	if ( ! $post || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) {
		return false;
	}
	$c     = (string) $post->post_content;
	$claim = false;
	if ( '' === trim( $c ) || false !== strpos( $c, '<!-- wp:gogh/' ) ) {
		$claim = true;
	} elseif ( 'post' === $post->post_type ) {
		$prose = array(
			'core/paragraph', 'core/heading', 'core/image', 'core/list', 'core/list-item',
			'core/quote', 'core/separator', 'core/gallery', 'core/embed', 'core/spacer',
			'core/pullquote', 'core/code', 'core/preformatted',
		);
		$claim = true;
		foreach ( parse_blocks( $c ) as $b ) {
			if ( null === $b['blockName'] ) {
				// stray whitespace between blocks is fine; classic HTML is not
				if ( '' !== trim( $b['innerHTML'] ) ) {
					$claim = false;
					break;
				}
				continue;
			}
			if ( ! in_array( $b['blockName'], $prose, true ) && 0 !== strpos( $b['blockName'], 'gogh/' ) ) {
				$claim = false;
				break;
			}
		}
	}
	return (bool) apply_filters( 'gogh_claims_post', $claim, $post );
}
// the front-end door for a post gogh claims — published posts by
// permalink, drafts through the preview gate
function gogh_front_edit_url( $post ) {
	$post = get_post( $post );
	$args = 'post' === $post->post_type ? array( 'gogh-write' => '1' ) : array( 'gogh-edit' => '1' );
	if ( 'publish' === $post->post_status ) {
		return add_query_arg( $args, get_permalink( $post ) );
	}
	$args['preview'] = 'true';
	$args[ 'page' === $post->post_type ? 'page_id' : 'p' ] = $post->ID;
	return add_query_arg( $args, home_url( '/' ) );
}
// Add Page / Add New Post land straight on gogh's surfaces. An abandoned
// door draft (still blank) is reused, never multiplied; ?gogh-classic=1
// slips past to the WordPress editor.
add_action( 'load-post-new.php', function () {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing only; creation is capability-gated below.
	if ( ! gogh_default_editor() || isset( $_GET['gogh-classic'] ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$type = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : 'post';
	if ( ! in_array( $type, array( 'post', 'page' ), true ) ) {
		return;
	}
	$pto = get_post_type_object( $type );
	if ( ! $pto || ! current_user_can( $pto->cap->create_posts ) ) {
		return;
	}
	$id    = 0;
	$stale = get_posts( array(
		'post_type'   => $type,
		'post_status' => 'draft',
		'numberposts' => 1,
		'author'      => get_current_user_id(),
		'meta_key'    => '_gogh_door',
	) );
	if ( $stale && '' === $stale[0]->post_title && '' === trim( wp_strip_all_tags( $stale[0]->post_content ) ) ) {
		$id = $stale[0]->ID;
	}
	if ( ! $id ) {
		// posts seed one blank paragraph (the write room wants a line to
		// stand on); pages must be TRULY empty for the canvas boot invite,
		// so they are born titled and immediately untitled — wp_insert_post
		// refuses an all-empty birth, wp_update_post allows the blanking
		$id = wp_insert_post( array(
			'post_type'    => $type,
			'post_status'  => 'draft',
			'post_title'   => 'page' === $type ? 'Draft page' : '',
			'post_content' => 'page' === $type ? '' : '<!-- wp:paragraph --><p></p><!-- /wp:paragraph -->',
			'meta_input'   => array( '_gogh_door' => 1 ),
		) );
		if ( $id && ! is_wp_error( $id ) && 'page' === $type ) {
			// wp_update_post refuses an all-empty page even as an update —
			// blank the placeholder title directly; the draft is ours,
			// seconds old, and the canvas title block must start empty
			global $wpdb;
			$wpdb->update( $wpdb->posts, array( 'post_title' => '' ), array( 'ID' => $id ) );
			clean_post_cache( $id );
		}
	}
	if ( $id && ! is_wp_error( $id ) ) {
		wp_safe_redirect( gogh_front_edit_url( $id ) );
		exit;
	}
} );
// With gogh as the front door, Appearance → Editor (the block Site
// Editor) is a second, unfamiliar editor for the same site — a beginner
// who wanders in has no way back to what they know (James: 'doesn't seem
// like we should show it for beginners'). The menu item and the admin
// bar's Edit Site go quiet; site-editor.php still answers by URL, and the
// gogh_default_editor filter brings both back.
add_action( 'admin_menu', function () {
	if ( gogh_default_editor() ) {
		remove_submenu_page( 'themes.php', 'site-editor.php' );
	}
}, 999 );
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( gogh_default_editor() ) {
		$bar->remove_node( 'site-editor' );
	}
}, 999 );

// Edit follows the claim: list rows, the admin bar, theme edit links
add_filter( 'get_edit_post_link', function ( $link, $post_id ) {
	if ( ! gogh_default_editor() ) {
		return $link;
	}
	$post = get_post( $post_id );
	if ( ! $post || ! gogh_claims_post( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $link;
	}
	return gogh_front_edit_url( $post );
}, 10, 2 );
// the labelled back door on every claimed row
function gogh_classic_row_action( $actions, $post ) {
	if ( ! gogh_default_editor() || ! gogh_claims_post( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return $actions;
	}
	$actions['gogh_classic'] = '<a href="' . esc_url( admin_url( sprintf( 'post.php?post=%d&action=edit', $post->ID ) ) ) . '">' .
		esc_html__( 'WordPress editor', 'gogh-editor' ) . '</a>';
	return $actions;
}
add_filter( 'page_row_actions', 'gogh_classic_row_action', 10, 2 );
add_filter( 'post_row_actions', 'gogh_classic_row_action', 10, 2 );

// gogh write: a clean canvas and space to think. ?gogh-new-post creates
// a draft and lands the writer straight on the front-end surface;
// ?gogh-write=1 on any editable post enables the mode.
add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['gogh-new-post'] ) || ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	$id = wp_insert_post( array(
		'post_type'    => 'post',
		'post_status'  => 'draft',
		'post_title'   => '',
		// wp_insert_post refuses a FULLY empty post — one blank paragraph
		// is the difference between a canvas and an error
		'post_content' => '<!-- wp:paragraph --><p></p><!-- /wp:paragraph -->',
	) );
	if ( $id && ! is_wp_error( $id ) ) {
		wp_safe_redirect( add_query_arg( array( 'p' => $id, 'preview' => 'true', 'gogh-write' => '1' ), home_url( '/' ) ) );
		exit;
	}
} );
add_action( 'wp_enqueue_scripts', function () {
	if ( ! isset( $_GET['gogh-write'] ) || ! is_singular( 'post' ) ) {
		return;
	}
	$post = get_post();
	if ( ! $post || ! current_user_can( 'edit_post', $post->ID ) ) {
		return;
	}
	wp_register_script( 'gogh-compose', plugins_url( 'gogh-compose.js', __FILE__ ), array(), '0.99.650-chrome', true );
	wp_enqueue_script( 'gogh-write', plugins_url( 'gogh-write.js', __FILE__ ), array( 'gogh-compose' ), '0.99.650-chrome', true );
	wp_enqueue_style( 'gogh-write', plugins_url( 'gogh-write.css', __FILE__ ), array(), '0.99.650-chrome' );
	wp_localize_script( 'gogh-write', 'GOGHWRITE', array(
		'postId'  => $post->ID,
		'restUrl' => esc_url_raw( rest_url() ),
		'nonce'   => wp_create_nonce( 'wp_rest' ),
		'status'  => $post->post_status,
		'homeUrl' => esc_url_raw( home_url( '/' ) ),
		'siteName' => get_bloginfo( 'name' ),
		'adminEdit' => esc_url_raw( get_edit_post_link( $post->ID, 'raw' ) ),
		'postStyle' => get_post_meta( $post->ID, '_gogh_post_style', true ) ?: '',
		'permalink' => esc_url_raw( get_permalink( $post->ID ) ),
		'excerpt' => (string) $post->post_excerpt,
		// the freeform break's starter: a real gogh/section block, generated
		// by the canvas itself and kept as a file — the write room stamps a
		// fresh scope on every insert
		'breakTpl' => (string) file_get_contents( __DIR__ . '/gogh-break.html' ),
	) );
	show_admin_bar( false );
} );

// Pages carry a hand-written description too: the SEO panel's search-
// preview card saves it as the native excerpt. Posts support excerpts out
// of the box; pages need the switch thrown before REST accepts the field.
add_action( 'init', function () {
	add_post_type_support( 'page', 'excerpt' );
} );

/**
 * ✦ Reading styles — how a post READS. The third of the family: Site style
 * (the whole site), Page style (how a page is framed), Post style (how a
 * post reads). A look owns GEOMETRY AND RHYTHM — title treatment, measure,
 * image containment — and never colour or font families: those stay with
 * Site style, so any look composes with any site style and nothing clashes.
 * Switching looks is metadata + CSS; post_content never changes — the words
 * simply re-dress.
 */
/**
 * ✦ Motion style — how the site MOVES. The fourth of the family: Site
 * style (colour and type), Page style (framing), Post style (reading),
 * Motion style (the site's gait). One choice, everywhere, coherent — never
 * per-element animation dropdowns, which is how sites get seasick.
 *
 * All pure CSS scroll-driven animation (animation-timeline: view()): zero
 * JS, compositor-only, and honest about support — browsers without scroll
 * timelines simply see a still site with everything visible. Reduced
 * motion always wins ("motion is a garnish, never a requirement"), and
 * the editor stays still so dragging never fights an entrance.
 */
/**
 * ✦ Blog style — how the blog page presents the work. The fifth of the
 * family. One choice, stored site-wide (there is one blog page), pure CSS
 * over the theme's own query-loop markup — plus one honest render-time
 * enrichment: the stock loop carries only title and date, so while a look
 * that wants media is active, each item gains its featured image (a
 * brand-tinted placeholder when a post has none) and excerpt at render.
 * Nothing is stored; switch to Default and the loop is untouched again.
 */
function gogh_blog_styles() {
	return array( '', 'list', 'cards', 'cover', 'ledger' ); // '' = the theme's own
}
function gogh_blog_style_active() {
	if ( ! ( is_home() || is_category() || is_tag() || is_author() ) ) {
		return '';
	}
	if ( isset( $_GET['gogh-look'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation-only preview
		$look = sanitize_key( $_GET['gogh-look'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $look, gogh_blog_styles(), true ) ) {
			return $look;
		}
	}
	$opt = get_option( 'gogh_blog_style', '' );
	return in_array( $opt, gogh_blog_styles(), true ) ? $opt : '';
}
// the posts page wears its own name: Twenty Twenty-Five's home template
// opens with a hidden "Blog" heading, but the page people made is called
// Journal or Insights — on a static posts page a level-one heading that
// says exactly Blog takes the page's title instead
add_filter( 'render_block_core/heading', function ( $html, $block ) {
	if ( is_admin() || ! is_home() ) {
		return $html;
	}
	$page_id = (int) get_option( 'page_for_posts' );
	if ( $page_id <= 0 ) {
		return $html;
	}
	$level = isset( $block['attrs']['level'] ) ? (int) $block['attrs']['level'] : 2;
	if ( 1 !== $level ) {
		return $html;
	}
	$said = trim( wp_strip_all_tags( $html ) );
	if ( '' === $said || ! in_array( $said, array( 'Blog', __( 'Blog', 'twentytwentyfive' ) ), true ) ) {
		return $html;
	}
	$title = trim( wp_strip_all_tags( get_the_title( $page_id ) ) );
	if ( '' === $title || $title === $said ) {
		return $html;
	}
	$swapped = preg_replace_callback(
		'/>(\s*)' . preg_quote( $said, '/' ) . '(\s*)</',
		function ( $m ) use ( $title ) {
			return '>' . $m[1] . esc_html( $title ) . $m[2] . '<';
		},
		$html,
		1
	);
	return null === $swapped ? $html : $swapped;
}, 10, 2 );
add_filter( 'body_class', function ( $classes ) {
	$b = gogh_blog_style_active();
	if ( $b ) {
		$classes[] = 'gogh-blog-' . $b;
	}
	return $classes;
}, 20 );
// the enrichment: media + excerpt join each loop item while a look wants them
add_filter( 'render_block_core/post-template', function ( $content, $block ) {
	// the posts rail on a canvas page wears the same looks as the blog: its
	// template carries gogh-posts-tpl, and the media and excerpt spans the
	// looks dress must be there wherever it sits
	$rail = ! empty( $block['attrs']['className'] ) && false !== strpos( (string) $block['attrs']['className'], 'gogh-posts-tpl' );
	if ( ! $rail && ! ( is_home() || is_category() || is_tag() || is_author() ) ) {
		return $content;
	}
	// enrich while a look is active — and ALWAYS for editors, so the pill's
	// hover-audition has real media to dress ('blog style is not showing
	// any images, just empty cards'): the client flips classes instantly,
	// the spans must already be there. Default-look visitors keep clean
	// markup; the CSS hides the spans until a look asks for them.
	$b = gogh_blog_style_active();
	if ( ! $rail && ! in_array( $b, array( 'list', 'cards', 'cover', 'ledger' ), true ) && ! current_user_can( 'edit_theme_options' ) ) {
		return $content;
	}
	return preg_replace_callback(
		'/<li class="wp-block-post post-(\d+)[^"]*">/',
		function ( $m ) {
			$id  = (int) $m[1];
			$img = get_the_post_thumbnail( $id, 'medium_large', array( 'class' => 'gogh-bs-thumb' ) );
			if ( ! $img && preg_match( '/<img[^>]+src="([^"]+)"/', (string) get_post_field( 'post_content', $id ), $im ) ) {
				// no featured image, but the post has pictures — the first one
				// stands in ('its still just showing image placeholders')
				$img = '<img class="gogh-bs-thumb" src="' . esc_url( $im[1] ) . '" alt="" loading="lazy" />';
			}
			if ( ! $img ) {
				// no featured image: a brand-tinted stand-in, hue seeded by the
				// post id so neighbouring posts never match
				$hue = ( $id * 47 ) % 360;
				$img = '<span class="gogh-bs-thumb gogh-bs-thumb-empty" style="background: linear-gradient(130deg, oklch(0.72 0.09 ' . $hue . '), oklch(0.35 0.08 ' . ( ( $hue + 40 ) % 360 ) . '));"></span>';
			}
			$ex = esc_html( wp_trim_words( get_the_excerpt( $id ), 20 ) );
			// a stand-in is marked: the ledger, a list of words, leaves it out
			$empty = false !== strpos( $img, 'gogh-bs-thumb-empty' ) ? ' is-empty' : '';
			return $m[0] . '<span class="gogh-bs-media' . $empty . '">' . $img . '</span><span class="gogh-bs-excerpt">' . $ex . '</span>';
		},
		$content
	);
}, 10, 2 );
// a hand-picked posts rail names its posts in the template's class
// (gogh-pick-12,7,31): the loop shows exactly those, in that order — and
// without gogh the same markup shows the newest few, as written
add_filter( 'query_loop_block_query_vars', function ( $query, $block ) {
	$cls = isset( $block->parsed_block['attrs']['className'] ) ? (string) $block->parsed_block['attrs']['className'] : '';
	if ( '' === $cls || ! preg_match( '/gogh-pick-([\d,]+)/', $cls, $m ) ) {
		return $query;
	}
	$ids = array_values( array_filter( array_map( 'intval', explode( ',', $m[1] ) ) ) );
	if ( ! $ids ) {
		return $query;
	}
	$query['post__in']       = $ids;
	$query['orderby']        = 'post__in';
	$query['posts_per_page'] = count( $ids );
	unset( $query['category__in'], $query['tax_query'] );
	return $query;
}, 10, 2 );
function gogh_blog_style_css() {
	$hair    = 'color-mix(in srgb, currentColor 25%, transparent)';
	$surface = 'color-mix(in srgb, currentColor 7%, transparent)';
	$lf      = gogh_look_fonts();
	$disp    = $lf['display'] ? ' font-family: ' . $lf['display'] . ';' : '';
	return
		// the posts rail's plain grid: core lays the columns, gogh sets the
		// gutter and tidies the card; a look (below) takes over the whole list
		'.gogh-widget > .wp-block-query.gogh-posts { width: 100%; }' .
		'.gogh-posts ul.wp-block-post-template { list-style: none; padding-left: 0; margin: 0; }' .
		'.gogh-posts-gap-s ul.wp-block-post-template.is-layout-grid { gap: 12px; }' .
		'.gogh-posts-gap-m ul.wp-block-post-template.is-layout-grid { gap: 24px; }' .
		'.gogh-posts-gap-l ul.wp-block-post-template.is-layout-grid { gap: 40px; }' .
		'.gogh-posts-grid li.wp-block-post { margin: 0; }' .
		'.gogh-posts-grid li.wp-block-post .wp-block-post-featured-image img { border-radius: 8px; width: 100%; }' .
		'.gogh-posts-grid li.wp-block-post .wp-block-post-title { margin-block: 0.6em 0.15em; font-size: 1.15em; line-height: 1.25; }' .
		'.gogh-posts-grid li.wp-block-post :is(.wp-block-post-date, .wp-block-post-excerpt, .wp-block-post-terms) { margin-block: 0.2em 0; font-size: 0.9em; }' .
		'.gogh-posts-grid li.wp-block-post .wp-block-post-terms { font-size: 0.75em; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; }' .
		// a rail wearing Cards keeps the columns it was built with (the look's own
		// auto-fill grid packed three posts into four narrow columns) and the
		// picture shape the panel chose; phones and tablets step down
		'.gogh-posts-c1.gogh-blog-cards ul.wp-block-post-template { grid-template-columns: minmax(0, 1fr); }' .
		'.gogh-posts-c2.gogh-blog-cards ul.wp-block-post-template { grid-template-columns: repeat(2, minmax(0, 1fr)); }' .
		'.gogh-posts-c3.gogh-blog-cards ul.wp-block-post-template { grid-template-columns: repeat(3, minmax(0, 1fr)); }' .
		'.gogh-posts-c4.gogh-blog-cards ul.wp-block-post-template { grid-template-columns: repeat(4, minmax(0, 1fr)); }' .
		'@media (max-width: 900px) { .gogh-posts-c3.gogh-blog-cards ul.wp-block-post-template, .gogh-posts-c4.gogh-blog-cards ul.wp-block-post-template { grid-template-columns: repeat(2, minmax(0, 1fr)); } }' .
		'@media (max-width: 600px) { .gogh-posts.gogh-blog-cards ul.wp-block-post-template { grid-template-columns: minmax(0, 1fr); } }' .
		'.gogh-posts-pic-landscape.gogh-blog-cards .gogh-bs-media { aspect-ratio: 4 / 3; }' .
		'.gogh-posts-pic-square.gogh-blog-cards .gogh-bs-media { aspect-ratio: 1; }' .
		'.gogh-posts-pic-portrait.gogh-blog-cards .gogh-bs-media { aspect-ratio: 3 / 4; }' .
		// shared plumbing for every look
		'[class*="gogh-blog-"] ul.wp-block-post-template { list-style: none; padding-left: 0; max-width: min(1200px, 94vw); margin-inline: auto !important; }' .
		// a loop that already carries its own featured image (the theme's, or one
		// James added) would show every picture twice while a look dresses the
		// item with gogh's media span — the look's picture is the one that stays
		'[class*="gogh-blog-"] ul.wp-block-post-template .wp-block-post-featured-image { display: none !important; }' .
		'.gogh-blog-list ul.wp-block-post-template { max-width: min(920px, 92vw); }' .
		'.gogh-blog-list li.wp-block-post :is(.wp-block-post-title, .wp-block-post-date, .gogh-bs-excerpt), .gogh-blog-list li.wp-block-post .wp-block-post-title * { margin-block: 0; text-align: left !important; justify-content: flex-start; }'.
		// the theme centres titles BOX-level (fit-content + auto margins) —
		// text-align never stood a chance; claim the row
		'.gogh-blog-list li.wp-block-post .wp-block-post-title { width: 100%; max-width: none; margin-inline: 0 !important; }' .
		// an index shows the way in, not the whole journey: the theme's loop
		// renders FULL post content inline — the looks stand it down and let
		// the injected excerpt speak
		'[class*="gogh-blog-"] li.wp-block-post :is(.wp-block-post-content, .entry-content) { display: none; }' .
		'.gogh-bs-media, .gogh-bs-excerpt { display: none; }' .
		'[class*="gogh-blog-"] .gogh-bs-media { display: block; }' .
		'[class*="gogh-blog-"] .gogh-bs-excerpt { display: revert; }' .
		'[class*="gogh-blog-"] .gogh-bs-media { position: relative; overflow: hidden; }' .
		// the frame owns the size: a tall image stretches an aspect-ratio box,
		// so the thumb is pinned absolute inside and cover-cropped
		'[class*="gogh-blog-"] .gogh-bs-thumb { position: absolute; inset: 0; display: block; width: 100%; height: 100%; object-fit: cover; }' .
		'[class*="gogh-blog-"] li.wp-block-post .wp-block-post-title { margin: 0;' . $disp . ' }' .
		// LIST — the theme's flow, tidied: hairlines, dates ranged right
		'.gogh-blog-list li.wp-block-post { position: relative; display: flex; flex-direction: column; gap: 6px; padding: 22px 8em 22px 0; border-top: 1px solid ' . $hair . '; margin: 0; }' .
		'.gogh-blog-list li.wp-block-post:last-child { border-bottom: 1px solid ' . $hair . '; }' .
		'.gogh-blog-list .gogh-bs-media { display: none; }' .
		'.gogh-blog-list li.wp-block-post .wp-block-post-title { font-size: 1.5em; line-height: 1.15; }' .
		'.gogh-blog-list .gogh-bs-excerpt { order: 2; font-size: 0.92em; opacity: 0.75; max-width: 60ch; }' .
	// List is the WORDS look: no pictures at all, including the theme
	// template's own featured-image block ("list view should not show
	// any images")
	'.gogh-blog-list li.wp-block-post :is(.wp-block-post-featured-image, .gogh-bs-media, figure) { display: none !important; }' .
		'.gogh-blog-list li.wp-block-post .wp-block-post-date { position: absolute; right: 0; top: 24px; font-size: 0.78em; opacity: 0.6; font-variant-numeric: tabular-nums; }' .
		// CARDS — image-led grid, the crowd-pleaser
		'.gogh-blog-cards ul.wp-block-post-template { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 22px; }' .
		'.gogh-blog-cards li.wp-block-post { display: flex; flex-direction: column; margin: 0; background: ' . $surface . '; border-radius: 14px; overflow: hidden; padding-bottom: 20px; }' .
		'@media (prefers-reduced-motion: no-preference) { .gogh-blog-cards li.wp-block-post { transition: transform 0.22s ease, box-shadow 0.22s ease; } .gogh-blog-cards li.wp-block-post:hover { transform: translateY(-6px); box-shadow: 0 24px 48px -20px rgba(0, 0, 0, 0.45); } }' .
		'.gogh-blog-cards .gogh-bs-media { order: -1; aspect-ratio: 16 / 10; margin-bottom: 16px; overflow: hidden; }' .
		'.gogh-blog-cards li.wp-block-post :is(.wp-block-post-title, .gogh-bs-excerpt, .wp-block-post-date) { padding-inline: 20px; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-title { font-size: 1.25em; line-height: 1.2; }' .
		'.gogh-blog-cards .gogh-bs-excerpt { order: 2; font-size: 0.86em; opacity: 0.75; margin-top: 8px; line-height: 1.55; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-date { order: 3; font-size: 0.72em; letter-spacing: 0.1em; text-transform: uppercase; opacity: 0.6; margin-top: 12px; white-space: nowrap; }' .
		// the theme's own loop item is a padded, constrained group (spacing-60
		// above and below, global padding at the sides) — inside a card that
		// read as a title floating 100px under the picture and indented past
		// the excerpt (James: 'the blog card layout is really weird - spacing').
		// The group dissolves; its title and date become the card's own children
		'[class*="gogh-blog-"] li.wp-block-post > .wp-block-group { display: contents; }' .
		'[class*="gogh-blog-"] li.wp-block-post > .wp-block-group > * { margin: 0 !important; max-width: none !important; width: auto; }' .
		'[class*="gogh-blog-"] li.wp-block-post .wp-block-post-title { margin: 0; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-title { order: 1; margin: 0; text-wrap: balance; text-align: left !important; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-date { text-align: left !important; }' .
		'.gogh-blog-cards li.wp-block-post :is(.wp-block-post-title, .wp-block-post-date, .gogh-bs-excerpt) { padding-inline: 22px !important; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-title a { text-decoration: none; }' .
		// the whole card is the link (James): the title's own link stretches over
		// the card — one anchor, honest markup, no duplicate links for screen readers
		'.gogh-blog-cards li.wp-block-post { position: relative; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-title a::after { content: ""; position: absolute; inset: 0; z-index: 1; border-radius: inherit; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-title a:focus-visible::after { outline: 2px solid currentColor; outline-offset: -2px; }' .
		'.gogh-blog-cards li.wp-block-post { cursor: pointer; }' .
		'.gogh-blog-cards li.wp-block-post :is(.wp-block-post-author, .wp-block-post-terms, .wp-block-post-author-name, .wp-block-read-more, .wp-block-post-excerpt) { order: 4; padding-inline: 20px; font-size: 0.8em; opacity: 0.7; margin-top: 10px; }' .
		'.gogh-blog-cards li.wp-block-post .wp-block-post-excerpt { display: none; }' .
		'.gogh-blog-cards .gogh-bs-media { margin-bottom: 18px; }' .
		'.gogh-blog-cards .gogh-bs-media img { width: 100%; height: 100%; object-fit: cover; display: block; }' .
		// COVER — the newest post huge, title overlaid; the rest in a grid
		'.gogh-blog-cover ul.wp-block-post-template { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; }' .
		'.gogh-blog-cover li.wp-block-post { margin: 0; }' .
		'.gogh-blog-cover li.wp-block-post:first-child { grid-column: 1 / -1; position: relative; border-radius: 16px; overflow: hidden; min-height: 380px; display: flex; align-items: flex-end; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .gogh-bs-media { position: absolute; inset: 0; }' .
		'.gogh-blog-cover li.wp-block-post:first-child::after { content: ""; position: absolute; inset: 0; background: linear-gradient(to top, rgba(10, 4, 8, 0.82) 0%, rgba(10, 4, 8, 0) 60%); pointer-events: none; }' .
		'.gogh-blog-cover li.wp-block-post:first-child :is(.wp-block-post-title, .gogh-bs-excerpt, .wp-block-post-date) { position: relative; z-index: 1; padding-inline: 34px; }' .
		'.gogh-blog-cover li.wp-block-post:first-child { flex-direction: column; align-items: flex-start; justify-content: flex-end; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .wp-block-post-title { font-size: clamp(2.2rem, 5vw, 3.4rem); line-height: 0.98; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .wp-block-post-title a { color: #fff; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .gogh-bs-excerpt { order: 2; color: rgba(255, 255, 255, 0.88); font-size: 0.95em; max-width: 52ch; margin-top: 10px; padding-bottom: 30px; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .wp-block-post-date { order: -1; color: rgba(255, 255, 255, 0.75); font-size: 0.72em; letter-spacing: 0.16em; text-transform: uppercase; margin-bottom: 10px; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) { display: flex; flex-direction: column; gap: 10px; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) .gogh-bs-media { order: -1; aspect-ratio: 16 / 10; border-radius: 10px; overflow: hidden; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) .wp-block-post-title { font-size: 1.05em; line-height: 1.25; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) .gogh-bs-excerpt { display: none; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) .wp-block-post-date { font-size: 0.7em; letter-spacing: 0.1em; text-transform: uppercase; opacity: 0.6; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .wp-block-post-title { text-align: left !important; }' .
		'.gogh-blog-cover li.wp-block-post:first-child .wp-block-post-date { padding-top: 0; }' .
		// the theme's posts page links the date, and its link colour was dark
		// on the dark picture
		'.gogh-blog-cover li.wp-block-post:first-child .wp-block-post-date a { color: inherit; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) :is(.wp-block-post-title, .wp-block-post-date) { text-align: left !important; }' .
		'.gogh-blog-cover li.wp-block-post:not(:first-child) .wp-block-post-title a { text-decoration: none; }' .
		'@media (max-width: 700px) { .gogh-blog-cover ul.wp-block-post-template { grid-template-columns: 1fr 1fr; } }' .
		// LEDGER — the dense editorial index; pairs with Gazette
		'.gogh-blog-ledger ul.wp-block-post-template { border-top: 3px double ' . $hair . '; }' .
		'.gogh-blog-ledger li.wp-block-post { display: flex; align-items: center; gap: 18px; padding: 14px 0; border-bottom: 1px solid ' . $hair . '; margin: 0; }' .
		// the theme nests title+date in a group with its own rhythm — flatten
		// it into the row so the ledger stays a LEDGER
		'.gogh-blog-ledger li.wp-block-post > .wp-block-group { flex: 1; display: flex; align-items: baseline; gap: 18px; margin: 0 !important; padding: 0 !important; }' .
		'.gogh-blog-ledger li.wp-block-post :is(.wp-block-post-title, .wp-block-post-date) { margin-block: 0 !important; }' .
		'.gogh-blog-ledger .gogh-bs-media { width: 52px; height: 52px; flex: none; border-radius: 8px; overflow: hidden; }' .
		'.gogh-blog-ledger li.wp-block-post .wp-block-post-title { font-size: 1.1em; line-height: 1.25; flex: 1; }' .
		'.gogh-blog-list li.wp-block-post > .wp-block-group { display: contents; }' .
		'.gogh-blog-ledger .gogh-bs-excerpt { display: none; }' .
		// a post with no picture of its own shows no coloured stand-in in a
		// ledger: an essayist's archive is a list of titles and dates
		'.gogh-blog-ledger .gogh-bs-media.is-empty { display: none; }' .
		// on the posts page the ledger keeps to the reading column, so its
		// rows line up under the page's own heading
		'body.gogh-blog-ledger ul.wp-block-post-template { max-width: min(var(--wp--style--global--content-size, 645px), 94vw); }' .
		'body.gogh-blog-ledger li.wp-block-post .wp-block-post-title { font-size: clamp(1.2rem, 1.8vw, 1.5rem) !important; }' .
		// the wider looks take the page's heading out to the grid's edge
		'body:is(.gogh-blog-cards, .gogh-blog-cover) main > h1 { max-width: min(1200px, 94vw); }' .
		'body.gogh-blog-list main > h1 { max-width: min(920px, 92vw); }' .
		'.gogh-blog-ledger li.wp-block-post .wp-block-post-date { font-size: 0.78em; opacity: 0.6; font-variant-numeric: tabular-nums; white-space: nowrap; }';
}

function gogh_motion_styles() {
	return array( '', 'calm', 'rise', 'drama' ); // '' = Still, the default
}
function gogh_motion_css() {
	$targets = function ( $key ) {
		return 'html:not(.gogh-editing) body.gogh-motion-' . $key . ' .gogh-section > *, ' .
			'html:not(.gogh-editing) body.gogh-motion-' . $key . ' .entry-content > *:not(.gogh-wrap):not(.wp-block-post-title):not(.alignfull)';
	};
	return
		'@supports (animation-timeline: view()) { @media (prefers-reduced-motion: no-preference) {' .
		// ranges end at COVER, not entry: a short element's "entry" span is
		// its own height — a badge finished its whole entrance in ~15px of
		// scroll and read as nothing ("doesnt seem very motiony"). Anchoring
		// the end to the element's journey through the viewport gives every
		// element, tall or tiny, a real scroll distance to move across.
		// CALM — a soft fade with barely-there lift
		$targets( 'calm' ) . ' { animation: gogh-mo-calm linear both; animation-timeline: view(); animation-range: entry 0% cover 25%; }' .
		'@keyframes gogh-mo-calm { from { opacity: 0; translate: 0 12px; } }' .
		// RISE — content lifts into place with a small sibling stagger
		$targets( 'rise' ) . ' { animation: gogh-mo-rise linear both; animation-timeline: view(); animation-range: entry 0% cover 30%; }' .
		'html:not(.gogh-editing) body.gogh-motion-rise .gogh-section > :nth-child(2) { animation-range: entry 5% cover 38%; }' .
		'html:not(.gogh-editing) body.gogh-motion-rise .gogh-section > :nth-child(3) { animation-range: entry 10% cover 46%; }' .
		'html:not(.gogh-editing) body.gogh-motion-rise .gogh-section > :nth-child(n+4) { animation-range: entry 15% cover 54%; }' .
		'@keyframes gogh-mo-rise { from { opacity: 0; translate: 0 40px; } }' .
		// DRAMA — bigger travel and a breath of scale
		$targets( 'drama' ) . ' { animation: gogh-mo-drama linear both; animation-timeline: view(); animation-range: entry 0% cover 45%; }' .
		'@keyframes gogh-mo-drama { from { opacity: 0; translate: 0 72px; scale: 0.96; } }' .
		'} }';
}
// the imagination's key — folks bring their own. Three sources, first
// wins: wp-config's GOGH_ASK_KEY (hosts/pros), the environment, or the
// option an admin pasted into the Ask panel (stored unautoloaded,
// write-only: it never travels back to a browser). No key = the tier
// simply isn't there; the vocabulary still answers.
function gogh_ask_key() {
	if ( defined( 'GOGH_ASK_KEY' ) && GOGH_ASK_KEY ) {
		return GOGH_ASK_KEY;
	}
	$env = getenv( 'ANTHROPIC_API_KEY' );
	if ( $env ) {
		return $env;
	}
	return (string) get_option( 'gogh_ask_key', '' );
}
// identity-linked keys act inside a workspace: same three sources
function gogh_ask_workspace() {
	if ( defined( 'GOGH_ASK_WORKSPACE' ) && GOGH_ASK_WORKSPACE ) {
		return GOGH_ASK_WORKSPACE;
	}
	$env = getenv( 'ANTHROPIC_WORKSPACE_ID' );
	if ( $env ) {
		return $env;
	}
	return (string) get_option( 'gogh_ask_workspace', '' );
}
// The section-level imagination tier is PARKED (James, 2026-09-03: the
// dice showed choice-within-guidelines beats ask-and-hope — "we might not
// need ai here"). The vocabulary, the seam and Experiences all stay; the
// model-backed section rewriter waits behind this labs door.
function gogh_labs_ask() {
	if ( defined( 'GOGH_LABS_ASK' ) ) {
		return (bool) GOGH_LABS_ASK;
	}
	return (bool) apply_filters( 'gogh_labs_ask', false );
}
function gogh_ask_handler( $req ) {
	if ( ! gogh_labs_ask() ) {
		return new WP_Error( 'gogh_ask_parked', __( 'The imagination tier is parked — Gogh answers with its built-in vocabulary.', 'gogh-editor' ), array( 'status' => 501 ) );
	}
	$key = gogh_ask_key();
	if ( ! $key ) {
		return new WP_Error( 'gogh_ask_no_key', __( 'The imagination tier has no key.', 'gogh-editor' ), array( 'status' => 501 ) );
	}
	$p           = $req->get_json_params();
	$instruction = isset( $p['instruction'] ) ? substr( sanitize_text_field( (string) $p['instruction'] ), 0, 300 ) : '';
	$section     = isset( $p['section'] ) && is_array( $p['section'] ) ? $p['section'] : null;
	if ( ! $instruction || ! $section || empty( $section['els'] ) || ! is_array( $section['els'] ) ) {
		return new WP_Error( 'gogh_ask_bad', __( 'Nothing to imagine with.', 'gogh-editor' ), array( 'status' => 400 ) );
	}
	// re-project server-side: only the fields the prompt schema names, so
	// the prompt can't be stuffed through a hand-rolled request body
	$els = array();
	foreach ( array_slice( $section['els'], 0, 24 ) as $i => $e ) {
		if ( ! is_array( $e ) ) {
			continue;
		}
		$o = array(
			'i'    => $i,
			'type' => isset( $e['type'] ) ? sanitize_key( $e['type'] ) : 'box',
			'x'    => isset( $e['x'] ) ? (int) $e['x'] : 0,
			'y'    => isset( $e['y'] ) ? (int) $e['y'] : 0,
			'w'    => isset( $e['w'] ) ? (int) $e['w'] : 100,
			'h'    => isset( $e['h'] ) ? (int) $e['h'] : 50,
		);
		foreach ( array( 'fs', 'align' ) as $f ) {
			if ( ! empty( $e[ $f ] ) ) {
				$o[ $f ] = substr( sanitize_text_field( (string) $e[ $f ] ), 0, 20 );
			}
		}
		if ( ! empty( $e['text'] ) ) {
			$o['text'] = substr( sanitize_text_field( (string) $e['text'] ), 0, 120 );
		}
		if ( ! empty( $e['ghost'] ) ) {
			$o['ghost'] = true;
		}
		if ( ! empty( $e['kids'] ) && is_array( $e['kids'] ) ) {
			$o['kids'] = count( $e['kids'] );
		}
		$els[] = $o;
	}
	// the client names the themes its palette actually offers (accents are
	// per-site); slugs only, and the client re-validates on the way back
	$themes = array( 'paper', 'mist', 'ink', 'sweep', 'mesh' );
	if ( ! empty( $section['themes'] ) && is_array( $section['themes'] ) ) {
		$sent = array();
		foreach ( array_slice( $section['themes'], 0, 12 ) as $t ) {
			if ( is_array( $t ) ) {
				// slug plus its MEASURED feel and hex — on a dark-mode
				// palette "ink" paints white, and only the client knows;
				// the hex is what stops "red" coming back blue
				$sl = isset( $t['slug'] ) ? sanitize_key( $t['slug'] ) : '';
				$fl = isset( $t['feel'] ) ? sanitize_key( $t['feel'] ) : '';
				$hx = ( isset( $t['hex'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $t['hex'] ) ) ? strtolower( $t['hex'] ) : '';
				if ( $sl ) {
					$note   = trim( $fl . ( $hx ? ' ' . $hx : '' ) );
					$sent[] = $sl . ( $note ? ' (' . $note . ')' : '' );
				}
			} elseif ( is_string( $t ) && sanitize_key( $t ) ) {
				$sent[] = sanitize_key( $t );
			}
		}
		if ( $sent ) {
			$themes = $sent;
		}
	}
	$sys    =
		"You are the imagination inside Gogh, a visual page builder. You redesign ONE section at a time.\n" .
		"A section is a 1200-unit-wide canvas; y grows downward; every element is a rectangle {i,type,x,y,w,h}. " .
		"Types: heading, para (text), button, image, badge, box (a card; kids = how many pieces it holds).\n" .
		"You NEVER write HTML or CSS. You return CHANGES to this model as JSON and the builder renders them safely.\n\n" .
		"Reply with ONLY this JSON — no fences, no prose:\n" .
		'{"candidates":[{"name":"Two words","ops":{}},{"name":"Two words","ops":{}}]}' . "\n" .
		"Exactly 2 candidates, each a genuinely DIFFERENT honest interpretation. name = 2-3 evocative words.\n\n" .
		"ops may contain:\n" .
		'- "set": [{"i":N, ...fields}] to change elements' . "\n" .
		'- "add": [{"type":"heading|para|button|image|badge","x":N,"y":N,"w":N,"h":N,"text":"..."}]' . "\n" .
		'- "remove": [indexes]' . "\n" .
		'- "section": {"theme":"slug","minH":N,"spread":0.7-1.6}' . "\n\n" .
		'Allowed set fields: x y w h (numbers) · text (short, the site\'s voice) · fs (null, "__disp-s", "__disp-m", "__disp-l" — display sizes, big) · align ("left","center","right") · rot (-6..6) · ghost (buttons: quiet outline) · mood (null,"lift","zoom" — hover life, image/box only) · tf {"fw":100-900,"ls2":-0.05-0.4,"tt":"uppercase"|null,"lh":0.9-2}.' . "\n" .
		'Section themes (the ONLY way to colour — never invent colours): ' . implode( ', ', $themes ) . '. A bracket is the colour that theme ACTUALLY paints on this site — trust it over the name. Name candidates by what the ops truly do; never promise a colour the palette cannot paint.' . "\n" .
		"Rules: 24+ units of air between elements; everything fits (x+w ≤ 1200); reading order top-to-bottom; " .
		"a section holds 2-8 elements; big type is the cheapest wow; when in doubt remove rather than add.";
	$user = wp_json_encode( array(
		'instruction' => $instruction,
		'section'     => array(
			'minH'  => isset( $section['minH'] ) ? (int) $section['minH'] : null,
			'theme' => isset( $section['theme'] ) ? sanitize_key( (string) $section['theme'] ) : null,
			'els'   => $els,
		),
	) );
	$headers = array(
		'content-type'      => 'application/json',
		'x-api-key'         => $key,
		'anthropic-version' => '2023-06-01',
	);
	$ws = gogh_ask_workspace();
	if ( $ws ) {
		$headers['anthropic-workspace-id'] = $ws;
	}
	$res = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
		'timeout' => 25,
		'headers' => $headers,
		'body'    => wp_json_encode( array(
			'model'      => 'claude-sonnet-5',
			// the model may spend a thinking block before its answer —
			// the budget covers both or the text never arrives
			'max_tokens' => 6000,
			'system'     => $sys,
			'messages'   => array( array( 'role' => 'user', 'content' => $user ) ),
		) ),
	) );
	if ( is_wp_error( $res ) ) {
		// name the transport failure (TLS, DNS, timeout) — never the key
		return new WP_Error( 'gogh_ask_down', sprintf(
			/* translators: %s: transport error detail */
			__( 'The imagination could not be reached — %s', 'gogh-editor' ),
			$res->get_error_message()
		), array( 'status' => 502 ) );
	}
	$code = wp_remote_retrieve_response_code( $res );
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( 401 === $code || 403 === $code ) {
		return new WP_Error( 'gogh_ask_bad_key', __( 'The key was refused — forget it and paste a fresh one.', 'gogh-editor' ), array( 'status' => 502 ) );
	}
	// the answer may sit after a thinking block — take every text block,
	// wherever it lands
	$text = '';
	if ( ! empty( $body['content'] ) && is_array( $body['content'] ) ) {
		foreach ( $body['content'] as $blk ) {
			if ( isset( $blk['type'], $blk['text'] ) && 'text' === $blk['type'] ) {
				$text .= $blk['text'];
			}
		}
	}
	$text = trim( $text );
	if ( 200 !== $code || '' === $text ) {
		$why = isset( $body['error']['message'] ) ? substr( (string) $body['error']['message'], 0, 160 ) : 'HTTP ' . $code;
		if ( 200 === $code ) {
			$why = 'empty answer (' . ( isset( $body['stop_reason'] ) ? $body['stop_reason'] : '?' ) . ': ' .
				implode( ',', array_map( function ( $b2 ) { return isset( $b2['type'] ) ? $b2['type'] : '?'; },
					is_array( $body['content'] ) ? $body['content'] : array() ) ) . ')';
		}
		// an identity-linked key without its workspace gets its own door
		if ( false !== stripos( $why, 'workspace' ) ) {
			return new WP_Error( 'gogh_ask_need_ws', __( 'Your key is workspace-linked — it needs its Workspace ID (starts wrkspc_…, shown beside the key in the console).', 'gogh-editor' ), array( 'status' => 502 ) );
		}
		return new WP_Error( 'gogh_ask_down', sprintf(
			/* translators: %s: upstream error detail */
			__( 'The imagination did not answer — %s', 'gogh-editor' ),
			$why
		), array( 'status' => 502 ) );
	}
	$text = preg_replace( '/^```(?:json)?\s*|\s*```$/', '', $text );
	// a chatty reply still usually carries the JSON — cut to the braces
	$a = strpos( $text, '{' );
	$z = strrpos( $text, '}' );
	if ( false !== $a && false !== $z && $z > $a ) {
		$text = substr( $text, $a, $z - $a + 1 );
	}
	$out = json_decode( $text, true );
	if ( empty( $out['candidates'] ) || ! is_array( $out['candidates'] ) ) {
		return new WP_Error( 'gogh_ask_odd', __( 'The imagination mumbled.', 'gogh-editor' ), array( 'status' => 502 ) );
	}
	// the client re-validates and clamps every field — this is transport,
	// not trust
	return array( 'candidates' => array_slice( array_values( $out['candidates'] ), 0, 3 ) );
}

// ✦ Imagine an experience: one prompt in, one self-contained HTML file
// out — written by the model, saved into the user's OWN media library,
// framed by the sandboxed Experience element. Same key, same workspace,
// same hard-won transport lessons as gogh/v1/ask.
function gogh_imagine_exp_handler( $req ) {
	$key = gogh_ask_key();
	if ( ! $key ) {
		return new WP_Error( 'gogh_ask_no_key', __( 'The imagination tier has no key.', 'gogh-editor' ), array( 'status' => 501 ) );
	}
	$p      = $req->get_json_params();
	$prompt = isset( $p['prompt'] ) ? substr( sanitize_text_field( (string) $p['prompt'] ), 0, 400 ) : '';
	if ( '' === $prompt ) {
		return new WP_Error( 'gogh_exp_bad', __( 'Describe the experience first.', 'gogh-editor' ), array( 'status' => 400 ) );
	}
	// the site's own inks travel along, so "in our brand colours" lands
	$pal     = array();
	$palette = wp_get_global_settings( array( 'color', 'palette' ) );
	foreach ( (array) ( $palette['theme'] ?? array() ) as $c ) {
		if ( isset( $c['slug'], $c['color'] ) ) {
			$pal[] = $c['slug'] . ' ' . $c['color'];
		}
	}
	$sys = 'You write ONE complete, self-contained HTML file: a small interactive or generative "experience" that runs inside a sandboxed iframe on a WordPress page. Rules: ' .
		'look stunning — full creative mode; canvas, SVG and CSS are all yours, motion welcome; ' .
		'ONE file, zero external requests: no CDNs, no web fonts, no remote images, no fetch — everything inline; ' .
		'fill the viewport (html and body at height 100%, margin 0) and adapt to any frame size; ' .
		'respect prefers-reduced-motion with a beautiful still fallback; ' .
		'the frame may report a 0x0 viewport at first paint — size everything from a function that re-runs on the resize event, never once at load; ' .
		'pointer and touch input welcome; sound only if the ask requests it; no alert(), no storage; ' .
		'keep the source under 60KB. ' .
		( $pal ? 'If the ask mentions brand or site colours, the palette is: ' . implode( ', ', array_slice( $pal, 0, 10 ) ) . '. ' : '' ) .
		'Answer with the HTML file ONLY — no fences, no commentary — starting with <!doctype html>.';
	$headers = array(
		'content-type'      => 'application/json',
		'x-api-key'         => $key,
		'anthropic-version' => '2023-06-01',
	);
	$ws = gogh_ask_workspace();
	if ( $ws ) {
		$headers['anthropic-workspace-id'] = $ws;
	}
	if ( function_exists( 'set_time_limit' ) ) {
		set_time_limit( 240 ); // a whole file takes longer than an op list
	}
	$res = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
		'timeout' => 180,
		'headers' => $headers,
		'body'    => wp_json_encode( array(
			'model'      => 'claude-sonnet-5',
			// a whole file, plus any thinking the model spends first
			'max_tokens' => 24000,
			'system'     => $sys,
			'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
		) ),
	) );
	if ( is_wp_error( $res ) ) {
		return new WP_Error( 'gogh_ask_down', sprintf(
			/* translators: %s: transport error detail */
			__( 'The imagination could not be reached — %s', 'gogh-editor' ),
			$res->get_error_message()
		), array( 'status' => 502 ) );
	}
	$code = wp_remote_retrieve_response_code( $res );
	$body = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( 401 === $code || 403 === $code ) {
		return new WP_Error( 'gogh_ask_bad_key', __( 'The key was refused — forget it and paste a fresh one.', 'gogh-editor' ), array( 'status' => 502 ) );
	}
	$text = '';
	if ( ! empty( $body['content'] ) && is_array( $body['content'] ) ) {
		foreach ( $body['content'] as $blk ) {
			if ( isset( $blk['type'], $blk['text'] ) && 'text' === $blk['type'] ) {
				$text .= $blk['text'];
			}
		}
	}
	$text = trim( $text );
	if ( 200 !== $code || '' === $text ) {
		$why = isset( $body['error']['message'] ) ? substr( (string) $body['error']['message'], 0, 160 ) : 'HTTP ' . $code;
		if ( false !== stripos( $why, 'workspace' ) ) {
			return new WP_Error( 'gogh_ask_need_ws', __( 'Your key is workspace-linked — it needs its Workspace ID (starts wrkspc_…, shown beside the key in the console).', 'gogh-editor' ), array( 'status' => 502 ) );
		}
		return new WP_Error( 'gogh_ask_down', sprintf(
			/* translators: %s: upstream error detail */
			__( 'The imagination did not answer — %s', 'gogh-editor' ),
			$why
		), array( 'status' => 502 ) );
	}
	// unwrap fences if the model added them anyway, and cut to the document
	$text = preg_replace( '/^```(?:html)?\s*|\s*```$/', '', $text );
	$a    = stripos( $text, '<!doctype' );
	if ( false === $a ) {
		$a = stripos( $text, '<html' );
	}
	if ( false !== $a ) {
		$text = substr( $text, $a );
	}
	$z = strripos( $text, '</html>' );
	if ( false !== $z ) {
		$text = substr( $text, 0, $z + 7 );
	}
	if ( false === stripos( $text, '<body' ) && false === stripos( $text, '<canvas' ) ) {
		return new WP_Error( 'gogh_exp_odd', __( 'The imagination mumbled — try describing it differently.', 'gogh-editor' ), array( 'status' => 502 ) );
	}
	if ( strlen( $text ) > 400000 ) {
		return new WP_Error( 'gogh_exp_big', __( 'That came out too large — ask for something simpler.', 'gogh-editor' ), array( 'status' => 502 ) );
	}
	// the seatbelt: sandboxed frames can boot at 0x0 before layout sizes
	// them — a tiny injected watcher fires one synthetic resize the moment
	// the viewport is real, so any well-behaved rebuild-on-resize file
	// (the prompt requires one) heals itself
	$seatbelt = '<script>(function(){var n=0,iv=setInterval(function(){if(innerWidth>0&&innerHeight>0){clearInterval(iv);dispatchEvent(new Event("resize"));}else if(++n>600){clearInterval(iv);}},50);})();</script>';
	if ( false !== stripos( $text, '<head>' ) ) {
		$text = preg_replace( '/<head>/i', '<head>' . $seatbelt, $text, 1 );
	} else {
		$text = $seatbelt . $text;
	}
	$slug = sanitize_title( wp_trim_words( $prompt, 6, '' ) );
	$up   = wp_upload_bits( ( $slug ? $slug : 'experience' ) . '.html', null, $text );
	if ( ! empty( $up['error'] ) ) {
		return new WP_Error( 'gogh_exp_save', $up['error'], array( 'status' => 500 ) );
	}
	$att = wp_insert_attachment( array(
		'post_mime_type' => 'text/html',
		'post_title'     => ucwords( wp_trim_words( $prompt, 8 ) ),
		'post_status'    => 'inherit',
	), $up['file'] );
	if ( ! $att || is_wp_error( $att ) ) {
		return new WP_Error( 'gogh_exp_save', __( 'The file could not join the media library.', 'gogh-editor' ), array( 'status' => 500 ) );
	}
	return array(
		'id'    => (int) $att,
		'url'   => $up['url'],
		'title' => get_the_title( $att ),
	);
}

// preview any reading look on any post: ?gogh-look=gazette — CSS-only,
// nothing stored; lets a writer share "how would this read as X" links
// (and lets screenshots be taken without touching the post)
add_filter( 'body_class', function ( $classes ) {
	if ( isset( $_GET['gogh-look'] ) && is_singular() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation-only preview
		$look = sanitize_key( $_GET['gogh-look'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $look, gogh_reading_styles(), true ) && $look ) {
			$classes   = array_diff( $classes, array_map( function ( $s ) { return 'gogh-read-' . $s; }, gogh_reading_styles() ) );
			$classes[] = 'gogh-read-' . $look;
		}
	}
	return $classes;
}, 20 );

add_filter( 'body_class', function ( $classes ) {
	$m = get_option( 'gogh_motion', '' );
	if ( $m && in_array( $m, gogh_motion_styles(), true ) ) {
		$classes[] = 'gogh-motion-' . $m;
	}
	return $classes;
} );

/**
 * ✦ The wow pass — the devices that turn polite looks into publications
 * (research note: scale commitment, type mixing, editorial furniture,
 * image rhythm, asymmetry). The type rule's honest amendment lives in
 * gogh_look_fonts(): a look may borrow a SECOND voice, but only from the
 * font families the theme itself registers — zero downloads, any brand.
 */
function gogh_look_fonts() {
	static $out = null;
	if ( null !== $out ) {
		return $out;
	}
	$list = array();
	$fams = wp_get_global_settings( array( 'typography', 'fontFamilies' ) );
	if ( is_array( $fams ) ) {
		foreach ( array( 'custom', 'theme', 'default' ) as $srcKey ) {
			if ( empty( $fams[ $srcKey ] ) || ! is_array( $fams[ $srcKey ] ) ) {
				continue;
			}
			foreach ( $fams[ $srcKey ] as $f ) {
				if ( ! empty( $f['fontFamily'] ) && ! empty( $f['slug'] ) ) {
					$list[ $f['slug'] ] = $f['fontFamily'];
				}
			}
		}
	}
	// a preset arrives as var:preset|font-family|slug in the stored styles but
	// as var(--wp--preset--font-family--slug) once resolved; reading only the
	// first form left the body unknown, and the 'second voice' became whichever
	// custom font happened to install first (a recipe blog's titles in its body face)
	$slug_of = function ( $v ) {
		return ( is_string( $v ) && preg_match( '/font-family(?:\||--)([a-z0-9-]+)/', $v, $m ) ) ? $m[1] : '';
	};
	$raw  = wp_get_global_styles( array( 'typography', 'fontFamily' ) );
	$bs   = $slug_of( $raw );
	$body = ( $bs && isset( $list[ $bs ] ) ) ? $list[ $bs ] : ( is_string( $raw ) ? $raw : '' );
	if ( '' === $body ) {
		$body = $list ? reset( $list ) : '';
	}
	// the second voice is the face the site's headings wear, when they wear one
	$hs      = $slug_of( wp_get_global_styles( array( 'elements', 'heading', 'typography', 'fontFamily' ) ) );
	$display = ( $hs && isset( $list[ $hs ] ) && $list[ $hs ] !== $body ) ? $list[ $hs ] : '';
	if ( '' === $display ) {
		foreach ( $list as $fam ) {
			if ( $fam !== $body ) {
				$display = $fam;
				break;
			}
		}
	}
	$out = array( 'display' => $display, 'body' => $body );
	return $out;
}

function gogh_reading_wow_css() {
	$lf = gogh_look_fonts();
	// the second voice: only when the theme actually registers one
	$disp = $lf['display'] ? ' font-family: ' . $lf['display'] . ';' : '';
	$rule25 = 'color-mix(in srgb, currentColor 25%, transparent)';
	return
		// ---- shared furniture: the asterism and the end-mark. A rule the
		// writer inserts becomes three quiet sparks; the last paragraph
		// closes with the printer's tombstone. ----
		':is(.gogh-read-magazine, .gogh-read-essay, .gogh-read-feature) .entry-content hr { border: 0; margin-block: 2.6em; text-align: center; overflow: visible; }' .
		':is(.gogh-read-magazine, .gogh-read-essay, .gogh-read-feature) .entry-content hr::before { content: "\2726 \2726 \2726"; letter-spacing: 1.1em; padding-left: 1.1em; font-size: 0.72rem; opacity: 0.45; }' .
		':is(.gogh-read-magazine, .gogh-read-gazette, .gogh-read-feature) .entry-content > p:last-of-type::after { content: " \220E"; font-size: 0.8em; opacity: 0.55; }' .
		// ---- MAGAZINE v2: scale commitment + the second voice + furniture ----
		'.gogh-read-magazine :is(.wp-block-post-title, .gogh-w-title) { font-size: clamp(3.4rem, 8vw, 6rem); font-weight: 800; line-height: 0.98; letter-spacing: -0.02em; max-width: 14ch;' . $disp . ' }' .
		'.gogh-read-magazine :is(.wp-block-post-terms, .wp-block-post-date, .wp-block-post-author-name) { font-size: 0.72rem; letter-spacing: 0.16em; text-transform: uppercase; opacity: 0.75; }' .
		'.gogh-read-magazine .wp-block-post-terms a { text-decoration: none; }' .
		// image rhythm: every second contained image goes full-bleed — never
		// the same treatment twice running; nothing stored, pure nth rhythm
		'.gogh-read-magazine .entry-content > figure.wp-block-image:not(.alignwide):not(.alignfull):nth-of-type(even) { width: 100vw; max-width: 100vw; margin-inline: calc(50% - 50vw); }' .
		'.gogh-read-magazine .entry-content > figure.wp-block-image:not(.alignwide):not(.alignfull):nth-of-type(even) img { width: 100%; max-height: 82vh; object-fit: cover; }' .
		'.gogh-read-magazine .entry-content figure.wp-block-image figcaption { font-variant-caps: all-small-caps; letter-spacing: 0.12em; font-size: 0.86rem; opacity: 0.6; margin-top: 0.9em; }' .
		// ---- ESSAY v2: the italic standfirst is the second voice ----
		'.gogh-read-essay .entry-content > p:first-of-type { font-style: italic; font-size: 1.22em; }' .
		'.gogh-read-essay .entry-content blockquote { position: relative; padding-top: 2.6em; }' .
		'.gogh-read-essay .entry-content blockquote::before { content: "\201C"; position: absolute; top: 0.05em; left: 0.28em; font-size: 3.6em; line-height: 1; opacity: 0.28; }' .
		// ---- GAZETTE v2: the columned intro from the Commons Journal ----
		'@media (min-width: 800px) { .gogh-read-gazette .entry-content > p:first-of-type { columns: 2; column-gap: 2.4em; column-rule: 1px solid ' . $rule25 . '; max-width: 68ch; } }' .
		'.gogh-read-gazette :is(.wp-block-post-title, .gogh-w-title) {' . $disp . ' }' .
		'.gogh-read-gazette .entry-content > h2, .gogh-read-gazette .entry-content > h3 {' . $disp . ' }' .
		// ---- GAZETTE v3: the broadsheet. When the server measures a post
		// short enough to fit without scroll-back (.gogh-short), the WHOLE
		// article runs in newspaper columns — length buys the treatment,
		// because print columns only work when the reader never has to
		// scroll down one column and back up for the next. ----
		'@media (min-width: 900px) {' .
			'.gogh-read-gazette.gogh-short .entry-content { columns: 2; column-gap: 2.8em; column-rule: 1px solid ' . $rule25 . '; max-width: min(1100px, 92vw); margin-inline: auto !important; orphans: 2; widows: 2; }' .
			// inside the broadsheet every child yields the theme's centred
			// constraint and fills its column
			'.gogh-read-gazette.gogh-short .entry-content > * { max-width: none; margin-inline: 0; }' .
			// the v2 columned intro stands down — no columns inside columns
			'.gogh-read-gazette.gogh-short .entry-content > p:first-of-type { columns: auto; column-rule: none; }' .
			'.gogh-read-gazette.gogh-short .entry-content :is(figure, blockquote) { break-inside: avoid; }' .
			'.gogh-read-gazette.gogh-short .entry-content > :is(h2, h3) { break-after: avoid; }' .
			'.gogh-read-gazette.gogh-short .entry-content figure.wp-block-image img { width: 100%; }' .
		'}' .
		'@media (min-width: 1200px) { .gogh-read-gazette.gogh-short .entry-content { columns: 3; } }' .
		// ---- PHOTO STORY v2: statements go big, bleed captions move inside ----
		'.gogh-read-photostory .entry-content > figure.wp-block-image + p { font-size: 1.5em; line-height: 1.35; max-width: 30ch; }' .
		'.gogh-read-photostory :is(.wp-block-post-title, .gogh-w-title) {' . $disp . ' }' .
		'.gogh-read-photostory .entry-content figure.wp-block-image:is(.alignwide, .alignfull) { position: relative; }' .
		'.gogh-read-photostory .entry-content figure.wp-block-image:is(.alignwide, .alignfull) figcaption { position: absolute; left: 26px; bottom: 18px; margin: 0; text-align: left; color: #fff; opacity: 0.94; text-shadow: 0 1px 16px rgba(0, 0, 0, 0.65); font-size: 0.88rem; }' .
		// ---- FEATURE: the committed-asymmetric look. Everything ranges hard
		// left; the title is the loudest thing gogh has ever set; a thin rule
		// runs the content's left edge; images offset right and hang their
		// captions back toward the margin. ----
		'.gogh-read-feature :is(.wp-block-post-title, .gogh-w-title) { font-size: clamp(3.6rem, 10vw, 7rem); font-weight: 800; line-height: 0.95; letter-spacing: -0.03em; text-wrap: balance; text-align: left; width: min(1060px, 94vw); max-width: none; margin-inline: auto;' . $disp . ' }' .
		// the composed canvas: a centred stage, everything ranged left WITHIN
		// it — flushing to the viewport edge opened a huge right void
		'.gogh-read-feature .entry-content { max-width: min(1060px, 94vw); margin-inline: auto !important; }' .
		'.gogh-read-feature main :is(p, .wp-block-group):has(.wp-block-post-author-name, a[href*="/author/"]) { width: min(1060px, 94vw); margin-inline: auto; text-align: left; justify-content: flex-start; }' .
		'.gogh-read-feature :is(.wp-block-post-terms, .wp-block-post-date, .wp-block-post-author-name) { font-size: 0.72rem; letter-spacing: 0.14em; text-transform: uppercase; opacity: 0.7; }' .
		'.gogh-read-feature .entry-content { border-left: 1px solid ' . $rule25 . '; padding-left: clamp(16px, 3vw, 34px); }' .
		'.gogh-read-feature .entry-content > * { margin-left: 0 !important; }' .
		'.gogh-read-feature .entry-content > p { max-width: 58ch; line-height: 1.7; }' .
		'.gogh-read-feature .entry-content > h2, .gogh-read-feature .entry-content > h3 { max-width: 58ch; font-size: 1.05em; letter-spacing: 0.12em; text-transform: uppercase; margin-block-start: 2.6em; }' .
		'.gogh-read-feature .entry-content > figure.wp-block-image:not(.alignfull) { margin-left: auto !important; margin-right: 0; width: min(86%, 720px); }' .
		'.gogh-read-feature .entry-content > figure.wp-block-image:not(.alignfull) img { width: 100%; max-height: 78vh; object-fit: cover; }' .
		'.gogh-read-feature .entry-content figure.wp-block-image figcaption { text-align: left; border-top: 1px solid ' . $rule25 . '; padding-top: 0.6em; margin-top: 0.8em; max-width: 26ch; font-size: 0.84rem; opacity: 0.65; }' .
		'.gogh-read-feature .entry-content blockquote { border: 0; font-size: 1.5em; line-height: 1.3; max-width: 24ch; margin-inline: 0; padding: 0; }';
}

/**
 * ✦ Gogh Forms — simple and elegant, no plugin ("most sites need it").
 * One dynamic block, three fields (name, email, message), a honeypot,
 * and every message stored as the user's OWN data: a private Messages
 * book in wp-admin, plus a note to the site's email. The saved page
 * carries plain block markup — the deactivation promise holds.
 */
add_action( 'init', function () {
	// ---------- Menu panels: the mega menu is a gogh page that drops from an item ----------
	// Designed on the blank canvas like any section; carried by the menu item
	// as a class (gogh-panel-12); rendered into the header at view time.
	register_post_type( 'gogh_panel', array(
		'label'               => __( 'Mega menus', 'gogh-editor' ),
		'labels'              => array( 'name' => __( 'Mega menus', 'gogh-editor' ), 'singular_name' => __( 'Mega menu', 'gogh-editor' ) ),
		'public'              => false,
		'publicly_queryable'  => true,  // the editor works on the panel's own URL (editors only — see below)
		'exclude_from_search' => true,
		'show_ui'             => false,
		'show_in_nav_menus'   => false,
		'show_in_rest'        => true,
		'rest_base'           => 'gogh-panels',
		'rewrite'             => array( 'slug' => 'menu-panel', 'with_front' => false ),
		'supports'            => array( 'title', 'editor', 'revisions', 'custom-fields' ),
		'map_meta_cap'        => true,
		'capability_type'     => 'page',
	) );
	register_post_type( 'gogh_message', array(
		'label'        => __( 'Messages', 'gogh-editor' ),
		'labels'       => array(
			'name'          => __( 'Messages', 'gogh-editor' ),
			'singular_name' => __( 'Message', 'gogh-editor' ),
			// the sidebar wears the FRONT-END name — folks added a contact
			// form, so that is the word they scan for (James's call); the
			// book itself stays Messages, and landing-page sign-ups land
			// here too (one inbox, never two)
			'menu_name'     => __( 'Contact form', 'gogh-editor' ),
			// an empty book says what it is for, not "No posts found"
			'not_found'          => __( 'No messages yet. When someone fills in the contact form on your site, it lands here.', 'gogh-editor' ),
			'not_found_in_trash' => __( 'No messages in the bin.', 'gogh-editor' ),
			'search_items'       => __( 'Search messages', 'gogh-editor' ),
			'all_items'          => __( 'All messages', 'gogh-editor' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'menu_icon'    => 'dashicons-email',
		'supports'     => array( 'title', 'editor' ),
		'capabilities' => array( 'create_posts' => 'do_not_allow' ), // messages arrive, they are not authored
		'map_meta_cap' => true,
	) );
	register_block_type( 'gogh/form', array(
		'api_version'     => 3,
		'title'           => __( 'Form', 'gogh-editor' ),
		'render_callback' => 'gogh_form_render',
		'attributes'      => array(
			'heading' => array( 'type' => 'string', 'default' => '' ),
			'button'  => array( 'type' => 'string', 'default' => '' ),
		),
	) );
} );
// the panel's pretty URL (menu-panel/…) needs its rewrite rule, and a fresh
// install has none until something flushes: the mega menu button then lands
// on WordPress's 404 guess — the PAGE with the nearest slug (Playground
// showed it: "Collection" opened the Collection page, not the panel). Flush
// once per plugin version, after every post type above is registered.
add_action( 'init', function () {
	if ( get_option( 'gogh_rewrite_stamp' ) !== GOGH_VERSION ) {
		flush_rewrite_rules( false );
		update_option( 'gogh_rewrite_stamp', GOGH_VERSION, false );
	}
}, 99 );

// the Messages list answers at a glance: who, how to reply, from where
add_filter( 'manage_gogh_message_posts_columns', function ( $cols ) {
	return array(
		'cb'       => isset( $cols['cb'] ) ? $cols['cb'] : '<input type="checkbox" />',
		'title'    => __( 'From', 'gogh-editor' ),
		'msg_mail' => __( 'Email', 'gogh-editor' ),
		'msg_body' => __( 'Message', 'gogh-editor' ),
		'msg_page' => __( 'From page', 'gogh-editor' ),
		'date'     => __( 'When', 'gogh-editor' ),
	);
} );
add_action( 'manage_gogh_message_posts_custom_column', function ( $col, $post_id ) {
	if ( 'msg_mail' === $col ) {
		$em = get_post_meta( $post_id, '_gogh_msg_email', true );
		echo $em ? '<a href="mailto:' . esc_attr( $em ) . '">' . esc_html( $em ) . '</a>' : '—';
	} elseif ( 'msg_body' === $col ) {
		if ( 'signup' === get_post_meta( $post_id, '_gogh_msg_kind', true ) ) {
			$utm = get_post_meta( $post_id, '_gogh_msg_utm', true );
			echo '<em>' . esc_html__( 'Sign-up', 'gogh-editor' ) . ( $utm ? ' · ' . esc_html( $utm ) : '' ) . '</em>';
		} else {
			echo esc_html( wp_trim_words( get_post_field( 'post_content', $post_id ), 16, '…' ) );
		}
	} elseif ( 'msg_page' === $col ) {
		$pid = (int) get_post_meta( $post_id, '_gogh_msg_page', true );
		if ( $pid && get_post( $pid ) ) {
			echo '<a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a>';
		}
	}
}, 10, 2 );

// ---------- reading the mail ----------
// a message is READ, not edited — clicking one opens a letter, never an
// Edit Post screen with an Update button (James: "i cant read the
// messages"). The row's Edit verb becomes Read; the letter offers a
// mailto reply and a way back.
add_filter( 'get_edit_post_link', function ( $link, $post_id ) {
	$post = get_post( $post_id );
	if ( $post && 'gogh_message' === $post->post_type && current_user_can( 'edit_post', $post->ID ) ) {
		return admin_url( 'admin.php?page=gogh-message-read&msg=' . $post->ID );
	}
	return $link;
}, 10, 2 );
add_filter( 'post_row_actions', function ( $actions, $post ) {
	if ( 'gogh_message' === $post->post_type && isset( $actions['edit'] ) ) {
		$actions['edit'] = '<a href="' . esc_url( admin_url( 'admin.php?page=gogh-message-read&msg=' . $post->ID ) ) . '">' .
			esc_html__( 'Read', 'gogh-editor' ) . '</a>';
	}
	return $actions;
}, 10, 2 );
add_action( 'admin_menu', function () {
	add_submenu_page( '', __( 'Read message', 'gogh-editor' ), '', 'edit_posts', 'gogh-message-read', function () {
		$msg = get_post( absint( isset( $_GET['msg'] ) ? $_GET['msg'] : 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view, capability-checked below
		if ( ! $msg || 'gogh_message' !== $msg->post_type || ! current_user_can( 'edit_post', $msg->ID ) ) {
			wp_die( esc_html__( 'That message is not here any more.', 'gogh-editor' ) );
		}
		$email  = get_post_meta( $msg->ID, '_gogh_msg_email', true );
		$pid    = (int) get_post_meta( $msg->ID, '_gogh_msg_page', true );
		$utm    = get_post_meta( $msg->ID, '_gogh_msg_utm', true );
		$signup = 'signup' === get_post_meta( $msg->ID, '_gogh_msg_kind', true );
		echo '<div class="wrap" style="max-width:680px">';
		echo '<p style="margin:18px 0 6px"><a href="' . esc_url( admin_url( 'edit.php?post_type=gogh_message' ) ) . '">&larr; ' . esc_html__( 'All messages', 'gogh-editor' ) . '</a></p>';
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:28px 32px;box-shadow:0 1px 2px rgba(0,0,0,.04)">';
		echo '<h1 style="margin:0 0 2px;font-size:26px">' . esc_html( get_the_title( $msg ) ) . '</h1>';
		echo '<p style="margin:0 0 18px;color:#646970">';
		echo esc_html( $signup ? __( 'Signed up', 'gogh-editor' ) : __( 'Wrote', 'gogh-editor' ) ) . ' ' . esc_html( human_time_diff( get_post_time( 'U', true, $msg ), time() ) ) . ' ' . esc_html__( 'ago', 'gogh-editor' );
		if ( $pid && get_post( $pid ) ) {
			echo ' &middot; ' . esc_html__( 'from', 'gogh-editor' ) . ' <a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a>';
		}
		if ( $utm ) {
			echo ' &middot; ' . esc_html( $utm );
		}
		echo '</p>';
		if ( '' !== trim( (string) $msg->post_content ) ) {
			echo '<div style="font-size:15px;line-height:1.7;white-space:pre-line;border-top:1px solid #f0f0f1;padding-top:18px">' . esc_html( $msg->post_content ) . '</div>';
		} else {
			echo '<p style="color:#646970;font-style:italic;border-top:1px solid #f0f0f1;padding-top:18px;margin:0">' . esc_html__( 'A sign-up — no message, just the hand raised.', 'gogh-editor' ) . '</p>';
		}
		echo '<p style="margin:24px 0 0;display:flex;gap:14px;align-items:center">';
		if ( $email ) {
			echo '<a class="button button-primary" href="mailto:' . esc_attr( $email ) . '">' . esc_html__( 'Reply by email', 'gogh-editor' ) . '</a>';
			echo '<span style="color:#646970">' . esc_html( $email ) . '</span>';
		}
		echo '<a style="margin-left:auto;color:#b32d2e" href="' . esc_url( get_delete_post_link( $msg->ID ) ) . '">' . esc_html__( 'Trash', 'gogh-editor' ) . '</a>';
		echo '</p></div></div>';
	} );
} );
// the book walks out as a spreadsheet — one link, one CSV
add_filter( 'views_edit-gogh_message', function ( $views ) {
	$views['gogh_csv'] = '<a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=gogh_messages_csv' ), 'gogh_messages_csv' ) ) . '">' .
		esc_html__( 'Export CSV', 'gogh-editor' ) . '</a>';
	return $views;
} );
add_action( 'admin_post_gogh_messages_csv', function () {
	if ( ! current_user_can( 'edit_others_posts' ) || ! wp_verify_nonce( sanitize_key( isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '' ), 'gogh_messages_csv' ) ) {
		wp_die( esc_html__( 'That export link has expired — open the Contact form book and try again.', 'gogh-editor' ) );
	}
	$rows = get_posts( array(
		'post_type'      => 'gogh_message',
		'post_status'    => 'private',
		'posts_per_page' => -1,
		'orderby'        => 'date',
		'order'          => 'DESC',
	) );
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=messages-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array( 'Date', 'Name', 'Email', 'Kind', 'Message', 'Page', 'Campaign' ) );
	foreach ( $rows as $r ) {
		$pid = (int) get_post_meta( $r->ID, '_gogh_msg_page', true );
		fputcsv( $out, array(
			get_post_time( 'Y-m-d H:i', false, $r ),
			get_the_title( $r ),
			get_post_meta( $r->ID, '_gogh_msg_email', true ),
			'signup' === get_post_meta( $r->ID, '_gogh_msg_kind', true ) ? 'Sign-up' : 'Message',
			$r->post_content,
			$pid ? get_the_title( $pid ) : '',
			get_post_meta( $r->ID, '_gogh_msg_utm', true ),
		) );
	}
	exit;
} );

function gogh_form_render( $attrs ) {
	$heading = trim( (string) ( isset( $attrs['heading'] ) ? $attrs['heading'] : '' ) );
	$button  = trim( (string) ( isset( $attrs['button'] ) ? $attrs['button'] : '' ) );
	if ( '' === $button ) {
		$button = __( 'Send', 'gogh-editor' );
	}
	$thanks = isset( $_GET['gogh-thanks'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display state only
	$out    = '<div class="gogh-form" id="gogh-form"' .
		' data-thanks="' . esc_attr__( 'Thank you — your message is on its way.', 'gogh-editor' ) . '"' .
		/* translators: %s: the sender's first name */
		' data-thanks-name="' . esc_attr__( 'Thanks, %s. Your message is on its way.', 'gogh-editor' ) . '"' .
		' data-fail="' . esc_attr__( 'That did not send. Please try again.', 'gogh-editor' ) . '">';
	if ( '' !== $heading ) {
		$out .= '<p class="gogh-form-heading">' . esc_html( $heading ) . '</p>';
	}
	if ( $thanks ) {
		$out .= '<p class="gogh-form-thanks">' . esc_html__( 'Thank you — your message is on its way.', 'gogh-editor' ) . '</p></div>';
		return $out;
	}
	$out .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' .
		'<input type="hidden" name="action" value="gogh_form_message" />' .
		wp_nonce_field( 'gogh_form_message', '_gogh_form', true, false ) .
		'<input type="hidden" name="fm_page" value="' . esc_attr( get_the_ID() ) . '" />' .
		// the honeypot: humans never see it, bots always fill it
		'<input type="text" name="fm_website" class="gogh-form-hp" tabindex="-1" autocomplete="off" aria-hidden="true" />' .
		'<div class="gogh-form-row">' .
		'<input type="text" name="fm_name" required placeholder="' . esc_attr__( 'Your name', 'gogh-editor' ) . '" />' .
		'<input type="email" name="fm_email" required placeholder="' . esc_attr__( 'Your email', 'gogh-editor' ) . '" />' .
		'</div>' .
		'<textarea name="fm_message" required rows="5" placeholder="' . esc_attr__( 'Your message…', 'gogh-editor' ) . '"></textarea>' .
		'<div class="gogh-form-foot"><button type="submit" data-sending="' . esc_attr__( 'Sending…', 'gogh-editor' ) . '">' . esc_html( $button ) . '</button>' .
		'<span class="gogh-form-note">' . esc_html__( 'Goes straight to this site — nowhere else.', 'gogh-editor' ) . '</span></div>' .
		'</form></div>';
	// the send happens in place: no round trip through admin-post and back,
	// no page flicker — the form fades into its thank-you where it stands.
	// Without JavaScript the plain POST and the redirect still work. (The
	// hidden field named "action" shadows form.action, so the script reads
	// the attribute.)
	static $script = false;
	if ( ! $script ) {
		$script = true;
		$out   .= '<script>' . gogh_form_js() . '</script>';
	}
	return $out;
}

function gogh_form_js() {
	return "(function(){if(window.__goghForm)return;window.__goghForm=1;" .
		"document.addEventListener('submit',function(ev){var f=ev.target;if(!f||!f.closest||!f.closest('.gogh-form')||!window.fetch||!window.FormData)return;" .
		"ev.preventDefault();var box=f.closest('.gogh-form'),btn=f.querySelector('button[type=submit]');var fd=new FormData(f);fd.append('fm_async','1');" .
		"var was=btn.textContent;btn.disabled=true;btn.textContent=btn.getAttribute('data-sending')||was;" .
		"box.querySelectorAll('.gogh-form-error').forEach(function(n){n.remove();});" .
		"fetch(f.getAttribute('action'),{method:'POST',body:fd,credentials:'same-origin',headers:{'Accept':'application/json'}})" .
		".then(function(r){return r.json().catch(function(){return{ok:r.ok};});})" .
		".then(function(j){if(!j||!j.ok)throw new Error((j&&j.error)||'');" .
		"var p=document.createElement('p');p.className='gogh-form-thanks';var name=String(fd.get('fm_name')||'').trim().split(/\\s+/)[0];" .
		"p.textContent=name?(box.getAttribute('data-thanks-name')||'%s').replace('%s',name):(box.getAttribute('data-thanks')||'');" .
		"f.replaceWith(p);})" .
		".catch(function(e){btn.disabled=false;btn.textContent=was;var p=document.createElement('p');p.className='gogh-form-error';" .
		"p.textContent=(e&&e.message)||box.getAttribute('data-fail')||'';f.appendChild(p);});});})();";
}

function gogh_form_handle_message() {
	// sent in place by the page's script: answer with JSON, no redirect
	$async = ! empty( $_POST['fm_async'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- the nonce is checked next
	if ( ! isset( $_POST['_gogh_form'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_gogh_form'] ), 'gogh_form_message' ) ) {
		if ( $async ) {
			wp_send_json( array( 'ok' => false, 'error' => __( 'That form has expired — reload the page and try again.', 'gogh-editor' ) ), 403 );
		}
		wp_die( esc_html__( 'That form has expired — please go back and try again.', 'gogh-editor' ) );
	}
	$back = wp_get_referer() ? remove_query_arg( 'gogh-thanks', wp_get_referer() ) : home_url( '/' );
	if ( ! empty( $_POST['fm_website'] ) ) { // the honeypot caught something
		if ( $async ) {
			wp_send_json( array( 'ok' => true ) );
		}
		wp_safe_redirect( add_query_arg( 'gogh-thanks', '1', $back ) . '#gogh-form' );
		exit;
	}
	$email = sanitize_email( wp_unslash( isset( $_POST['fm_email'] ) ? $_POST['fm_email'] : '' ) );
	$msg   = sanitize_textarea_field( wp_unslash( isset( $_POST['fm_message'] ) ? $_POST['fm_message'] : '' ) );
	if ( ! is_email( $email ) || '' === trim( $msg ) ) {
		if ( $async ) {
			wp_send_json( array( 'ok' => false, 'error' => __( 'The email or message did not look right.', 'gogh-editor' ) ), 400 );
		}
		wp_die( esc_html__( 'The email or message did not look right — please go back and try again.', 'gogh-editor' ) );
	}
	$name = sanitize_text_field( wp_unslash( isset( $_POST['fm_name'] ) ? $_POST['fm_name'] : '' ) );
	$page = absint( isset( $_POST['fm_page'] ) ? $_POST['fm_page'] : 0 );
	$id   = wp_insert_post( array(
		'post_type'    => 'gogh_message',
		'post_status'  => 'private',
		'post_title'   => $name ? $name : $email,
		'post_content' => $msg,
	) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_gogh_msg_email', $email );
		update_post_meta( $id, '_gogh_msg_page', $page );
		wp_mail(
			get_option( 'admin_email' ),
			sprintf( /* translators: %s: site name */ __( 'New message on %s', 'gogh-editor' ), get_bloginfo( 'name' ) ),
			sprintf( "%s <%s>\n\n%s\n\n%s", $name, $email, $msg, $page ? get_permalink( $page ) : '' )
		);
	}
	if ( $async ) {
		wp_send_json( array( 'ok' => true ) );
	}
	wp_safe_redirect( add_query_arg( 'gogh-thanks', '1', $back ) . '#gogh-form' );
	exit;
}
add_action( 'admin_post_gogh_form_message', 'gogh_form_handle_message' );
add_action( 'admin_post_nopriv_gogh_form_message', 'gogh_form_handle_message' );

// the form wears the theme: inputs inked from currentColor, the button
// from the palette's contrast — composes with any site style
function gogh_form_css() {
	return
		'.gogh-form { width: 100%; }' .
		'.gogh-form-heading { font-weight: 650; margin: 0 0 0.8em; }' .
		'.gogh-form-row { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }' .
		'.gogh-form-row input { flex: 1 1 180px; min-width: 0; }' .
		'.gogh-form input, .gogh-form textarea { box-sizing: border-box; padding: 0.85em 1em; border-radius: 10px; border: 1.5px solid color-mix(in srgb, currentColor 30%, transparent); background: color-mix(in srgb, var(--wp--preset--color--base, #fff) 85%, transparent); color: inherit; font: inherit; }' .
		'.gogh-form textarea { width: 100%; resize: vertical; }' .
		'.gogh-form ::placeholder { color: color-mix(in srgb, currentColor 55%, transparent); }' .
		'.gogh-form-foot { display: flex; align-items: center; gap: 14px; margin-top: 12px; flex-wrap: wrap; }' .
		'.gogh-form-foot button { padding: 0.85em 1.8em; border: 0; border-radius: 10px; font: inherit; font-weight: 650; cursor: pointer; background: var(--wp--preset--color--contrast, #16181c); color: var(--wp--preset--color--base, #fff); }' .
		'.gogh-form-foot button:hover { filter: brightness(1.12); }' .
		'.gogh-form-foot .gogh-form-fbtn { padding: 0.85em 1.8em; border-radius: 10px; font-weight: 650; background: var(--wp--preset--color--contrast, #16181c); color: var(--wp--preset--color--base, #fff); }' .
		'.gogh-form-note { font-size: 0.82em; opacity: 0.6; }' .
		'.gogh-form-thanks { font-weight: 650; margin: 0; animation: gogh-form-in 0.45s ease; }' .
		'.gogh-form-thanks::before { content: "\\2713"; display: inline-block; width: 1.5em; height: 1.5em; line-height: 1.5em; text-align: center; border-radius: 50%; margin-right: 0.5em; font-size: 0.85em; background: var(--wp--preset--color--contrast, #16181c); color: var(--wp--preset--color--base, #fff); }' .
		'@keyframes gogh-form-in { from { opacity: 0; transform: translateY(8px); } }' .
		'@media (prefers-reduced-motion: reduce) { .gogh-form-thanks { animation: none; } }' .
		'.gogh-form-foot button:disabled { opacity: 0.7; cursor: default; }' .
		'.gogh-form-error { margin: 10px 0 0; font-size: 0.9em; color: #b3261e; }' .
		'.gogh-form-hp { position: absolute !important; left: -9999px !important; width: 1px; height: 1px; opacity: 0; }' .
		'@media (max-width: 560px) { .gogh-form-row { flex-direction: column; } .gogh-form-foot button { width: 100%; } }';
}
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'gogh-form', false, array(), null );
	wp_enqueue_style( 'gogh-form' );
	wp_add_inline_style( 'gogh-form', gogh_form_css() );
} );

/**
 * The menu behind the ☰ — WordPress's default overlay is a blank white
 * sheet with small links in a corner. If gogh offers the hamburger as a
 * layout, the moment after the tap must be designed (James: "make this
 * look beautiful"): the theme's own ground and ink, big centred type, a
 * soft round close, and a staggered arrival. Theme-adaptive throughout —
 * presets only, so it re-dresses with the site style. The same overlay
 * folds the phone menu on every header, so phones get it too.
 */
// ---------- mobile menu style: one site-wide choice, layout + ground ----------
// (James: "it would be cool to have a few different style options for the
// mobile menu"). Stored as one option; worn as two body classes so the
// editor can audition by swapping classes and the CSS below is the same
// stylesheet for editing and for visitors.
// ---------- a header keeps its menu across an export and import ----------
// core's navigation block refers to its menu by post ID. An import gives
// every post a new ID, so the header points at nothing and WordPress draws
// its automatic page list instead: every page, alphabetical, the ones kept
// out of the menu included (Ben's imported photographer). When a reference
// is dead, or lands on a post that is not a menu, the block is pointed at
// the menu the site has — the most recently changed one if there are
// several, the menu manager's own reading of "the menu". Render-time only:
// nothing is rewritten, the site editor still shows what is stored
add_filter( 'render_block_data', function ( $parsed ) {
	if ( ! isset( $parsed['blockName'] ) || 'core/navigation' !== $parsed['blockName'] ) {
		return $parsed;
	}
	$ref = isset( $parsed['attrs']['ref'] ) ? (int) $parsed['attrs']['ref'] : 0;
	if ( $ref <= 0 ) {
		return $parsed; // no reference at all: core's own fallback knows what to do
	}
	$menu = get_post( $ref );
	if ( $menu && 'wp_navigation' === $menu->post_type && 'publish' === $menu->post_status ) {
		return $parsed;
	}
	static $fallback = null;
	if ( null === $fallback ) {
		$found    = get_posts( array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'orderby' => 'modified', 'order' => 'DESC' ) );
		$fallback = $found ? (int) $found[0] : 0;
	}
	if ( $fallback > 0 ) {
		$parsed['attrs']['ref'] = $fallback;
	}
	return $parsed;
} );
function gogh_menu_style() {
	$o = get_option( 'gogh_menu_style', array() );
	$layouts = array( 'stack', 'centred', 'drawer', 'sheet' );
	$grounds = array( 'light', 'dark', 'brand' );
	$layout  = isset( $o['layout'] ) && in_array( $o['layout'], $layouts, true ) ? $o['layout'] : 'stack';
	$ground  = isset( $o['ground'] ) && in_array( $o['ground'], $grounds, true ) ? $o['ground'] : 'light';
	// what phones want at the foot of the menu, and (rarely) a menu of their own
	$phone_menu = isset( $o['phoneMenu'] ) ? (int) $o['phoneMenu'] : 0;
	if ( $phone_menu && 'wp_navigation' !== get_post_type( $phone_menu ) ) {
		$phone_menu = 0;
	}
	return array(
		'layout'    => $layout,
		'ground'    => $ground,
		'phone'     => isset( $o['phone'] ) ? sanitize_text_field( $o['phone'] ) : '',
		'email'     => isset( $o['email'] ) && is_email( $o['email'] ) ? sanitize_email( $o['email'] ) : '',
		'account'   => ! empty( $o['account'] ),
		'phoneMenu' => $phone_menu,
	);
}
add_filter( 'body_class', function ( $classes ) {
	$ms        = gogh_menu_style();
	$classes[] = 'gogh-mm-' . $ms['layout'];
	$classes[] = 'gogh-mmg-' . $ms['ground'];
	if ( $ms['phoneMenu'] ) {
		$classes[] = 'gogh-mm-hasphone';
	}
	return $classes;
} );
function gogh_menu_style_css() {
	$open = '.wp-block-navigation__responsive-container.is-menu-open';
	return
		// GROUNDS — body + class outranks the base rule's own !important
		'body.gogh-mmg-dark ' . $open . ' { background: var(--wp--preset--color--contrast, #141519) !important; color: var(--wp--preset--color--base, #fff) !important; }' .
		'body.gogh-mmg-dark ' . $open . ' .wp-block-navigation-item__content, body.gogh-mmg-dark ' . $open . ' .wp-block-navigation__responsive-container-close { color: inherit !important; }' .
		'body.gogh-mmg-brand ' . $open . ' { background: var(--wp--preset--color--primary, var(--wp--preset--color--accent, var(--wp--preset--color--accent-1, var(--wp--preset--color--main-accent, var(--wp--preset--color--primary-accent, var(--wp--preset--color--secondary, var(--wp--preset--color--contrast, #141519))))))) !important; color: var(--wp--preset--color--base, #fff) !important; }' .
		'body.gogh-mmg-brand ' . $open . ' .wp-block-navigation-item__content, body.gogh-mmg-brand ' . $open . ' .wp-block-navigation__responsive-container-close { color: inherit !important; }' .
		// CENTRED — every line centred on its own axis, not a left column parked mid-page
		// STACK — big type, left-aligned. It had no rule of its own and inherited
		// the header menu's alignment, so on a centred header it looked exactly
		// like Centred (James: 'whats the difference between stack and centered?')
		'body.gogh-mm-stack ' . $open . ' .wp-block-navigation__responsive-container-content { align-items: flex-start !important; }' .
		'body.gogh-mm-stack ' . $open . ' .wp-block-navigation__container { align-items: flex-start !important; text-align: left !important; }' .
		'body.gogh-mm-stack ' . $open . ' .wp-block-navigation-item { justify-content: flex-start; text-align: left; }' .
		'body.gogh-mm-centred ' . $open . ' .wp-block-navigation__container { align-items: center !important; }' .
		'body.gogh-mm-centred ' . $open . ' .wp-block-navigation-item { justify-content: center; text-align: center; }' .
		// DRAWER — slides in from the right, reads top-down like a list
		'body.gogh-mm-drawer ' . $open . ' { inset: 0 0 0 auto !important; left: auto !important; width: min(440px, 88%) !important; box-shadow: -24px 0 60px rgba(0,0,0,0.22); animation: gogh-menu-drawer 0.36s cubic-bezier(.2,.7,.2,1) both !important; padding-top: clamp(72px, 12vh, 120px) !important; }' .
		'body.gogh-mm-drawer ' . $open . ' .wp-block-navigation__responsive-container-content { align-items: flex-start !important; justify-content: flex-start !important; }' .
		'body.gogh-mm-drawer ' . $open . ' .wp-block-navigation__container { align-items: flex-start !important; text-align: left !important; gap: clamp(8px, 1.6vh, 18px) !important; }' .
		'body.gogh-mm-drawer ' . $open . ' .wp-block-navigation-item__content { font-size: clamp(22px, 3.6vw, 34px) !important; }' .
		// SHEET — rises from the bottom, rounded shoulders, the page still visible above
		'body.gogh-mm-sheet ' . $open . ' { inset: auto 0 0 0 !important; top: auto !important; height: auto !important; max-height: 82vh !important; border-radius: 28px 28px 0 0 !important; box-shadow: 0 -24px 60px rgba(0,0,0,0.22); animation: gogh-menu-sheet 0.4s cubic-bezier(.2,.7,.2,1) both !important; padding: clamp(28px, 5vh, 48px) clamp(24px, 6%, 64px) clamp(36px, 6vh, 64px) !important; }' .
		'body.gogh-mm-sheet ' . $open . '::before { content: ""; position: absolute; top: 12px; left: 50%; width: 44px; height: 5px; border-radius: 999px; background: currentColor; opacity: 0.28; transform: translateX(-50%); }' .
		'body.gogh-mm-sheet ' . $open . ' .wp-block-navigation__responsive-container-content { align-items: center !important; justify-content: flex-start !important; }' .
		'body.gogh-mm-sheet ' . $open . ' .wp-block-navigation__container { align-items: center !important; text-align: center !important; gap: clamp(8px, 1.6vh, 18px) !important; }' .
		'body.gogh-mm-sheet ' . $open . ' .wp-block-navigation-item { justify-content: center; }' .
		'body.gogh-mm-sheet ' . $open . ' .wp-block-navigation-item__content { font-size: clamp(22px, 3.6vw, 36px) !important; }' .
		'@keyframes gogh-menu-drawer { from { transform: translateX(100%); } to { transform: none; } }' .
		'@keyframes gogh-menu-sheet { from { transform: translateY(100%); } to { transform: none; } }' .
		'@media (prefers-reduced-motion: reduce) { body.gogh-mm-drawer ' . $open . ', body.gogh-mm-sheet ' . $open . ' { animation: none !important; } }';
}
// ---------- the header's dressing, on EVERY front-end page ----------
// These rules lived in gogh-base, which only loads on singular gogh pages —
// so the shop archive, cart, checkout and the blog index wore a broken
// header (James: 'header broken on shop page'). A header is site-wide.
/**
 * Outline (ghost) buttons wear the site's accent for outline and words when
 * that accent reads on the page as text (4.5:1); otherwise they keep the
 * words colour. Read from the palette the site is wearing now — the brand,
 * or a Remix roll — so it follows every look.
 */
function gogh_hex_lum( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( ! preg_match( '/^[0-9a-f]{6}$/i', $hex ) ) {
		return null;
	}
	$out = array();
	foreach ( array( 0, 2, 4 ) as $i ) {
		$v     = hexdec( substr( $hex, $i, 2 ) ) / 255;
		$out[] = $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
	}
	return 0.2126 * $out[0] + 0.7152 * $out[1] + 0.0722 * $out[2];
}
function gogh_ghost_ink_css() {
	if ( ! function_exists( 'wp_get_global_settings' ) ) {
		return '';
	}
	$pal = wp_get_global_settings( array( 'color', 'palette' ) );
	$pal = is_array( $pal ) ? ( isset( $pal['theme'] ) ? $pal['theme'] : ( isset( $pal['default'] ) ? $pal['default'] : array() ) ) : array();
	$accent = null;
	$page   = null;
	$lightest = null;
	foreach ( (array) $pal as $p ) {
		if ( empty( $p['slug'] ) || empty( $p['color'] ) ) {
			continue;
		}
		$lum = gogh_hex_lum( $p['color'] );
		if ( null === $lum ) {
			continue;
		}
		if ( null === $accent && preg_match( '/^(accent(-1)?|primary|primary-accent)$/', $p['slug'] ) ) {
			$accent = $p['color'];
		}
		if ( 'base' === $p['slug'] || 'background' === $p['slug'] ) {
			$page = $p['color'];
		}
		if ( null === $lightest || $lum > $lightest[1] ) {
			$lightest = array( $p['color'], $lum );
		}
	}
	if ( null === $page && $lightest ) {
		$page = $lightest[0];
	}
	if ( ! $accent || ! $page ) {
		return '';
	}
	$a = gogh_hex_lum( $accent );
	$b = gogh_hex_lum( $page );
	if ( null === $a || null === $b ) {
		return '';
	}
	$ratio = ( max( $a, $b ) + 0.05 ) / ( min( $a, $b ) + 0.05 );
	return $ratio >= 4.5 ? ':root{--gogh-ghost-ink:' . esc_attr( $accent ) . ';}' : '';
}
function gogh_chrome_css() {
	return
		'header.wp-block-template-part:not(:has(.gogh-chrome-preview)):has(.gogh-header-overlay), header.wp-block-template-part:has(.gogh-chrome-preview .gogh-header-overlay) { position: absolute; top: var(--wp-admin--admin-bar--height, 0px); left: 0; right: 0; z-index: 40; background: transparent; }' .
		// no automatic scrim: transparent means TRANSPARENT ("transparent not
		// transparent" — over a pale hero the helpful gradient read as a grey
		// smear). The Look row's custom colour + see-through dial is the
		// scrim now, on demand, in the user's own colour.

		// the row declares its text colour; links inherit it — element-level
		// link CSS does not survive every render context (REST previews)
		'.gogh-hrow.has-text-color a, .gogh-hrow.has-text-color .wp-block-navigation-item__content, .gogh-hrow.has-text-color .wp-block-navigation { color: inherit !important; }' .
		'#wpadminbar .gogh-ab-ic { display: inline-block; vertical-align: -2px; margin-right: 7px; }' .
		// Edit as a solid white button while viewing (the way in); View site
		// stays a plain bar link while editing (the way out, same spot). A
		// little air on its left: WooCommerce's Live / Coming soon badge sits
		// right before it and the two touched (James, 2026-09-22)
		'#wpadminbar #wp-admin-bar-gogh-edit.gogh-ab-solid { display: flex; align-items: center; height: 32px; margin-left: 4px; } #wpadminbar #wp-admin-bar-gogh-edit.gogh-ab-solid > .ab-item { height: 24px; line-height: 24px; padding: 0 12px; border-radius: 5px; background: #fff; color: #1d2327; font-weight: 700; } #wpadminbar #wp-admin-bar-gogh-edit.gogh-ab-solid:hover > .ab-item, #wpadminbar #wp-admin-bar-gogh-edit.gogh-ab-solid > .ab-item:focus { background: #eceef2; color: #1d2327; }' .
		// the phone, desktop and brush in the bar: icons, named on hover
		'#wpadminbar #wp-admin-bar-gogh-style { display: flex; align-items: center; height: 32px; float: left; } #wpadminbar #wp-admin-bar-gogh-style > .ab-item { height: 26px; padding: 0 10px 0 8px; display: inline-flex; align-items: center; gap: 6px; border-radius: 6px; color: rgba(255,255,255,0.86); font: 600 12.5px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif; } #wpadminbar #wp-admin-bar-gogh-style > .ab-item:hover, #wpadminbar #wp-admin-bar-gogh-style > .ab-item:focus { background: rgba(255,255,255,0.14); color: #fff; } #wpadminbar #wp-admin-bar-gogh-style .gogh-ab-ic { margin: 0; width: 16px; height: 16px; vertical-align: 0; } #wpadminbar #wp-admin-bar-gogh-style .gogh-stylebar-word { line-height: 1; }' .
		// the ? beside Howdy: an icon alone, no word (the tooltip says it)
		'#wpadminbar #wp-admin-bar-gogh-help > .ab-item { padding: 0 9px; } #wpadminbar #wp-admin-bar-gogh-help .gogh-ab-ic { margin-right: 0; vertical-align: -3px; width: 15px; height: 15px; }' .
		// when gogh sizes the nav, the links FOLLOW — theme rules on the
		// anchors otherwise out-rank the container's size
		'.wp-block-navigation[style*="font-size"] a { font-size: inherit; }' .
		// a real logo makes the text title redundant — one identity, not two
		// one identity, not two: a real logo image hides the redundant text
		// title — scoped to the whole header part, because some layouts
		// (Centred) don't wear .gogh-hrow and showed BOTH ("two logos")
		'header.wp-block-template-part:has(.wp-block-site-logo img) .wp-block-site-title, .gogh-hrow:has(.wp-block-site-logo img) .wp-block-site-title { display: none; }' .
		// sticky pins the HEADER ELEMENT (the inner group has zero travel);
		// theme-independent, admin-bar aware
		'header.wp-block-template-part:not(:has(.gogh-chrome-preview)):has(.gogh-sticky), header.wp-block-template-part:has(.gogh-chrome-preview .gogh-sticky) { position: sticky; top: var(--wp-admin--admin-bar--height, 0px); z-index: 90; }' .
		// transparent AND sticky: sticky alone keeps its flow space (the
		// grey band that hid the float through three bug reports) — fixed
		// floats over the hero AND stays through the scroll
		'header.wp-block-template-part:not(:has(.gogh-chrome-preview)):has(.gogh-header-overlay):has(.gogh-sticky), header.wp-block-template-part:has(.gogh-chrome-preview .gogh-header-overlay):has(.gogh-chrome-preview .gogh-sticky) { position: fixed; top: var(--wp-admin--admin-bar--height, 0px); left: 0; right: 0; z-index: 90; }' .
		// WooCommerce block-hooks append cart/account icons after the nav in
		// every header — give them a deliberate seat instead of a random one:
		// nav pushes right, icons tuck in beside it, stacks stay centred
		// a solid pinned bar needs an edge, or the page appears to slide
		// out of nowhere underneath it
		'.gogh-hsolid { border-bottom: 1px solid color-mix(in srgb, currentColor 12%, transparent); }' .
		'.gogh-hrow { align-items: center; gap: 1.1rem; }' .
		'.gogh-hrow:not(.gogh-hstack) > .wp-block-navigation { margin-left: auto; }' .
		'.gogh-hrow > [class*="mini-cart"], .gogh-hrow > [class*="customer-account"] { flex: none; }' .
		// the Centred header is a stack: title above, menu below. Woo's icons
		// arrive as two more stack rows (a lone account icon, then a lone
		// cart — "centred header looks broken when woo is installed"), so
		// the stack becomes a wrapping row instead: the logo and the title
		// take a full line each, and the menu, account and cart share one
		// centred line under them
		'.gogh-hstack { flex-direction: row !important; flex-wrap: wrap !important; justify-content: center !important; align-items: center; }' .
		'.gogh-hstack > .wp-block-site-logo, .gogh-hstack > .wp-block-site-title { flex-basis: 100%; text-align: center; }' .
		'.gogh-hstack > .wp-block-site-logo img { margin-inline: auto; }' .
		'.gogh-hstack > [class*="mini-cart"], .gogh-hstack > [class*="customer-account"] { align-self: center; }' .
		'';
}
/**
 * The overlay is the phone menu; the bar is the desktop one. An item can
 * live in either or both (a class on its link block); the extras (Call,
 * Email, My account) and a separate phone menu join the overlay at render.
 */
add_filter( 'render_block_core/navigation', function ( $html ) {
	static $inside = false;
	if ( $inside || false === strpos( $html, 'wp-block-navigation__responsive-container-content' ) ) {
		return $html;
	}
	$ms    = gogh_menu_style();
	$extra = '';
	if ( $ms['phoneMenu'] ) {
		$inside = true;
		$alt    = do_blocks( '<!-- wp:navigation {"ref":' . (int) $ms['phoneMenu'] . ',"overlayMenu":"never"} /-->' );
		$inside = false;
		if ( preg_match( '#<ul[^>]*class="[^"]*wp-block-navigation__container[^"]*"[^>]*>[\s\S]*</ul>#', $alt, $mm ) ) {
			$extra .= preg_replace( '/class="wp-block-navigation__container/', 'class="wp-block-navigation__container gogh-mm-phonelist', $mm[0], 1 );
		}
	}
	$links = array();
	if ( $ms['phone'] ) {
		$links[] = '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $ms['phone'] ) ) . '"><span class="gogh-mm-extra-k">' . esc_html__( 'Call', 'gogh-editor' ) . '</span>' . esc_html( $ms['phone'] ) . '</a>';
	}
	if ( $ms['email'] ) {
		$links[] = '<a href="mailto:' . esc_attr( $ms['email'] ) . '"><span class="gogh-mm-extra-k">' . esc_html__( 'Email', 'gogh-editor' ) . '</span>' . esc_html( $ms['email'] ) . '</a>';
	}
	if ( $ms['account'] && function_exists( 'wc_get_page_permalink' ) ) {
		$links[] = '<a href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '"><span class="gogh-mm-extra-k">' . esc_html__( 'Account', 'gogh-editor' ) . '</span>' . esc_html__( 'My account', 'gogh-editor' ) . '</a>';
	}
	if ( $links ) {
		$extra .= '<div class="gogh-mm-extras">' . implode( '', $links ) . '</div>';
	}
	if ( '' === $extra ) {
		return $html;
	}
	$at = strpos( $html, 'wp-block-navigation__responsive-container-content' );
	if ( false === $at || ! preg_match( '#</ul>\s*</div>#', $html, $m, PREG_OFFSET_CAPTURE, $at ) ) {
		return $html;
	}
	$pos = $m[0][1] + strlen( '</ul>' );
	return substr( $html, 0, $pos ) . $extra . substr( $html, $pos );
}, 20 );
// a panel's page is for its editor: visitors who reach it go home
add_action( 'template_redirect', function () {
	if ( is_singular( 'gogh_panel' ) && ! current_user_can( 'edit_theme_options' ) ) {
		wp_safe_redirect( home_url( '/' ), 302 );
		exit;
	}
} );
// a new panel wears the blank canvas (no header, no footer — it IS the header's)
add_action( 'save_post_gogh_panel', function ( $post_id ) {
	if ( ! get_page_template_slug( $post_id ) ) {
		update_post_meta( $post_id, '_wp_page_template', 'blank-canvas' ); // plugin templates are stored by bare slug
	}
} );
/**
 * The mega menu at view time: a menu item carrying gogh-panel-N gets its
 * panel (the page's sections, rendered) as a dropdown, a chevron that
 * opens it for keyboards and touch, and — for the phone overlay — the
 * panel's links as a plain list that folds under the item.
 */
add_filter( 'render_block_core/navigation-link', function ( $html, $block ) {
	static $inside = false;
	$cls = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( $inside || ! preg_match( '/(?:^|\s)gogh-panel-(\d+)(?:\s|$)/', $cls, $m ) ) {
		return $html;
	}
	// while EDITING, the header stays a plain menu: a panel's sections inside
	// it would read as a freeform header to the editor and hide the menu tools
	// (the panel has a page of its own to be edited on)
	if ( isset( $_GET['gogh-edit'] ) || isset( $_GET['gogh-write'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return $html;
	}
	$panel = get_post( (int) $m[1] );
	if ( ! $panel || 'gogh_panel' !== $panel->post_type || 'publish' !== $panel->post_status ) {
		return $html;
	}
	$inside = true;
	$inner  = do_blocks( $panel->post_content );
	$inside = false;
	$inner  = trim( (string) $inner );
	if ( '' === $inner ) {
		return $html;
	}
	// a section's style scope is minted per PAGE (gogh-sec-2, -5, …), so a
	// panel's first section shares its scope with the host page's hero — two
	// stylesheets for one class, and the open menu laid itself out by the
	// hero's rules (James: "a newly made mega menu looks quite broken"). In
	// the menu, the panel's sections wear a suffix of their own.
	$inner = gogh_rescope_html( $inner, '-m' . (int) $panel->ID );
	$id    = 'gogh-mega-' . (int) $panel->ID;
	$label = isset( $block['attrs']['label'] ) ? wp_strip_all_tags( (string) $block['attrs']['label'] ) : '';
	// the panel's links, for phones
	$links = '';
	if ( preg_match_all( '/<a\s[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/is', $inner, $mm, PREG_SET_ORDER ) ) {
		$seen = array();
		$rows = array();
		foreach ( $mm as $a ) {
			$text = trim( wp_strip_all_tags( $a[2] ) );
			$href = html_entity_decode( $a[1] );
			if ( '' === $text || isset( $seen[ $href ] ) || 0 === strpos( $href, '#' ) ) {
				continue;
			}
			$seen[ $href ] = 1;
			$rows[]        = '<li><a href="' . esc_url( $href ) . '">' . esc_html( $text ) . '</a></li>';
			if ( count( $rows ) >= 12 ) {
				break;
			}
		}
		if ( $rows ) {
			$links = '<ul class="gogh-mega-links">' . implode( '', $rows ) . '</ul>';
		}
	}
	$toggle = '<button type="button" class="gogh-mega-toggle" aria-expanded="false" aria-controls="' . esc_attr( $id ) . '" aria-label="' . esc_attr( sprintf( __( 'More under %s', 'gogh-editor' ), $label ) ) . '">' .
		'<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>';
	$mega   = '<div class="gogh-mega" id="' . esc_attr( $id ) . '" hidden><div class="gogh-mega-in">' . $inner . '</div></div>';
	$out    = preg_replace( '/class="wp-block-navigation-item /', 'class="wp-block-navigation-item gogh-has-panel ', $html, 1 );
	$at     = strrpos( $out, '</li>' );
	if ( false === $at ) {
		return $html;
	}
	return substr( $out, 0, $at ) . $toggle . $mega . $links . substr( $out, $at );
}, 10, 2 );
/**
 * Re-scope rendered gogh sections: every scope token named by a
 * data-gogh-scope attribute is suffixed wherever it appears — class lists,
 * the data attribute, and the scoped stylesheet — so the same section can
 * live on a page beside sections that were minted with the same counter.
 */
function gogh_rescope_html( $html, $suffix ) {
	if ( ! preg_match_all( '/data-gogh-scope="([a-z0-9-]+)"/', $html, $m ) ) {
		return $html;
	}
	$tokens = array_unique( $m[1] );
	usort( $tokens, function ( $a, $b ) { return strlen( $b ) - strlen( $a ); } );
	$suffix = preg_replace( '/[^a-z0-9-]/', '', (string) $suffix );
	foreach ( $tokens as $t ) {
		$html = preg_replace( '/(?<![a-z0-9-])' . preg_quote( $t, '/' ) . '(?![a-z0-9-])/', $t . $suffix, $html );
	}
	return $html;
}
function gogh_mega_css() {
	return // the site's button style (a pill with a button's worth of padding) lands on
		// the icon-only search button INSIDE its field, where it fills the field's
		// full height and sticks out fat ("is the search meant to look like this")
		'.wp-block-search__button-inside .wp-block-search__button.has-icon { padding: 0.45em 0.9em !important; min-height: 0 !important; line-height: 1 !important; margin: 4px !important; }' .
		'.wp-block-search__button-inside .wp-block-search__inside-wrapper { align-items: center; }' .
		'.wp-block-navigation-item.gogh-has-panel { position: relative; }' .
		'.gogh-mega-toggle { all: unset; cursor: pointer; display: inline-grid; place-items: center; width: 22px; height: 22px; margin-left: 2px; border-radius: 50%; opacity: 0.7; transition: transform 0.2s, opacity 0.2s; }' .
		'.gogh-mega-toggle:hover, .gogh-mega-toggle:focus-visible { opacity: 1; }' .
		'.gogh-mega-toggle:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }' .
		'.gogh-has-panel.is-open > .gogh-mega-toggle { transform: rotate(180deg); }' .
		// the dropdown: the header's width, the theme's paper, under everything in the header
		'.gogh-mega { position: absolute; z-index: 60; top: 100%; left: 0; width: 100vw; background: var(--wp--preset--color--base, #fff); color: var(--wp--preset--color--contrast, #141519); box-shadow: 0 30px 80px -20px rgba(0,0,0,0.35); border-top: 1px solid color-mix(in srgb, currentColor 10%, transparent); max-height: min(72vh, 760px); overflow: auto; overscroll-behavior: contain; text-align: left; }' .
		'.gogh-mega[hidden] { display: none; }' .
		'@media (prefers-reduced-motion: no-preference) { .gogh-mega { animation: gogh-mega-in 0.18s ease; } @keyframes gogh-mega-in { from { opacity: 0; translate: 0 -6px; } to { opacity: 1; translate: 0 0; } } }' .
		// a section inside the panel fills the panel, never the viewport
		'.gogh-mega .gogh-wrap, .gogh-mega .alignfull, .gogh-mega .alignwide { width: 100% !important; max-width: 100% !important; margin-inline: 0 !important; }' .
		'.gogh-mega .gogh-section a { text-decoration: none; }' .
		'.gogh-mega .gogh-section a:hover { text-decoration: underline; text-underline-offset: 3px; }' .
		// phones: no dropdown — the panel's links fold under the item
		'.gogh-mega-links { display: none; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mega { display: none !important; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-has-panel { flex-wrap: wrap; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-has-panel.is-open > .gogh-mega-links { display: flex; flex-direction: column; gap: 6px; flex-basis: 100%; list-style: none; margin: 8px 0 6px; padding: 0 0 0 0.6em; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mega-links a { font-size: clamp(16px, 2.2vw, 22px) !important; font-weight: 500; opacity: 0.85; text-decoration: none; color: inherit; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mega-toggle { width: 36px; height: 36px; margin-left: 6px; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mega-toggle svg { width: 20px; height: 20px; }';
}
function gogh_menu_overlay_css() {
	return
		// one menu, two places: phone-only items hide in the bar, desktop-only
		// items hide in the overlay; the extras and a phone menu live only there
		'.wp-block-navigation-item.gogh-only-phone { display: none !important; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item.gogh-only-phone { display: flex !important; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item.gogh-only-desktop { display: none !important; }' .
		'.gogh-mm-phonelist, .gogh-mm-extras { display: none; }' .
		'body.gogh-mm-hasphone .wp-block-navigation__responsive-container.is-menu-open ul.wp-block-navigation__container:not(.gogh-mm-phonelist) { display: none !important; }' .
		'.wp-block-navigation__responsive-container.is-menu-open ul.gogh-mm-phonelist { display: flex; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mm-extras { display: flex; flex-direction: column; align-items: inherit; gap: 10px; margin-top: clamp(20px, 4vh, 40px); padding-top: clamp(16px, 3vh, 28px); border-top: 1px solid color-mix(in srgb, currentColor 18%, transparent); font-size: clamp(15px, 2vw, 19px); }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mm-extras a { color: inherit; text-decoration: none; opacity: 0.85; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .gogh-mm-extras a:hover { opacity: 1; }' .
		'.gogh-mm-extra-k { display: inline-block; min-width: 4.5em; font-size: 0.72em; letter-spacing: 0.12em; text-transform: uppercase; opacity: 0.6; margin-right: 8px; }' .
		'body.gogh-mm-centred .wp-block-navigation__responsive-container.is-menu-open .gogh-mm-extras, body.gogh-mm-stack .wp-block-navigation__responsive-container.is-menu-open .gogh-mm-extras, body.gogh-mm-sheet .wp-block-navigation__responsive-container.is-menu-open .gogh-mm-extras { align-items: center; text-align: center; }' .
		'.wp-block-navigation__responsive-container.is-menu-open { background: var(--wp--preset--color--base, #fff) !important; color: var(--wp--preset--color--contrast, #141519); padding: clamp(24px, 6%, 72px) !important; animation: gogh-menu-in 0.28s ease; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-content { align-items: center; justify-content: center; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__container { align-items: center; text-align: center; gap: clamp(10px, 2.2vh, 26px) !important; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item { opacity: 0; transform: translateY(10px); animation: gogh-menu-item 0.45s cubic-bezier(.2,.7,.2,1) forwards; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item:nth-child(1) { animation-delay: 0.06s; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item:nth-child(2) { animation-delay: 0.12s; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item:nth-child(3) { animation-delay: 0.18s; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item:nth-child(4) { animation-delay: 0.24s; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item:nth-child(5) { animation-delay: 0.30s; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item:nth-child(n+6) { animation-delay: 0.36s; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item__content { font-size: clamp(28px, 5.2vw, 60px) !important; font-weight: 600; line-height: 1.12; letter-spacing: -0.01em; text-decoration: none; padding: 0.1em 0.2em; border-radius: 0.2em; transition: opacity 0.15s ease, transform 0.15s ease; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item__content:hover { opacity: 0.62; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item__content:focus-visible { outline: 2px solid currentColor; outline-offset: 6px; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__submenu-container .wp-block-navigation-item__content { font-size: clamp(18px, 2.4vw, 26px) !important; font-weight: 500; opacity: 0.8; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close { top: clamp(16px, 3vw, 28px); right: clamp(16px, 3vw, 28px); width: 48px; height: 48px; border-radius: 999px; display: flex; align-items: center; justify-content: center; background: color-mix(in srgb, var(--wp--preset--color--contrast, #141519) 8%, transparent); color: inherit; transition: background 0.15s ease; }' .
		'.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close:hover { background: color-mix(in srgb, var(--wp--preset--color--contrast, #141519) 16%, transparent); }' .
		'@keyframes gogh-menu-in { from { opacity: 0; } to { opacity: 1; } }' .
		'@keyframes gogh-menu-item { to { opacity: 1; transform: none; } }' .
		'@media (prefers-reduced-motion: reduce) { .wp-block-navigation__responsive-container.is-menu-open, .wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation-item { animation: none; opacity: 1; transform: none; } }';
}
// a gogh-built description carries its own <style> block; anything that
// trims it to plain words (the mini-cart, excerpts, feeds) would otherwise
// print '/* generated by gogh */ .gogh-wrap { container-…' as prose.
// Trim from the markup with the style and script blocks removed.
add_filter( 'wp_trim_words', function ( $text, $num_words, $more, $original ) {
	if ( false === stripos( (string) $original, '<style' ) && false === stripos( (string) $original, '<script' ) ) {
		return $text;
	}
	$clean = preg_replace( '#<(style|script)\b[^>]*>.*?</\1>#is', ' ', (string) $original );
	$clean = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $clean ) ) );
	$words = $clean === '' ? array() : preg_split( '/ /u', $clean );
	if ( count( $words ) <= $num_words ) {
		return implode( ' ', $words );
	}
	return implode( ' ', array_slice( $words, 0, $num_words ) ) . ( null === $more ? '&hellip;' : $more );
}, 10, 4 );
// the Store API (mini-cart, cart, checkout) reads product descriptions as
// text: kses drops gogh's <style> tag and keeps its words. Over REST the
// style and script blocks go, the words stay; the product page itself
// still renders the full gogh section.
foreach ( array( 'woocommerce_product_get_description', 'woocommerce_product_get_short_description' ) as $gogh_desc_hook ) {
	add_filter( $gogh_desc_hook, function ( $value ) {
		if ( ! gogh_is_store_api() || ! is_string( $value ) || false === stripos( $value, '<style' ) ) {
			return $value;
		}
		return preg_replace( '#<(style|script)\b[^>]*>.*?</\1>#is', '', $value );
	}, 5 );
}
// while a pattern preview renders, a rails widget shows the model's own
// preview markup (the sample shop / the last live preview) instead of the
// Woo block — the section's model is stashed as the section starts to render
add_filter( 'render_block_data', function ( $parsed ) {
	if ( ! empty( $GLOBALS['gogh_pattern_preview'] ) && isset( $parsed['blockName'] ) && 'gogh/section' === $parsed['blockName'] ) {
		$GLOBALS['gogh_preview_model'] = isset( $parsed['attrs']['model'] ) ? $parsed['attrs']['model'] : null;
	}
	return $parsed;
} );
add_filter( 'render_block_core/group', function ( $html, $block ) {
	if ( empty( $GLOBALS['gogh_pattern_preview'] ) ) {
		return $html;
	}
	$cls = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( false === strpos( $cls, 'gogh-widget' ) || ! preg_match( '/gogh-el-(\d+)/', $cls, $m ) ) {
		return $html;
	}
	$model = isset( $GLOBALS['gogh_preview_model'] ) ? $GLOBALS['gogh_preview_model'] : null;
	$el    = ( $model && isset( $model['elements'][ $m[1] - 1 ] ) ) ? $model['elements'][ $m[1] - 1 ] : null;
	if ( ! $el || empty( $el['rails'] ) || empty( $el['whtml'] ) ) {
		return $html;
	}
	return '<div class="wp-block-group ' . esc_attr( $cls ) . '">' . wp_kses_post( $el['whtml'] ) . '</div>';
}, 10, 2 );
// A product grid must never render a product's whole page. Woo 11 hydrates
// every product in a Product Collection by pushing its full description
// through do_blocks (Store API ProductSchema → wc_format_content). A product
// whose description is a gogh page WITH its own product sections then
// renders a grid that renders that product that renders a grid… (47,000
// blocks, ten seconds, then the memory limit — 'the whole site is now
// running incredibly slowly'). While a collection renders, a product's
// description is empty for Woo's purposes: the grid never shows it.
add_filter( 'pre_render_block', function ( $pre, $parsed ) {
	if ( isset( $parsed['blockName'] ) && 'woocommerce/product-collection' === $parsed['blockName'] ) {
		$GLOBALS['gogh_in_collection'] = ( $GLOBALS['gogh_in_collection'] ?? 0 ) + 1;
	}
	return $pre;
}, 1, 2 );
add_filter( 'render_block_woocommerce/product-collection', function ( $html ) {
	$GLOBALS['gogh_in_collection'] = max( 0, ( $GLOBALS['gogh_in_collection'] ?? 1 ) - 1 );
	return $html;
}, 1000 );
function gogh_in_collection() {
	return ! empty( $GLOBALS['gogh_in_collection'] );
}
foreach ( array( 'woocommerce_product_get_description', 'woocommerce_product_get_short_description' ) as $gogh_coll_hook ) {
	add_filter( $gogh_coll_hook, function ( $value ) {
		if ( gogh_in_collection() && is_string( $value ) && false !== strpos( $value, 'wp:gogh/section' ) ) {
			return '';
		}
		return $value;
	}, 4 );
}
// ---------- the rails: Woo's Product Collection, dressed by gogh ----------
// S / M / L spacing presets (no gutter field anywhere), and the designed
// empty store: a visitor never meets "No results found" on day one.
function gogh_shop_css() {
	// Woo sizes its flex cards assuming its own 1.25em gap — a wider gap
	// makes the third card wrap. S tightens the gap (safe); M is Woo's own;
	// L adds air INSIDE each card so the row's maths never changes.
	return '.gogh-shop-gap-s .wc-block-product-template.is-flex-container { gap: 0.6em; }' .
		'.gogh-shop-gap-l .wc-block-product-template.is-flex-container > li { padding: 0 0.7em 1.2em; box-sizing: border-box; }' .
		// pages published before the rails fix (Sept 2026) carry a section-wide button rule; the rails keep Woo's natural sizes
		'.gogh-widget .wp-block-button, .gogh-widget .wp-block-button__link { width: auto !important; height: auto !important; display: inline-flex !important; }' .
		'.gogh-widget .wc-block-components-product-button { margin-top: 10px; }' .
		// the Hero layout's glass panel — the words read on any picture
		'.gogh-prod-hero-panel { background: color-mix(in srgb, var(--wp--preset--color--contrast, #141519) 55%, transparent); backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px); border-radius: 22px; padding-block: clamp(1.4rem, 2.6vw, 2rem) !important; padding-inline: clamp(1.4rem, 3vw, 2.4rem) !important; color: var(--wp--preset--color--base, #fff); box-shadow: 0 30px 80px -30px rgba(0,0,0,0.55); }' .
		'.gogh-prod-hero-panel > :first-child { margin-top: 0 !important; }' .
		'.gogh-prod-hero-panel > :last-child { margin-bottom: 0 !important; }' .
		'.gogh-prod-hero-panel { max-width: min(560px, 100%); margin-left: 0; }' .
		'.gogh-prod-hero-panel > *, .gogh-prod-hero-panel h1, .gogh-prod-hero-panel .wp-block-post-title, .gogh-prod-hero-panel p, .gogh-prod-hero-panel .price, .gogh-prod-hero-panel .price ins, .gogh-prod-hero-panel .price del, .gogh-prod-hero-panel .stock, .gogh-prod-hero-panel .wc-block-components-product-price__value { color: var(--wp--preset--color--base, #fff) !important; }' .
		'.gogh-prod-hero-panel .wp-block-post-title { margin-top: 0; line-height: 1.05; text-wrap: balance; }' .
		'.gogh-prod-hero-panel .wc-block-components-product-price, .gogh-prod-hero-panel .wp-block-woocommerce-product-summary { color: inherit; }' .
		'.gogh-prod-hero-panel .single_add_to_cart_button, .gogh-prod-hero-panel .wp-block-button__link { background: var(--wp--preset--color--base, #fff) !important; color: var(--wp--preset--color--contrast, #141519) !important; border-color: transparent; }' .
		'.gogh-prod-hero-panel .quantity .qty, .gogh-prod-hero-panel input.input-text { background: color-mix(in srgb, var(--wp--preset--color--base, #fff) 92%, transparent); color: var(--wp--preset--color--contrast, #141519); border-color: transparent; }' .
		'.gogh-prod-hero .wp-block-cover__inner-container { width: 100%; }' .
		'@media (max-width: 720px) { .gogh-prod-hero { min-height: 100svh !important; } .gogh-prod-hero-panel { padding: 1.2rem; } }' .
		// the classic gallery's lightbox trigger is a bare 🔍 above the picture in
		// block themes — a quiet corner button instead (James: 'pretty weird placed, and quite ugly')
		// the gallery fills its column (it stopped at Woo's single-image width —
		// James: 'is the image a little small?')
		'.wp-block-woocommerce-product-image-gallery, .wp-block-woocommerce-product-image-gallery .woocommerce-product-gallery, .woocommerce-product-gallery__wrapper { width: 100% !important; max-width: none !important; }' .
		'.woocommerce-product-gallery__image img { width: 100%; height: auto; display: block; }' .
		'.woocommerce-product-gallery { position: relative; }' .
		'.woocommerce-product-gallery__trigger { position: absolute; top: 14px; right: 14px; z-index: 9; width: 42px; height: 42px; border-radius: 999px; background: color-mix(in srgb, var(--wp--preset--color--base, #fff) 86%, transparent) no-repeat center / 18px 18px; background-image: url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23141519%27 stroke-width=%272.2%27 stroke-linecap=%27round%27%3E%3Ccircle cx=%2711%27 cy=%2711%27 r=%277%27/%3E%3Cpath d=%27M20 20l-3.5-3.5M11 8v6M8 11h6%27/%3E%3C/svg%3E"); backdrop-filter: blur(8px); box-shadow: 0 6px 18px rgba(0,0,0,0.18); font-size: 0 !important; color: transparent !important; text-decoration: none; opacity: 0.9; transition: opacity 0.15s ease, transform 0.15s ease; }' .
		'.woocommerce-product-gallery__trigger:hover { opacity: 1; transform: scale(1.05); }' .
		'.woocommerce-product-gallery__trigger img, .woocommerce-product-gallery__trigger span { display: none; }' .
		// shop looks
		'.gogh-shop-title { text-wrap: balance; }' .
		'.gogh-shop-head-editorial .gogh-shop-title { font-size: clamp(2.6rem, 6vw, 4.6rem); line-height: 1.02; letter-spacing: -0.02em; margin: 0 0 0.3em; }' .
		'.gogh-shop-head-gallery .gogh-shop-title { font-size: clamp(2rem, 4vw, 3rem); margin: 0 0 0.3em; }' .
		'.gogh-shop-desc { max-width: 62ch; opacity: 0.8; }' .
		'.gogh-shop-head-gallery .gogh-shop-desc { margin-inline: auto; text-align: center; }' .
		'.gogh-catchips ul.wc-block-product-categories-list { display: flex; flex-wrap: wrap; gap: 8px; list-style: none; padding: 0; margin: 1.2rem 0 0; }' .
		'.gogh-shop-head-gallery .gogh-catchips ul.wc-block-product-categories-list { justify-content: center; }' .
		'.gogh-catchips ul.wc-block-product-categories-list li { margin: 0; }' .
		'.gogh-shop-head-editorial .gogh-catchips, .gogh-shop-head-editorial .gogh-catchips ul { margin-inline: 0 !important; }' .
		'.gogh-catchips ul.wc-block-product-categories-list a { display: inline-block; padding: 7px 14px; border-radius: 999px; border: 1.5px solid color-mix(in srgb, currentColor 30%, transparent); text-decoration: none; font-size: 0.9em; font-weight: 600; }' .
		'.gogh-catchips ul.wc-block-product-categories-list a:hover { border-color: currentColor; }' .
		'.gogh-shop-toolbar { padding: 0.6rem 0 1rem; border-bottom: 1px solid color-mix(in srgb, currentColor 14%, transparent); margin-bottom: 1.5rem !important; }' .
		'.gogh-shop-toolbar .woocommerce-result-count { margin: 0; opacity: 0.7; }' .
		// Woo's sorting control arrives as the browser's own <select> (James:
		// 'this is kinda ugly') — the theme's type, a quiet pill, a drawn chevron
		'.wc-block-catalog-sorting select, .woocommerce-ordering select, form.woocommerce-ordering select.orderby { appearance: none; -webkit-appearance: none; font: inherit; font-size: 0.92em; color: inherit; background: color-mix(in srgb, currentColor 6%, transparent) no-repeat right 14px center / 12px 12px; background-image: url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27currentColor%27 stroke-width=%272.4%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27%3E%3Cpath d=%27M6 9l6 6 6-6%27/%3E%3C/svg%3E"); border: 1.5px solid color-mix(in srgb, currentColor 22%, transparent); border-radius: 999px; padding: 9px 38px 9px 16px; line-height: 1.2; cursor: pointer; }' .
		'.wc-block-catalog-sorting select:hover, .woocommerce-ordering select:hover { border-color: currentColor; }' .
		'.wc-block-catalog-sorting select:focus-visible, .woocommerce-ordering select:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }' .
		'.woocommerce-ordering { margin: 0; }' .
		'.gogh-shoplook-gallery .wc-block-product-template.is-flex-container { gap: 0.9em; }' .
		'.gogh-shoplook-gallery .wp-block-post-title { font-size: 0.98em; }' .
		'.gogh-shoplook-editorial .wp-block-post-title { font-size: 1.15em; }' .
		'.gogh-shop-side .wp-block-woocommerce-product-filters { position: sticky; top: 110px; }' .
		'@media (max-width: 782px) { .gogh-shop-catalogue { flex-direction: column; } .gogh-shop-side { flex-basis: auto !important; } }' .
		// the story under the buy box: plain words get air above and below;
		// a full-bleed section joins the hero flush (James: 'text looks kinda tight')
		'.gogh-story-slot .entry-content:not(:has(> .gogh-wrap:first-child)) { padding-top: clamp(2.5rem, 6vw, 5rem); }' .
		'.gogh-story-slot .entry-content:not(:has(> .gogh-wrap:last-child)) { padding-bottom: clamp(2rem, 5vw, 4rem); }' .
		// a rails widget's block fills its cell (the widget group is a flex row — a
		// block with no width of its own shrank to 46px and its tiles to nothing)
		'.gogh-widget > .wp-block-woocommerce-product-categories, .gogh-widget > .wp-block-woocommerce-product-collection { flex: 1 1 100%; width: 100%; min-width: 0; }' .
		// category tiles (the Categories section): Woo's category list as doors
		'.gogh-shop-cats ul.wc-block-product-categories-list { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 1.25em; list-style: none; padding: 0; margin: 0; }' .
		'.gogh-shop-cats-c2 ul.wc-block-product-categories-list { grid-template-columns: repeat(2, minmax(0, 1fr)); }' .
		'.gogh-shop-cats-c4 ul.wc-block-product-categories-list { grid-template-columns: repeat(4, minmax(0, 1fr)); }' .
		'.gogh-shop-cats.gogh-shop-gap-s ul.wc-block-product-categories-list { gap: 0.6em; } .gogh-shop-cats.gogh-shop-gap-l ul.wc-block-product-categories-list { gap: 2em; }' .
		'.gogh-shop-cats li.wc-block-product-categories-list-item { margin: 0; }' .
		'.gogh-shop-cats li.wc-block-product-categories-list-item > a { position: relative; display: block; aspect-ratio: 4 / 3; border-radius: 12px; overflow: hidden; background: color-mix(in srgb, currentColor 8%, transparent); text-decoration: none; }' .
		// Woo dresses the list for 50px thumbnails; the tile wants the whole picture
		'.gogh-shop-cats .wc-block-product-categories-list-item__image { position: absolute !important; inset: 0 !important; margin: 0 !important; width: 100% !important; max-width: none !important; height: 100% !important; float: none !important; }' .
		'.gogh-shop-cats .wc-block-product-categories-list-item__image img { width: 100% !important; max-width: none !important; height: 100% !important; object-fit: cover; display: block; transition: transform 0.4s ease; }' .
		'.gogh-shop-cats li > a:hover .wc-block-product-categories-list-item__image img { transform: scale(1.04); }' .
		'.gogh-shop-cats .wc-block-product-categories-list-item__name { position: absolute; left: 0; right: 0; bottom: 0; padding: 18px 20px; color: #fff; font-weight: 700; font-size: 1.25em; line-height: 1.2; background: linear-gradient(to top, rgba(0, 0, 0, 0.62), transparent); }' .
		'.gogh-shop-cats .wc-block-product-categories-list-item-count { display: none; }' .
		'@media (max-width: 700px) { .gogh-shop-cats ul.wc-block-product-categories-list { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; } }' .
		'.gogh-shop-empty { border: 1.5px dashed color-mix(in srgb, currentColor 30%, transparent); border-radius: 14px; padding: 56px 24px; text-align: center; max-width: 560px; margin-inline: auto; }' .
		'.gogh-shop-empty-owner { border-style: solid; border-color: color-mix(in srgb, currentColor 14%, transparent); background: color-mix(in srgb, currentColor 4%, transparent); }' .
		'.gogh-shop-empty-eyebrow { display: block; font-style: normal; font-size: 0.72em; letter-spacing: 0.14em; text-transform: uppercase; opacity: 0.55; margin-bottom: 14px; }' .
		'.gogh-shop-empty strong { display: block; font-size: 1.5em; line-height: 1.15; margin-bottom: 8px; }' .
		'.gogh-shop-empty span { display: block; opacity: 0.7; max-width: 38ch; margin-inline: auto; }' .
		'.gogh-shop-empty-cta { margin: 22px 0 0; }' .
		// the category banner: the category's own picture, a Cover with its
		// name and words at the foot (Editorial category look)
		'.gogh-shop-banner { margin-bottom: 1.5rem; }' .
		'.gogh-shop-banner .wp-block-cover__inner-container { padding: 2.5rem 0 2rem; }' .
		'.gogh-shop-banner .gogh-shop-title, .gogh-shop-banner .gogh-shop-desc, .gogh-shop-banner .gogh-shop-desc p { color: #fff; }' .
		'.gogh-shop-banner .gogh-shop-desc { max-width: 48ch; opacity: 0.88; }' .
		'.gogh-shop-banner .gogh-shop-title { margin-top: 0; }';
}
/**
 * The designed empty state. Squarespace shows "No results found" to
 * everyone; gogh answers the person actually looking:
 *   - the OWNER of an empty shop gets an invitation with the one button
 *     that matters (Add a product) and the promise that it lands here;
 *   - a visitor to a shop with nothing in it yet gets a graceful coming-soon;
 *   - an empty CATEGORY names itself and points back to the whole shop;
 *   - filters that match nothing say so and offer to clear.
 */
function gogh_shop_empty_state( $block ) {
	$owner = current_user_can( 'edit_products' );
	$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	$shop  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
	// which slice of the shop is empty?
	$term = null;
	if ( function_exists( 'is_product_category' ) && ( is_product_category() || is_product_tag() ) ) {
		$term = get_queried_object();
	} elseif ( ! empty( $attrs['query']['taxQuery']['product_cat'][0] ) ) {
		$t = get_term( (int) $attrs['query']['taxQuery']['product_cat'][0], 'product_cat' );
		if ( $t && ! is_wp_error( $t ) ) {
			$term = $t;
		}
	}
	$filtered = false;
	foreach ( array_keys( $_GET ) as $k ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $k, array( 'min_price', 'max_price', 'rating_filter', 'filter_stock_status', 'stock_status' ), true ) || 0 === strpos( (string) $k, 'filter_' ) || 0 === strpos( (string) $k, 'query_type_' ) ) {
			$filtered = true;
		}
	}
	$eyebrow = '';
	$title   = '';
	$line    = '';
	$cta     = '';
	$cta_url = '';
	$kind    = 'visitor';
	// a rail narrowed to what's on sale: an empty one is not an empty shop
	$on_sale = ! empty( $attrs['query']['woocommerceOnSale'] );
	if ( $filtered ) {
		$title   = __( 'Nothing matches those filters.', 'gogh-editor' );
		$line    = __( 'Loosen one and the shelves fill back up.', 'gogh-editor' );
		$cta     = __( 'Clear filters', 'gogh-editor' );
		$cta_url = strtok( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), '?' ) ?: $shop; // phpcs:ignore
		$cta_url = home_url( $cta_url );
		$kind    = 'filtered';
	} elseif ( $on_sale ) {
		$title = __( 'Nothing is on sale right now.', 'gogh-editor' );
		if ( $owner ) {
			$eyebrow = __( 'Only you can see this', 'gogh-editor' );
			$line    = __( 'Put a sale price on a product and it appears here, in this look.', 'gogh-editor' );
			$cta     = __( 'Manage products', 'gogh-editor' );
			$cta_url = admin_url( 'edit.php?post_type=product' );
			$kind    = 'owner';
		} else {
			$line    = __( 'The rest of the shop is open.', 'gogh-editor' );
			$cta     = __( 'Browse the whole shop', 'gogh-editor' );
			$cta_url = $shop;
		}
	} elseif ( $term ) {
		if ( $owner ) {
			$eyebrow = __( 'Only you can see this', 'gogh-editor' );
			/* translators: %s: category name */
			$title   = sprintf( __( 'Nothing in %s yet.', 'gogh-editor' ), $term->name );
			$line    = __( 'Add a product and put it in this category — it shows up here, in this look, with nothing else to set up.', 'gogh-editor' );
			$cta     = __( 'Add a product', 'gogh-editor' );
			$cta_url = admin_url( 'post-new.php?post_type=product' );
			$kind    = 'owner';
		} else {
			/* translators: %s: category name */
			$title   = sprintf( __( 'Nothing in %s just yet.', 'gogh-editor' ), $term->name );
			$line    = __( 'The rest of the shop is open.', 'gogh-editor' );
			$cta     = __( 'Browse the whole shop', 'gogh-editor' );
			$cta_url = $shop;
		}
	} elseif ( $owner ) {
		$eyebrow = __( 'Only you can see this', 'gogh-editor' );
		$title   = __( 'Your shop is ready for its first product.', 'gogh-editor' );
		$line    = __( 'A name and a price make it sellable. Publish it and it appears right here.', 'gogh-editor' );
		$cta     = __( 'Add a product', 'gogh-editor' );
		$cta_url = admin_url( 'post-new.php?post_type=product' );
		$kind    = 'owner';
	} else {
		$title = __( 'New things are on their way.', 'gogh-editor' );
		$line  = __( 'The shop opens soon — check back shortly.', 'gogh-editor' );
	}
	$out = '<div class="gogh-shop-empty gogh-shop-empty-' . esc_attr( $kind ) . '">';
	if ( $eyebrow ) {
		$out .= '<em class="gogh-shop-empty-eyebrow">' . esc_html( $eyebrow ) . '</em>';
	}
	$out .= '<strong>' . esc_html( $title ) . '</strong><span>' . esc_html( $line ) . '</span>';
	if ( $cta && $cta_url ) {
		$out .= '<p class="gogh-shop-empty-cta"><a class="wp-element-button wp-block-button__link" href="' . esc_url( $cta_url ) . '">' . esc_html( $cta ) . '</a></p>';
	}
	return $out . '</div>';
}
add_filter( 'render_block_woocommerce/product-collection', function ( $html, $block ) {
	$cls = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( false === strpos( $cls, 'gogh-shop' ) ) {
		return $html;
	}
	// no products rendered → the designed empty state, in the theme's own ink
	if ( false === strpos( $html, 'wc-block-product' ) || false === strpos( $html, '<li' ) ) {
		return '<div class="wp-block-woocommerce-product-collection ' . esc_attr( $cls ) . '">' . gogh_shop_empty_state( $block ) . '</div>';
	}
	return $html;
}, 10, 2 );
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'gogh-menu', false, array(), null );
	wp_enqueue_style( 'gogh-menu' );
	wp_add_inline_style( 'gogh-menu', gogh_chrome_css() . gogh_ghost_ink_css() . gogh_menu_overlay_css() . gogh_menu_style_css() . gogh_mega_css() );
	if ( class_exists( 'WooCommerce' ) ) {
		wp_add_inline_style( 'gogh-menu', gogh_shop_css() );
	}
} );

function gogh_reading_styles() {
	return array( 'magazine', 'journal', 'essay', 'gazette', 'photostory', 'feature', 'cover', 'manual' ); // '' = the theme's own default
}
add_action( 'init', function () {
	// the cover's chosen slice: 0 = top of the photo, 100 = bottom
	register_post_meta( 'post', '_gogh_cover_pos', array(
		'show_in_rest'  => true,
		'single'        => true,
		'type'          => 'integer',
		'default'       => 50,
		'sanitize_callback' => function ( $v ) {
			return max( 0, min( 100, (int) $v ) );
		},
		'auth_callback' => function ( $allowed, $meta_key, $post_id ) {
			return current_user_can( 'edit_post', $post_id );
		},
	) );
	register_post_meta( 'post', '_gogh_post_style', array(
		'show_in_rest'  => true,
		'single'        => true,
		'type'          => 'string',
		'default'       => '',
		'sanitize_callback' => function ( $v ) {
			return in_array( $v, gogh_reading_styles(), true ) ? $v : '';
		},
		'auth_callback' => function ( $allowed, $meta_key, $post_id ) {
			return current_user_can( 'edit_post', $post_id );
		},
	) );
} );
add_filter( 'body_class', function ( $classes ) {
	if ( is_singular( 'post' ) ) {
		$style = get_post_meta( get_the_ID(), '_gogh_post_style', true );
		if ( $style && in_array( $style, gogh_reading_styles(), true ) ) {
			$classes[] = 'gogh-read-' . $style;
		}
	}
	return $classes;
} );
// the cover look's raw materials, served on every post whether or not it
// wears the look yet — the write room auditions by flipping the body
// class, and the image must already be on the table when it does
add_action( 'wp_enqueue_scripts', function () {
	if ( ! is_singular( 'post' ) ) {
		return;
	}
	$post = get_post();
	$img  = get_the_post_thumbnail_url( $post, 'full' );
	if ( ! $img && preg_match( '/<img[^>]+src="([^"]+)"/', $post->post_content, $m ) ) {
		$img = $m[1]; // the first picture stands in for a missing featured image
	}
	$author = get_the_author_meta( 'display_name', $post->post_author );
	$byline = trim( ( $author ? $author . ' · ' : '' ) . get_the_date( '', $post ) );
	$pos    = (int) get_post_meta( $post->ID, '_gogh_cover_pos', true );
	$pos    = max( 0, min( 100, $pos ? $pos : 50 ) );
	$css    = 'body { ' .
		( $img ? '--gogh-cover-img: url(' . esc_url( $img ) . '); ' : '' ) .
		'--gogh-cover-pos: ' . $pos . '%; ' .
		'--gogh-cover-byline: "' . str_replace( array( '"', '\\' ), '', $byline ) . '"; }';
	wp_register_style( 'gogh-cover-vars', false, array(), null );
	wp_enqueue_style( 'gogh-cover-vars' );
	wp_add_inline_style( 'gogh-cover-vars', $css );
} );
// the broadsheet gate: gogh measures the post so looks can respond to
// length. Between the bounds the whole piece fits a screen or so and
// newspaper columns work; too short and columns are silly, too long and
// the reader would scroll down one column and back up for the next.
add_filter( 'body_class', function ( $classes ) {
	if ( is_singular( 'post' ) ) {
		$text  = wp_strip_all_tags( get_post_field( 'post_content', get_the_ID() ), true );
		$words = count( preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );
		if ( $words >= 120 && $words <= 460 ) {
			$classes[] = 'gogh-short';
		}
	}
	return $classes;
} );
/**
 * The looks themselves. Scoped by body class so the write room auditions by
 * flipping the class — the room IS the post, so the preview is the truth.
 */
function gogh_reading_style_css() {
	return
		// MAGAZINE — the feature treatment: a big centred title with a rule
		// beneath, a lede-sized opener with a drop cap, centred pull-quotes.
		// Unmistakable within one screen of any post.
		'.gogh-read-magazine .wp-block-post-title { text-align: center; font-size: clamp(3rem, 7vw, 4.8rem); line-height: 1.02; letter-spacing: -0.025em; max-width: 16ch; margin-inline: auto; text-wrap: balance; padding-bottom: 0.45em; position: relative; }' .
		'.gogh-read-magazine .wp-block-post-title::after { content: ""; position: absolute; left: 50%; bottom: 0; transform: translateX(-50%); width: 3.5em; height: 2px; background: currentColor; opacity: 0.55; }' .
		'.gogh-read-magazine .entry-content > p:first-of-type { font-size: 1.18em; line-height: 1.55; }' .
		'.gogh-read-magazine .entry-content > p:first-of-type::first-letter { float: left; font-size: 3.4em; line-height: 0.8; padding: 0.05em 0.12em 0 0; font-weight: 700; }' .
		// initial-letter is the real drop cap: sunk three lines, top on line
		// one, base on line three — the float version stays as the fallback
		'@supports (initial-letter: 3) { .gogh-read-magazine .entry-content > p:first-of-type::first-letter { float: none; font-size: unset; line-height: unset; padding: 0; initial-letter: 3; font-weight: 650; margin-right: 0.16em; } }' .
		'.gogh-read-magazine .entry-content > p, .gogh-read-magazine .entry-content > h2, .gogh-read-magazine .entry-content > h3 { max-width: 68ch; }' .
		'.gogh-read-magazine .entry-content > h2, .gogh-read-magazine .entry-content > h3 { text-align: center; }' .
		'.gogh-read-magazine .entry-content blockquote { font-size: 1.4em; line-height: 1.35; text-align: center; border: 0; max-width: 24ch; margin-inline: auto; }' .
		// image rhythm — the missing half of a look ("not sure it handles
		// images so well"). Print rules: a tall portrait runs NARROWER, never
		// three screens tall. In-column images cap at 72vh with the whole
		// photo visible (width follows, centred; no crop, nothing stored).
		// Deliberate bleeds keep their drama but never exceed a screen.
		'.gogh-read-magazine .entry-content figure.wp-block-image:not(.alignwide):not(.alignfull) img { max-height: 72vh; width: auto; max-width: 100%; margin-inline: auto; }' .
		'.gogh-read-magazine .entry-content figure.wp-block-image:not(.alignwide):not(.alignfull) { text-align: center; }' .
		'.gogh-read-magazine .entry-content figure.wp-block-image.alignwide img, .gogh-read-magazine .entry-content figure.wp-block-image.alignfull:not(.gogh-splash-break) img { max-height: 85vh; object-fit: cover; }' .
		// JOURNAL — the quiet notebook: a small uppercase title with a hanging
		// rule, a distinctly narrow measure, roomier lines, images pulled into
		// the column with soft corners. Reads as a different publication.
		'.gogh-read-journal .wp-block-post-title { font-size: clamp(1.15rem, 2vw, 1.5rem); font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; line-height: 1.3; border-bottom: 1px solid color-mix(in srgb, currentColor 25%, transparent); padding-bottom: 0.8em; max-width: 58ch; }' .
		'.gogh-read-journal .entry-content > p, .gogh-read-journal .entry-content > h2, .gogh-read-journal .entry-content > h3 { max-width: 54ch; }' .
		'.gogh-read-journal .entry-content > p { font-size: 0.95em; line-height: 1.85; margin-block-end: 1.6em; }' .
		'.gogh-read-journal .entry-content > h2, .gogh-read-journal .entry-content > h3 { font-size: 1.15em; letter-spacing: 0.06em; text-transform: uppercase; }' .
		'.gogh-read-journal .entry-content blockquote { border-left: 2px solid currentColor; padding-left: 1.2em; font-style: italic; opacity: 0.85; }' .
		'.gogh-read-journal .entry-content figure.wp-block-image.alignwide, .gogh-read-journal .entry-content figure.wp-block-image.alignfull:not(.gogh-splash-break) { width: 100% !important; max-width: 54ch !important; margin-inline: auto !important; }' .
		'.gogh-read-journal .entry-content figure.wp-block-image img { border-radius: 10px; }' .
		// the notebook keeps photos modest: whole image visible, never a
		// screen-filler
		'.gogh-read-journal .entry-content figure.wp-block-image img { max-height: 60vh; width: auto; max-width: 100%; margin-inline: auto; }' .
		'.gogh-read-journal .entry-content figure.wp-block-image { text-align: center; }' .
		// ESSAY — the architecture of calm: a centred, unhurried feature.
		// Lighter title than Magazine (no rule, no shout), a centred
		// standfirst, generous air between everything, and pull-quotes on a
		// soft tinted panel (colour mixed from the theme's own ink, so it
		// composes with any site style).
		'.gogh-read-essay .wp-block-post-title { text-align: center; font-size: clamp(2.4rem, 5.5vw, 3.8rem); font-weight: 500; line-height: 1.08; letter-spacing: -0.015em; max-width: 18ch; margin-inline: auto; text-wrap: balance; }' .
		'.gogh-read-essay .entry-content > p:first-of-type { text-align: center; font-size: 1.15em; line-height: 1.6; max-width: 44ch; margin-inline: auto; opacity: 0.85; }' .
		'.gogh-read-essay .entry-content > p { max-width: 62ch; line-height: 1.75; margin-block-end: 1.5em; }' .
		'.gogh-read-essay .entry-content > h2, .gogh-read-essay .entry-content > h3 { max-width: 62ch; font-size: 1.3em; font-weight: 600; margin-block-start: 2.4em; }' .
		'.gogh-read-essay .entry-content blockquote { border: 0; background: color-mix(in srgb, currentColor 6%, transparent); border-radius: 4px; padding: 2em 2.2em; font-size: 1.25em; line-height: 1.45; max-width: 34ch; margin-block: 2.5em; }' .
		'.gogh-read-essay .entry-content figure.wp-block-image { margin-block: 3em; text-align: center; }' .
		'.gogh-read-essay .entry-content figure.wp-block-image:not(.alignwide):not(.alignfull) img { max-height: 75vh; width: auto; max-width: 100%; margin-inline: auto; }' .
		'.gogh-read-essay .entry-content figure.wp-block-image figcaption { font-size: 0.8em; letter-spacing: 0.06em; text-transform: uppercase; opacity: 0.55; margin-top: 1em; text-align: center; }' .
		// GAZETTE — the commons journal: newsprint bones. A tight left title
		// under a double rule, justified columns with hyphenation, boxed
		// pull-quotes, headings in small caps with a hanging rule. All rules
		// draw from currentColor so the ink follows the theme.
		'.gogh-read-gazette .wp-block-post-title { font-size: clamp(2.2rem, 5vw, 3.4rem); font-weight: 700; line-height: 1.04; letter-spacing: -0.02em; max-width: 22ch; border-top: 3px double currentColor; padding-top: 0.45em; }' .
		'.gogh-read-gazette .entry-content > p { max-width: 60ch; text-align: justify; hyphens: auto; -webkit-hyphens: auto; line-height: 1.6; margin-block-end: 1.1em; }' .
		'.gogh-read-gazette .entry-content > p:first-of-type::first-letter { float: left; font-size: 3.1em; line-height: 0.82; padding: 0.04em 0.14em 0 0; font-weight: 700; }' .
		'@supports (initial-letter: 3) { .gogh-read-gazette .entry-content > p:first-of-type::first-letter { float: none; font-size: unset; line-height: unset; padding: 0; initial-letter: 3; font-weight: 700; margin-right: 0.15em; } }' .
		// crossheads sit IN the column, set loud in the display face — the
		// newspaper's "The Fog Machine" move, not a section divider
		// 36ch ≈ the paragraphs' 60ch box: ch here is measured in the
		// crosshead's own 1.65em characters, so the width must scale down
		// or the centred box overhangs the text column
		'.gogh-read-gazette .entry-content > h2, .gogh-read-gazette .entry-content > h3 { max-width: 38ch; font-size: 1.65em; font-weight: 700; line-height: 1.08; letter-spacing: -0.01em; text-transform: none; margin-block: 1.3em 0.45em; }' .
		'.gogh-read-gazette .entry-content blockquote { border: 1px solid color-mix(in srgb, currentColor 45%, transparent); padding: 1.4em 1.6em; text-align: center; font-size: 1.2em; line-height: 1.4; max-width: 30ch; margin-inline: auto; margin-block: 2em; }' .
		'.gogh-read-gazette .entry-content figure.wp-block-image { margin-block: 1.8em; }' .
		'.gogh-read-gazette .entry-content figure.wp-block-image:not(.alignwide):not(.alignfull) img { max-height: 65vh; width: auto; max-width: 100%; margin-inline: auto; }' .
		'.gogh-read-gazette .entry-content figure.wp-block-image figcaption { font-size: 0.78em; opacity: 0.65; border-bottom: 1px solid color-mix(in srgb, currentColor 25%, transparent); padding-bottom: 0.7em; }' .
		// PHOTO STORY — pictures lead, words breathe between. A huge, tight
		// display title; sparse centred text bands on a narrow measure;
		// images run big (bleeds up to a full screen) with prominent
		// breathing room and quiet captions; quotes are bare oversized
		// statements. For posts that are mostly photographs.
		'.gogh-read-photostory .wp-block-post-title { font-size: clamp(3.2rem, 9vw, 6rem); line-height: 0.98; letter-spacing: -0.03em; max-width: 12ch; text-wrap: balance; }' .
		'.gogh-read-photostory .entry-content > p { max-width: 46ch; margin-inline: auto; text-align: center; line-height: 1.8; font-size: 1.05em; margin-block: 2.2em; }' .
		'.gogh-read-photostory .entry-content > h2, .gogh-read-photostory .entry-content > h3 { text-align: center; font-size: 1.1em; letter-spacing: 0.14em; text-transform: uppercase; margin-block-start: 3em; }' .
		'.gogh-read-photostory .entry-content figure.wp-block-image { margin-block: 3.5em; text-align: center; }' .
		'.gogh-read-photostory .entry-content figure.wp-block-image:not(.alignwide):not(.alignfull) img { max-height: 88vh; width: auto; max-width: 100%; margin-inline: auto; }' .
		'.gogh-read-photostory .entry-content figure.wp-block-image.alignwide img, .gogh-read-photostory .entry-content figure.wp-block-image.alignfull:not(.gogh-splash-break) img { max-height: 96vh; object-fit: cover; }' .
		'.gogh-read-photostory .entry-content figure.wp-block-image figcaption { font-size: 0.82em; opacity: 0.6; margin-top: 1.2em; text-align: center; }' .
		'.gogh-read-photostory .entry-content blockquote { border: 0; text-align: center; font-size: 1.6em; line-height: 1.3; max-width: 22ch; margin-inline: auto; margin-block: 2.5em; }' .
		// COVER — the poster front ("takes an image and sets it as the
		// background, with title, author over the top"). The featured image
		// (or the post's first picture) becomes a full-bleed header with the
		// title knocked out over a quiet scrim and the byline beneath it in
		// small caps; the raw materials arrive as CSS vars so the write room
		// can audition the look live. No image → a deep brand-toned cover.
		'.gogh-read-cover .wp-block-post-title { box-sizing: border-box; width: 100vw; max-width: 100vw; position: relative; left: 50%; transform: translateX(-50%); margin-inline: 0; margin-top: 0; min-height: 74vh; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 1.2em 6vw; color: #fff; background: linear-gradient(rgba(8, 9, 12, 0.28), rgba(8, 9, 12, 0.55)), var(--gogh-cover-img, linear-gradient(165deg, #1d2233, #0d0e14)) center var(--gogh-cover-pos, 50%) / cover no-repeat; font-size: clamp(2.8rem, 7vw, 5.2rem); line-height: 1.03; letter-spacing: -0.02em; text-wrap: balance; }' .
		'.gogh-read-cover .wp-block-post-title::after { content: var(--gogh-cover-byline, ""); display: block; margin-top: 1.5em; font-size: 0.82rem; font-weight: 600; letter-spacing: 0.22em; text-transform: uppercase; opacity: 0.85; }' .
		// the byline lives on the cover now; the template rows and the
		// featured-image block fold into it
		'.gogh-read-cover :is(.wp-block-post-date, .wp-block-post-author-name, .wp-block-post-author, .wp-block-post-terms) { display: none; }' .
	// the whole byline ROW folds away — its 'Written by' and 'in' are
	// naked sibling paragraphs, so the shared wrapper is the true target
	'.gogh-read-cover main :is(div, p, .wp-block-group, .wp-block-post-meta):has(> .wp-block-post-author-name), .gogh-read-cover main :is(div, p, .wp-block-group, .wp-block-post-meta):has(> .wp-block-post-date) { display: none !important; }' .
		'.gogh-read-cover .wp-block-post-featured-image { display: none; }' .
		'.gogh-read-cover .entry-content { margin-top: 3rem; }' .
		'.gogh-read-cover .entry-content > p, .gogh-read-cover .entry-content > h2, .gogh-read-cover .entry-content > h3 { max-width: 66ch; }' .
		// FLUSH under the nav: the cover is the page's true top — the
		// template's breathing room above content becomes a stray band here
		'.gogh-read-cover main { padding-block-start: 0 !important; }' .
		'.gogh-read-cover main > :first-child { margin-block-start: 0 !important; padding-block-start: 0 !important; }' .
		// under the write room's audition zoom viewport units lie inside
		// the scaled page — the band sizes to its full-width parent there,
		// padding and all. (The look class rides on BODY, so the selector
		// chains it; the old descendant form never matched and the cover
		// sat half off the page — James's Playground screenshot.)
		'body.gogh-w-audition.gogh-read-cover .wp-block-post-title { width: calc(100% + var(--wp--style--root--padding-left, 0px) + var(--wp--style--root--padding-right, 0px)); max-width: none; left: calc(-1 * var(--wp--style--root--padding-left, 0px)); transform: none; }' .
		// writing on the cover: the pseudo byline stays out of the caret's way
		'body.gogh-writing.gogh-read-cover .wp-block-post-title::after { content: none; }' .
		// MANUAL — the reference page: a side table of contents that stays
		// put, section headings you can land on, tables and code that are
		// meant to be read rather than admired. The contents are built by
		// gogh-view from the post's own h2/h3 (two or more), so the look
		// asks nothing of the writer.
		// the title lives in the template's own group: give it the text's measure so the two share a left edge
		'.gogh-read-manual .wp-block-post-title { font-size: clamp(1.7rem, 3vw, 2.5rem); font-weight: 700; letter-spacing: -0.01em; line-height: 1.15; text-align: left; margin-block-end: 0.6em; max-width: 46rem; }' .
		// the contents hang in the left gutter beside the theme's own centred
		// measure (title, headings and text keep one edge); when the gutter
		// is too narrow they sit boxed above the text instead
		'.gogh-read-manual .entry-content > :not(.gogh-toc) { max-width: 46rem; }' .
		'.gogh-toc-side { position: fixed; top: 96px; width: 220px; max-height: calc(100vh - 120px); overflow-y: auto; scrollbar-width: thin; z-index: 5; }' .
		'.gogh-read-manual .entry-content > .gogh-toc-boxed { max-width: 46rem; margin-block-end: 2em; padding: 0.9em 1.1em; border: 1px solid color-mix(in srgb, currentColor 14%, transparent); border-radius: 8px; }' .
		'.gogh-toc-boxed ol { border-left: 0; } .gogh-toc-boxed a { padding-left: 0; border-left: 0; } .gogh-toc-boxed li.gogh-toc-h3 a { padding-left: 14px; }' .
		// the writing room's contents: read-only, beside the column, never inside the content
		'.gogh-toc-room { position: fixed; top: 112px; width: 220px; max-height: calc(100vh - 140px); overflow-y: auto; z-index: 5; }' .
		'.gogh-toc-room a { cursor: pointer; }' .
		// the audition shows the column too (James) — placed clear of the looks list, or not at all
		'.gogh-toc-room[hidden] { display: none; }' .
		'.gogh-read-manual .entry-content > .wp-block-table, .gogh-read-manual .entry-content > .wp-block-code, .gogh-read-manual .entry-content > pre, .gogh-read-manual .entry-content > figure.wp-block-image.alignwide, .gogh-read-manual .entry-content > figure.wp-block-image.alignfull { max-width: 46rem; }' .
		'.gogh-toc { font-size: 0.86rem; line-height: 1.45; padding-right: 8px; }' .
		'.gogh-toc-title { display: block; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; opacity: 0.6; margin-block-end: 0.8em; }' .
		'.gogh-toc ol { list-style: none; margin: 0; padding: 0; border-left: 1px solid color-mix(in srgb, currentColor 18%, transparent); }' .
		'.gogh-toc li { margin: 0; }' .
		'.gogh-toc a { display: block; padding: 0.35em 0 0.35em 14px; margin-left: -1px; border-left: 2px solid transparent; color: inherit; text-decoration: none; opacity: 0.72; }' .
		'.gogh-toc a:hover { opacity: 1; }' .
		'.gogh-toc a.is-here { opacity: 1; font-weight: 600; border-left-color: currentColor; }' .
		'.gogh-toc li.gogh-toc-h3 a { padding-left: 28px; font-size: 0.94em; }' .
		'.gogh-read-manual .entry-content > h2 { margin-block-start: 2.2em; padding-block-top: 0.9em; padding-top: 0.9em; border-top: 1px solid color-mix(in srgb, currentColor 14%, transparent); font-size: 1.45em; letter-spacing: -0.01em; }' .
		'.gogh-read-manual .entry-content > h3 { margin-block-start: 1.6em; font-size: 1.12em; }' .
		'.gogh-read-manual .entry-content :is(h2, h3, h4) { scroll-margin-top: 32px; }' .
		'.gogh-read-manual .entry-content > p, .gogh-read-manual .entry-content > ul, .gogh-read-manual .entry-content > ol { line-height: 1.65; }' .
		'.gogh-read-manual .entry-content li { margin-block-end: 0.35em; }' .
		// tables read as tables: full measure, a real header row, quiet stripes
		'.gogh-read-manual .entry-content .wp-block-table { overflow-x: auto; }' .
		'.gogh-read-manual .entry-content .wp-block-table table { width: 100%; border-collapse: collapse; font-size: 0.92em; border: 1px solid color-mix(in srgb, currentColor 16%, transparent); }' .
		'.gogh-read-manual .entry-content .wp-block-table :is(th, td) { padding: 0.55em 0.8em; border: 1px solid color-mix(in srgb, currentColor 12%, transparent); text-align: left; vertical-align: top; }' .
		'.gogh-read-manual .entry-content .wp-block-table th, .gogh-read-manual .entry-content .wp-block-table thead td { background: color-mix(in srgb, currentColor 8%, transparent); font-weight: 600; }' .
		'.gogh-read-manual .entry-content .wp-block-table tbody tr:nth-child(even) td { background: color-mix(in srgb, currentColor 3.5%, transparent); }' .
		// code sits on a quiet panel; inline code wears a light tint
		'.gogh-read-manual .entry-content :is(pre, .wp-block-code) { background: color-mix(in srgb, currentColor 6%, transparent); border: 1px solid color-mix(in srgb, currentColor 12%, transparent); border-radius: 8px; padding: 1em 1.2em; font-size: 0.88em; line-height: 1.55; overflow-x: auto; tab-size: 2; }' .
		'.gogh-read-manual .entry-content :not(pre) > code { background: color-mix(in srgb, currentColor 8%, transparent); border-radius: 4px; padding: 0.1em 0.35em; font-size: 0.9em; }' .
		// notes: a blockquote is a callout here, not a pull-quote
		'.gogh-read-manual .entry-content blockquote { border-left: 3px solid currentColor; background: color-mix(in srgb, currentColor 4%, transparent); padding: 0.8em 1.1em; margin-inline: 0; font-style: normal; font-size: 0.95em; border-radius: 0 8px 8px 0; }' .
		'.gogh-read-manual .entry-content blockquote p { margin: 0; }' .
		'.gogh-read-manual .entry-content blockquote cite { display: block; margin-top: 0.4em; font-size: 0.85em; opacity: 0.7; }' .
		// the writing room and phones: one column, the contents fold above the text
		gogh_reading_wow_css();
}

// menus heal themselves: trashing a page removes its links from every
// menu ("i deleted some pages and now the menu looks broken" — core
// leaves a hole where the dead link was). Untrash re-adds nothing; a
// restored page is one drag away in the nav editor.
// a front-door draft is deliberately blank (title, content and excerpt) —
// WordPress refuses to update such a post at all, so it could not even be
// trashed ("Error moving page to trash"). Blank gogh pages may be updated.
add_filter( 'wp_insert_post_empty_content', function ( $maybe_empty, $postarr ) {
	if ( ! $maybe_empty ) {
		return $maybe_empty;
	}
	$id = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
	if ( $id && get_post_meta( $id, '_gogh_door', true ) ) {
		return false;
	}
	// any page on its way to the trash may be empty — the trash is not a save
	if ( isset( $postarr['post_type'], $postarr['post_status'] ) && 'page' === $postarr['post_type'] && 'trash' === $postarr['post_status'] ) {
		return false;
	}
	return $maybe_empty;
}, 10, 2 );
add_action( 'trashed_post', function ( $post_id ) {
	$type = get_post_type( $post_id );
	if ( ! in_array( $type, array( 'page', 'post' ), true ) ) {
		return;
	}
	$navs = get_posts( array(
		'post_type'   => 'wp_navigation',
		'post_status' => 'publish',
		'numberposts' => 20,
	) );
	foreach ( $navs as $nav ) {
		if ( false === strpos( $nav->post_content, '"id":' . $post_id ) ) {
			continue;
		}
		$cleaned = preg_replace_callback(
			'/<!--\s*wp:navigation-link\s+({[\s\S]*?})\s*\/-->/',
			function ( $m ) use ( $post_id ) {
				$attrs = json_decode( $m[1], true );
				return ( is_array( $attrs ) && isset( $attrs['id'] ) && (int) $attrs['id'] === (int) $post_id ) ? '' : $m[0];
			},
			$nav->post_content
		);
		if ( null !== $cleaned && $cleaned !== $nav->post_content ) {
			wp_update_post( array( 'ID' => $nav->ID, 'post_content' => $cleaned ) );
		}
	}
} );

function gogh_starters() {
	$out = array();
	foreach ( glob( __DIR__ . '/starters/*/manifest.json' ) as $mf ) {
		$slug = basename( dirname( $mf ) );
		$m    = json_decode( file_get_contents( $mf ), true );
		if ( $m && ! empty( $m['pages'] ) ) {
			$m['slug']    = $slug;
			$out[ $slug ] = $m;
		}
	}
	return $out;
}
// ---- the parts of a starter that are not its pages: shared by the starter
// route (a starter on disk) and a site definition (a site from a chat) ----
// the menu from the pages made, the header and footer patterns wearing it
function gogh_starter_apply_chrome( $m, $made ) {
			$links = '';
			// a ONE-PAGE site has one page, so a menu made of pages says nothing.
			// A definition can name its own menu instead — labels pointing at the
			// anchors its sections carry ( #work ), which scroll rather than load.
			// Absolute, so the same menu still works from a post or the 404.
			foreach ( (array) ( isset( $m['nav'] ) ? $m['nav'] : array() ) as $item ) {
				if ( ! is_array( $item ) || empty( $item['label'] ) ) {
					continue;
				}
				$href = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';
				if ( preg_match( '/^#[A-Za-z][A-Za-z0-9-]*$/', $href ) ) {
					$href = home_url( '/' ) . strtolower( $href );
				}
				if ( ! $href ) {
					continue;
				}
				$links .= '<!-- wp:navigation-link {"label":"' . esc_attr( $item['label'] ) .
					'","url":"' . esc_url( $href ) . '","kind":"custom","isTopLevelLink":true} /-->';
			}
			foreach ( $links ? array() : $made as $c ) {
				if ( ! empty( $c['no_menu'] ) ) {
					continue;
				}
				$links .= '<!-- wp:navigation-link {"label":"' . esc_attr( $c['title'] ) . '","type":"page","id":' . $c['id'] .
					',"url":"' . esc_url( get_permalink( $c['id'] ) ) . '","kind":"post-type"} /-->';
			}
			// re-use a same-named menu rather than minting a new wp_navigation
			// post on every apply — otherwise re-running a starter litters the
			// "swap menus" list with a fresh "Café menu" each time
			$nav_title = $m['name'] . ' menu';
			$found = new WP_Query( array(
				'post_type'      => 'wp_navigation',
				'post_status'    => 'publish',
				'title'          => $nav_title,
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			) );
			$nav_id = $found->posts ? (int) $found->posts[0] : 0;
			if ( $nav_id ) {
				wp_update_post( array( 'ID' => $nav_id, 'post_content' => $links ) );
			} else {
				$nav_id = wp_insert_post( array(
					'post_type'    => 'wp_navigation',
					'post_status'  => 'publish',
					'post_title'   => $nav_title,
					'post_content' => $links,
				) );
			}
			// point the live header's menu at the new navigation
			$part = get_block_template( get_stylesheet() . '//header', 'wp_template_part' );
			if ( $part && $nav_id && ! is_wp_error( $nav_id ) ) {
				$praw = (string) $part->content;
				// a starter may choose one of gogh's own headers — the Yellow
				// House floats the transparent overlay over its hero
				if ( ! empty( $m['chrome']['header'] ) ) {
					$pfile = __DIR__ . '/patterns/' . sanitize_file_name( $m['chrome']['header'] ) . '.html';
					if ( is_readable( $pfile ) ) {
						$praw = file_get_contents( $pfile );
					}
					// a one-page site's menu is only useful if it is still there at the
					// bottom of the page — the same class the header room's sticky door sets
					if ( ! empty( $m['chrome']['sticky'] ) && false === strpos( $praw, 'gogh-sticky' ) ) {
						$praw = preg_replace( '/gogh-hrow/', 'gogh-hrow gogh-sticky', $praw, 2 );
						// a pattern without the row class (split and centred once lacked it)
						// silently stayed unpinned — mark the first group regardless, the way
						// the header room's own switch does
						if ( false === strpos( $praw, 'gogh-sticky' ) ) {
							$praw = preg_replace( '/^(<!-- wp:group \{)/', '$1"className":"gogh-sticky",', $praw, 1 );
							$praw = preg_replace( '/(<div class="wp-block-group)/', '$1 gogh-sticky', $praw, 1 );
						}
					}
				}
				$next = '';
				if ( preg_match( '/wp:navigation[^>]*"ref":\d+/', $praw ) ) {
					$next = preg_replace( '/("ref":)\d+/', '${1}' . $nav_id, $praw, 1 );
				} elseif ( preg_match( '/<!--\s+wp:navigation\s+\{/', $praw ) ) {
					$next = preg_replace( '/(<!--\s+wp:navigation\s+\{)/', '${1}"ref":' . $nav_id . ',', $praw, 1 );
				} else {
					$next = preg_replace( '/(<!--\s+wp:navigation)(\s+-->)/', '${1} {"ref":' . $nav_id . '}${2}', $praw, 1 );
				}
				if ( $next && $next !== $praw ) {
					if ( ! empty( $part->wp_id ) ) {
						wp_update_post( array( 'ID' => $part->wp_id, 'post_content' => $next ) );
					} else {
						$pid = wp_insert_post( array(
							'post_type'    => 'wp_template_part',
							'post_status'  => 'publish',
							'post_title'   => 'header',
							'post_name'    => 'header',
							'post_content' => $next,
						) );
						if ( $pid && ! is_wp_error( $pid ) ) {
							wp_set_post_terms( $pid, array( get_stylesheet() ), 'wp_theme' );
							wp_set_post_terms( $pid, array( 'header' ), 'wp_template_part_area' );
						}
					}
				}
			}
			// and one of gogh's own footers, the same way (a theme's default
			// footer is a sampler of dummy links no real site wants)
			if ( ! empty( $m['chrome']['footer'] ) && $nav_id && ! is_wp_error( $nav_id ) ) {
				$ffile = __DIR__ . '/patterns/' . sanitize_file_name( $m['chrome']['footer'] ) . '.html';
				if ( is_readable( $ffile ) ) {
					$fraw = file_get_contents( $ffile );
					if ( preg_match( '/wp:navigation[^>]*"ref":\d+/', $fraw ) ) {
						$fnext = preg_replace( '/("ref":)\d+/', '${1}' . $nav_id, $fraw, 1 );
					} elseif ( preg_match( '/<!--\s+wp:navigation\s+\{/', $fraw ) ) {
						$fnext = preg_replace( '/(<!--\s+wp:navigation\s+\{)/', '${1}"ref":' . $nav_id . ',', $fraw, 1 );
					} else {
						$fnext = preg_replace( '/(<!--\s+wp:navigation)(\s+-->)/', '${1} {"ref":' . $nav_id . '}${2}', $fraw, 1 );
					}
					$fpart = get_block_template( get_stylesheet() . '//footer', 'wp_template_part' );
					if ( $fpart && ! empty( $fpart->wp_id ) ) {
						wp_update_post( array( 'ID' => $fpart->wp_id, 'post_content' => $fnext ) );
					} else {
						$fpid = wp_insert_post( array(
							'post_type'    => 'wp_template_part',
							'post_status'  => 'publish',
							'post_title'   => 'footer',
							'post_name'    => 'footer',
							'post_content' => $fnext,
						) );
						if ( $fpid && ! is_wp_error( $fpid ) ) {
							wp_set_post_terms( $fpid, array( get_stylesheet() ), 'wp_theme' );
							wp_set_post_terms( $fpid, array( 'footer' ), 'wp_template_part_area' );
						}
					}
				}
			}
			// the design brings its own look: apply the named theme style
			// variation to user global styles. The user's saved gogh brand is
			// untouched and can be re-applied from Your brand at any time.
}
// the theme variation, the palette over it, then the styles on top
// every image filter out of a styles tree ('filter' => array( 'duotone' => … ))
function gogh_strip_duotone( $styles ) {
	if ( ! is_array( $styles ) ) {
		return $styles;
	}
	foreach ( $styles as $k => $v ) {
		if ( 'filter' === $k && is_array( $v ) && isset( $v['duotone'] ) ) {
			unset( $styles[ $k ]['duotone'] );
			if ( ! $styles[ $k ] ) {
				unset( $styles[ $k ] );
			}
		} elseif ( is_array( $v ) ) {
			$styles[ $k ] = gogh_strip_duotone( $v );
		}
	}
	return $styles;
}
function gogh_starter_apply_styles( $m ) {
			$applied_variation = '';
			if ( ! empty( $m['variation'] ) && class_exists( 'WP_Theme_JSON_Resolver' ) ) {
				foreach ( WP_Theme_JSON_Resolver::get_style_variations() as $v ) {
					if ( isset( $v['title'] ) && 0 === strcasecmp( $v['title'], $m['variation'] ) ) {
						$applied_variation = $m['variation'];
						$gs_id = WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
						if ( $gs_id ) {
							wp_update_post( array(
								'ID'           => $gs_id,
								// slashed: wp_update_post unslashes its input, and a variation whose
								// font names carry \"quotes\" (Morning's Ysabeau Office) came back as
								// broken JSON that the palette merge below could not read — the site
								// kept the colours and lost the type
								'post_content' => wp_slash( wp_json_encode( array(
									'version'                     => class_exists( 'WP_Theme_JSON' ) ? WP_Theme_JSON::LATEST_SCHEMA : 3,
									'isGlobalStylesUserThemeJSON' => true,
									'settings'                    => isset( $v['settings'] ) ? $v['settings'] : new stdClass(),
									'styles'                      => isset( $v['styles'] ) ? $v['styles'] : new stdClass(),
								) ) ),
							) );
						}
						break;
					}
				}
			}
			// remember which style the site now wears — WP itself forgets the
			// variation's name the moment it's copied into user global styles.
			// Only when it truly applied: a design's variation is a Twenty
			// Twenty-Five name, and on another theme (James switched to Ollie)
			// nothing matched — recording it anyway would have the Site style
			// panel claim a look the site never put on.
			if ( '' !== $applied_variation ) {
				update_option( 'gogh_active_style', $applied_variation );
			}
			// a starter may carry a bespoke PALETTE: theme palette slugs are
			// re-coloured (base/contrast keep roles, accents cycle), applied
			// as user global styles — same mechanism as Your brand
			if ( ! empty( $m['palette'] ) && class_exists( 'WP_Theme_JSON_Resolver' ) ) {
				$theme_pal = wp_get_global_settings( array( 'color', 'palette', 'theme' ) );
				if ( is_array( $theme_pal ) && $theme_pal ) {
					$pal     = $m['palette'];
					$accents = isset( $pal['accents'] ) && is_array( $pal['accents'] ) ? array_values( $pal['accents'] ) : array();
					$ai      = 0;
					$out_pal = array();
					// $pslug, not $slug: this loop used to reuse the starter's own
					// $slug and left it reading 'accent-6', so everything after the
					// palette looked for its files in starters/accent-6/
					foreach ( $theme_pal as $entry ) {
						$pslug = isset( $entry['slug'] ) ? $entry['slug'] : '';
						if ( ( 'base' === $pslug || 'background' === $pslug ) && ! empty( $pal['base'] ) ) {
							$entry['color'] = $pal['base'];
						} elseif ( ( 'contrast' === $pslug || 'text' === $pslug || 'foreground' === $pslug ) && ! empty( $pal['contrast'] ) ) {
							$entry['color'] = $pal['contrast'];
						} elseif ( $accents && 0 === strpos( $pslug, 'accent' ) ) {
							$entry['color'] = $accents[ $ai % count( $accents ) ];
							$ai++;
						}
						$out_pal[] = $entry;
					}
					$gs_id = WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
					if ( $gs_id ) {
						// merged into what the variation (above) just wrote: a design
						// can bring both its type and its own colours (the palette
						// used to be written alone, and a variation applied after it
						// replaced the whole user styles post, palette included)
						$gs_post = get_post( $gs_id );
						$gs      = $gs_post ? json_decode( (string) $gs_post->post_content, true ) : null;
						if ( ! is_array( $gs ) ) {
							$gs = array();
						}
						$gs['version']                     = class_exists( 'WP_Theme_JSON' ) ? WP_Theme_JSON::LATEST_SCHEMA : 3;
						$gs['isGlobalStylesUserThemeJSON'] = true;
						if ( empty( $gs['settings'] ) || ! is_array( $gs['settings'] ) ) {
							$gs['settings'] = array();
						}
						if ( empty( $gs['settings']['color'] ) || ! is_array( $gs['settings']['color'] ) ) {
							$gs['settings']['color'] = array();
						}
						$gs['settings']['color']['palette'] = array( 'theme' => $out_pal );
						if ( empty( $gs['styles'] ) ) {
							$gs['styles'] = new stdClass();
						} elseif ( is_array( $gs['styles'] ) ) {
							// a variation's picture filter (Midnight's purple and green
							// duotone) was drawn for the variation's own colours; with
							// a design's own palette it only stains every photograph
							$gs['styles'] = gogh_strip_duotone( $gs['styles'] );
						}
						wp_update_post( array(
							'ID'           => $gs_id,
							'post_content' => wp_slash( wp_json_encode( $gs ) ), // wp_update_post unslashes: a variation's \"quoted\" font names would break the JSON
						) );
					}
				}
			}
			// a starter may also bring a few STYLE decisions the variation
			// leaves wrong for it (Morning paints button words in the contrast
			// colour, which on a cobalt button is ink on blue): merged into
			// the same user global styles, after the variation and palette
			if ( ! empty( $m['styles'] ) && is_array( $m['styles'] ) && class_exists( 'WP_Theme_JSON_Resolver' ) ) {
				$gs_id = WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
				if ( $gs_id ) {
					$gs_post = get_post( $gs_id );
					$gs      = $gs_post ? json_decode( (string) $gs_post->post_content, true ) : null;
					if ( ! is_array( $gs ) ) {
						$gs = array();
					}
					$gs['version']                     = class_exists( 'WP_Theme_JSON' ) ? WP_Theme_JSON::LATEST_SCHEMA : 3;
					$gs['isGlobalStylesUserThemeJSON'] = true;
					$cur                               = ( ! empty( $gs['styles'] ) && is_array( $gs['styles'] ) ) ? $gs['styles'] : array();
					$gs['styles']                      = array_replace_recursive( $cur, $m['styles'] );
					if ( empty( $gs['settings'] ) ) {
						$gs['settings'] = new stdClass();
					}
					wp_update_post( array(
						'ID'           => $gs_id,
						'post_content' => wp_slash( wp_json_encode( $gs ) ), // wp_update_post unslashes: a variation's \"quoted\" font names would break the JSON
					) );
				}
			}
			// a shop design brings its shelves stocked: categories, an
			// attribute or two, and the products themselves (rails data,
			// so the canvas has something to sell from day one)
}
// ---------- a site from a definition ----------
// Stage one of "chat to an AI, get a blueprint". A definition is content and
// choices — pages of takes from the shelf, filled by role — never geometry.
// PHP makes the pages, posts, menu, chrome and palette; the editor draws the
// sections on first load (?gogh-build=1) through its own bridge, so the
// server needs no browser and the takes carry the taste.
function gogh_site_def_boot( $def ) {
	if ( ! is_array( $def ) || empty( $def['pages'] ) || ! is_array( $def['pages'] ) ) {
		return new WP_Error( 'gogh_bad_def', __( 'The site definition needs at least one page.', 'gogh-editor' ), array( 'status' => 400 ) );
	}
	$made  = array();
	$ids   = array();
	$front = 0;
	$blog  = 0;
	foreach ( array_values( $def['pages'] ) as $i => $pg ) {
		if ( ! is_array( $pg ) ) {
			continue;
		}
		$title = sanitize_text_field( isset( $pg['title'] ) ? $pg['title'] : 'Page' );
		$id    = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_name'    => sanitize_title( ! empty( $pg['slug'] ) ? $pg['slug'] : $title ),
			'post_content' => '',
		) );
		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}
		$ids[ $i ] = (int) $id;
		$made[]    = array( 'id' => (int) $id, 'title' => $title, 'no_menu' => isset( $pg['menu'] ) && false === $pg['menu'] );
		if ( ! empty( $pg['front'] ) ) {
			$front = (int) $id;
		}
		if ( ! empty( $pg['blog'] ) ) {
			$blog = (int) $id;
		}
	}
	if ( ! $made ) {
		return new WP_Error( 'gogh_bad_def', __( 'No page could be made.', 'gogh-editor' ), array( 'status' => 500 ) );
	}
	// a design's own CSS goes into WordPress's Additional CSS (the person can
	// read and change it there), between markers so a rebuild replaces it
	if ( ! empty( $def['css'] ) && is_string( $def['css'] ) ) {
		$css  = wp_strip_all_tags( substr( $def['css'], 0, 65536 ) );
		// WordPress prints Additional CSS at the END of the global styles, where
		// an @import is ignored: web-font imports are lifted out and loaded as
		// stylesheet links instead (Google Fonts only)
		$fonts = array();
		$css   = preg_replace_callback( '#@import\s+url\(\s*["\']?(https://fonts\.googleapis\.com/[^"\')\s]+)["\']?\s*\)\s*;?#i', function ( $m ) use ( &$fonts ) {
			$fonts[] = esc_url_raw( $m[1] );
			return '';
		}, $css );
		update_option( 'gogh_site_font_urls', array_slice( array_values( array_unique( array_filter( $fonts ) ) ), 0, 4 ), false );
		$prev = preg_replace( '#\n?/\* gogh:site-css start \*/.*?/\* gogh:site-css end \*/\n?#s', '', (string) wp_get_custom_css() );
		wp_update_custom_css_post( trim( $prev . "\n/* gogh:site-css start */\n" . $css . "\n/* gogh:site-css end */\n" ) );
	}
	// the design's named looks and its own sections (see gogh_site_design_clean):
	// kept for the editor and the block editor; a design without them clears
	// the last one's, so a rebuild never inherits another design's chips
	$design = gogh_site_design_clean( $def );
	if ( $design ) {
		update_option( 'gogh_site_design', $design, true );
	} else {
		delete_option( 'gogh_site_design' );
	}
	// posts: plain text becomes paragraphs; block markup passes through. A
	// post may carry its own date (an archive that reads as one, not eight
	// posts written in the same second), an excerpt and a slug
	$gogh_newest = 0;
	$gogh_newest_at = '';
	foreach ( (array) ( isset( $def['posts'] ) ? $def['posts'] : array() ) as $ps ) {
		if ( ! is_array( $ps ) || empty( $ps['title'] ) ) {
			continue;
		}
		$body = isset( $ps['content'] ) ? (string) $ps['content'] : (string) ( isset( $ps['text'] ) ? $ps['text'] : '' );
		if ( false === strpos( $body, '<!-- wp:' ) ) {
			$paras = preg_split( '/\n\s*\n/', trim( $body ) );
			$body  = implode( "\n", array_map( function ( $pp ) {
				return '<!-- wp:paragraph --><p>' . wp_kses_post( trim( $pp ) ) . '</p><!-- /wp:paragraph -->';
			}, array_filter( $paras ) ) );
		}
		$gogh_post = array(
			'post_type'    => 'post',
			'post_status'  => 'publish',
			'post_title'   => sanitize_text_field( $ps['title'] ),
			'post_content' => wp_slash( $body ),
		);
		if ( ! empty( $ps['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?$/', (string) $ps['date'] ) ) {
			$gogh_post['post_date'] = strlen( $ps['date'] ) === 10 ? $ps['date'] . ' 09:00:00' : $ps['date'] . ':00';
		}
		if ( ! empty( $ps['excerpt'] ) ) {
			$gogh_post['post_excerpt'] = sanitize_textarea_field( (string) $ps['excerpt'] );
		}
		if ( ! empty( $ps['slug'] ) ) {
			$gogh_post['post_name'] = sanitize_title( (string) $ps['slug'] );
		}
		$pid = wp_insert_post( $gogh_post );
		if ( ! $pid || is_wp_error( $pid ) ) {
			continue;
		}
		// a post can be filed: 'cats' names its categories, made as needed
		if ( ! empty( $ps['cats'] ) ) {
			$gogh_cat_ids = array();
			foreach ( array_slice( (array) $ps['cats'], 0, 5 ) as $gogh_cn ) {
				$gogh_cn = sanitize_text_field( (string) $gogh_cn );
				if ( '' === $gogh_cn ) {
					continue;
				}
				$gogh_t = term_exists( $gogh_cn, 'category' );
				if ( ! $gogh_t ) {
					$gogh_t = wp_insert_term( $gogh_cn, 'category' );
				}
				if ( $gogh_t && ! is_wp_error( $gogh_t ) ) {
					$gogh_cat_ids[] = (int) ( is_array( $gogh_t ) ? $gogh_t['term_id'] : $gogh_t );
				}
			}
			if ( $gogh_cat_ids ) {
				wp_set_post_categories( $pid, $gogh_cat_ids );
			}
		}
		$gogh_at = get_post_field( 'post_date', $pid );
		if ( ! $gogh_newest || strcmp( (string) $gogh_at, $gogh_newest_at ) > 0 ) {
			$gogh_newest    = (int) $pid;
			$gogh_newest_at = (string) $gogh_at;
		}
		if ( ! empty( $ps['image'] ) ) {
			$aid = gogh_site_def_picture( (string) $ps['image'], (int) $pid, sanitize_text_field( $ps['title'] ) );
			if ( $aid ) {
				set_post_thumbnail( $pid, $aid );
			}
		}
	}
	$m = array(
		'name'      => sanitize_text_field( ! empty( $def['name'] ) ? $def['name'] : 'Site' ),
		'chrome'    => ( isset( $def['chrome'] ) && is_array( $def['chrome'] ) ) ? $def['chrome'] : array(),
		'nav'       => ( isset( $def['nav'] ) && is_array( $def['nav'] ) ) ? $def['nav'] : array(),
		'variation' => isset( $def['variation'] ) ? sanitize_text_field( $def['variation'] ) : '',
		'palette'   => ( isset( $def['palette'] ) && is_array( $def['palette'] ) ) ? $def['palette'] : null,
		'styles'    => ( isset( $def['styles'] ) && is_array( $def['styles'] ) ) ? $def['styles'] : null,
	);
	try {
		gogh_starter_apply_chrome( $m, $made );
	} catch ( \Throwable $e ) {}
	try {
		gogh_starter_apply_styles( $m );
	} catch ( \Throwable $e ) {}
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front ? $front : $made[0]['id'] );
	update_option( 'page_for_posts', $blog ? $blog : 0 );
	if ( ! empty( $def['name'] ) ) {
		update_option( 'blogname', sanitize_text_field( $def['name'] ) );
	}
	if ( isset( $def['tagline'] ) ) {
		update_option( 'blogdescription', sanitize_text_field( $def['tagline'] ) );
	}
	// photographers get their name on the site: the picture libraries ask for
	// it, and a site that credits its pictures is a site someone can publish
	if ( ! empty( $def['credits'] ) && is_array( $def['credits'] ) ) {
		$credits = array();
		foreach ( array_slice( $def['credits'], 0, 20 ) as $c ) {
			if ( empty( $c['name'] ) ) {
				continue;
			}
			$credits[] = array(
				'name' => sanitize_text_field( $c['name'] ),
				'link' => ! empty( $c['link'] ) ? esc_url_raw( $c['link'] ) : '',
			);
		}
		if ( $credits ) {
			update_option( 'gogh_picture_credits', $credits, false );
		}
	}
	// the posts page's look (the blog styles: list, cards, cover, ledger)
	// a posts section can ask for one category by name: the editor's grid
	// needs its id, known only now the posts are filed
	foreach ( (array) ( isset( $def['pages'] ) ? $def['pages'] : array() ) as $gogh_pi => $gogh_pg ) {
		foreach ( (array) ( isset( $gogh_pg['sections'] ) ? $gogh_pg['sections'] : array() ) as $gogh_si => $gogh_sc ) {
			if ( ! is_array( $gogh_sc ) || empty( $gogh_sc['posts']['cat'] ) || ! empty( $gogh_sc['posts']['catId'] ) ) {
				continue;
			}
			$gogh_t = get_term_by( 'name', sanitize_text_field( (string) $gogh_sc['posts']['cat'] ), 'category' );
			if ( $gogh_t ) {
				$def['pages'][ $gogh_pi ]['sections'][ $gogh_si ]['posts']['catId'] = (int) $gogh_t->term_id;
			}
		}
	}
	if ( isset( $def['blog_look'] ) && in_array( (string) $def['blog_look'], gogh_blog_styles(), true ) ) {
		update_option( 'gogh_blog_style', (string) $def['blog_look'] );
	}
	// a writer's site opens where the writing is: the newest post, in the
	// writing room, once the pages are drawn
	$gogh_open = ( isset( $def['open'] ) && 'writing' === $def['open'] && $gogh_newest )
		? add_query_arg( 'gogh-write', '1', get_permalink( $gogh_newest ) ) : '';
	// the editor reads this on ?gogh-build=1, draws every page, then deletes it
	update_option( 'gogh_site_def', array( 'def' => $def, 'pages' => $ids, 'open' => $gogh_open ), false );
	return array( 'pages' => $ids, 'home' => get_permalink( $front ? $front : $made[0]['id'] ) );
}
// ---------- a design's named looks ------------------------------------------
// A definition can name LOOKS for a kind of piece ("Yellow print" for a
// button, "Misregistered" for a heading) and mark one as the default. A look
// is a WordPress block style: its class is is-style-<slug>, the design's own
// CSS styles that class, gogh dresses every new piece in the default, and the
// block editor's Styles panel lists the same names. A definition can also
// bring a SHELF of its own sections, offered first in the section picker.
function gogh_site_design_types() {
	return array(
		'heading' => 'core/heading',
		'para'    => 'core/paragraph',
		'button'  => 'core/button',
		'image'   => 'core/image',
		// shapes and cards publish as core/group: a style registered there
		// would sit on every group in the block editor, so theirs stay gogh's
		'box'     => '',
	);
}
function gogh_site_design_clean( $def ) {
	if ( ! is_array( $def ) ) {
		return null;
	}
	// names core already gives these blocks: a look may not shadow them
	$reserved = array( 'default', 'fill', 'outline', 'rounded', 'squared', 'regular', 'large', 'plain-core' );
	$looks    = array();
	if ( ! empty( $def['looks'] ) && is_array( $def['looks'] ) ) {
		foreach ( array_keys( gogh_site_design_types() ) as $type ) {
			if ( empty( $def['looks'][ $type ] ) || ! is_array( $def['looks'][ $type ] ) ) {
				continue;
			}
			$list     = array();
			$seen     = array();
			$has_def  = false;
			foreach ( array_slice( array_values( $def['looks'][ $type ] ), 0, 6 ) as $lk ) {
				if ( ! is_array( $lk ) || empty( $lk['name'] ) || ! is_string( $lk['name'] ) ) {
					continue;
				}
				$name = sanitize_text_field( mb_substr( $lk['name'], 0, 32 ) );
				$slug = sanitize_title( $name );
				if ( '' === $name || ! preg_match( '/^[a-z][a-z0-9-]{0,29}$/', $slug ) || isset( $seen[ $slug ] ) || in_array( $slug, $reserved, true ) ) {
					continue;
				}
				$seen[ $slug ] = true;
				$is_def        = ! empty( $lk['default'] ) && ! $has_def;
				$has_def       = $has_def || $is_def;
				$list[]        = array( 'name' => $name, 'slug' => $slug, 'default' => $is_def );
			}
			if ( $list ) {
				$looks[ $type ] = $list;
			}
		}
	}
	// the shelf: whole sections in the definition's own format. The editor
	// draws them through the same door as the pages (genEl whitelists every
	// field), so here they are only bounded
	$shelf = array();
	if ( ! empty( $def['shelf'] ) && is_array( $def['shelf'] ) ) {
		foreach ( array_slice( array_values( $def['shelf'] ), 0, 8 ) as $sc ) {
			if ( ! is_array( $sc ) || empty( $sc['els'] ) || ! is_array( $sc['els'] ) ) {
				continue;
			}
			$sc['name'] = sanitize_text_field( mb_substr( isset( $sc['name'] ) ? (string) $sc['name'] : 'Section', 0, 40 ) );
			$sc['note'] = sanitize_text_field( mb_substr( isset( $sc['note'] ) ? (string) $sc['note'] : '', 0, 80 ) );
			if ( strlen( wp_json_encode( $sc ) ) > 32768 ) {
				continue;
			}
			$shelf[] = $sc;
		}
	}
	if ( ! $looks && ! $shelf ) {
		return null;
	}
	return array(
		'name'  => sanitize_text_field( ! empty( $def['name'] ) ? $def['name'] : 'this design' ),
		'looks' => (object) $looks,
		'shelf' => $shelf,
	);
}
// the looks as block styles: the block editor's Styles panel offers the same
// names, and choosing one there writes the same class gogh writes
add_action( 'init', function () {
	$design = get_option( 'gogh_site_design' );
	if ( ! is_array( $design ) || empty( $design['looks'] ) || ! function_exists( 'register_block_style' ) ) {
		return;
	}
	$map = gogh_site_design_types();
	$reg = class_exists( 'WP_Block_Styles_Registry' ) ? WP_Block_Styles_Registry::get_instance() : null;
	foreach ( (array) $design['looks'] as $type => $list ) {
		if ( empty( $map[ $type ] ) || ! is_array( $list ) ) {
			continue;
		}
		foreach ( $list as $lk ) {
			if ( empty( $lk['slug'] ) || ( $reg && $reg->is_registered( $map[ $type ], $lk['slug'] ) ) ) {
				continue;
			}
			register_block_style( $map[ $type ], array( 'name' => $lk['slug'], 'label' => $lk['name'] ) );
		}
	}
}, 20 );
// for the editor: the looks and the shelf, or null when the site has none
function gogh_site_design_for_editor() {
	$design = get_option( 'gogh_site_design' );
	return is_array( $design ) ? $design : null;
}

// ---------- launch counter --------------------------------------------------
// A blueprint writes gogh_booted_as when it boots (each blueprint's runPHP
// names itself). The first page after that sends one beacon to the helper:
// the blueprint's name and the plugin version, nothing else, and the option
// flips first so a lost ping is never retried. The helper ignores localhost
// and Studio by origin, keeps the totals in KV, and hands them back from
// /api/boot for the Plugins screen and the demo README.
// web fonts a definition's CSS asked for (see gogh_site_def_boot): loaded as
// links on the site and in the editor, since an @import inside Additional CSS
// is ignored
add_action( 'wp_enqueue_scripts', function () {
	foreach ( (array) get_option( 'gogh_site_font_urls', array() ) as $i => $url ) {
		if ( is_string( $url ) && 0 === strpos( $url, 'https://fonts.googleapis.com/' ) ) {
			wp_enqueue_style( 'gogh-site-font-' . $i, $url, array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- the font host versions its own files
		}
	}
} );

// ---------- the Make door: a chat that builds the site it lives in ----------
// /?gogh-make=1 is a whole page of its own (no theme): the conversation runs
// on the helper, and when a site is published this page applies it here and
// runs the build. blueprint-make.json lands on it.
function gogh_make_ids() {
	return array_map( 'intval', get_posts( array(
		'post_type'      => array( 'page', 'post' ),
		'post_status'    => 'any',
		'numberposts'    => -1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'suppress_filters' => true,
	) ) );
}
function gogh_make_clear() {
	foreach ( (array) get_option( 'gogh_make_made', array() ) as $id ) {
		$id = (int) $id;
		if ( $id && get_post( $id ) ) {
			wp_trash_post( $id );
		}
	}
	delete_option( 'gogh_make_made' );
}
add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['gogh-make'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a read-only door
		return;
	}
	if ( ! is_user_logged_in() ) {
		auth_redirect();
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	gogh_make_page();
	exit;
}, 1 );
function gogh_make_page() {
	$cfg = array(
		'helper' => untrailingslashit( gogh_helper_url() ),
		'rest'   => esc_url_raw( rest_url( 'gogh/v1/' ) ),
		'nonce'  => wp_create_nonce( 'wp_rest' ),
		'build'  => home_url( '/?gogh-edit=1&gogh-build=1' ),
		'built'  => (bool) get_option( 'gogh_make_made' ),
	);
	$site  = home_url( '/' );
	$built = $cfg['built'];
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );
	?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $built ? __( 'Change your website', 'gogh-editor' ) : __( 'Make your website', 'gogh-editor' ) ); ?></title>
<style>
  :root { --paper: #ffffff; --wash: #f5f6fa; --ink: #16181c; --soft: #5f646e; --line: #e3e5ec; --accent: #3858e9; --accent-ink: #ffffff; }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--paper); color: var(--ink); font: 17px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; transition: opacity .35s; }
  body.is-leaving { opacity: .35; }
  .top { position: sticky; top: 0; background: rgba(255,255,255,.94); backdrop-filter: blur(8px); border-bottom: 1px solid var(--line); z-index: 2; }
  .top-in { max-width: 760px; margin: 0 auto; padding: 14px 20px; display: flex; align-items: center; gap: 16px; }
  .brand { font-weight: 800; letter-spacing: -.01em; }
  .top a, .top button { margin-left: auto; font: inherit; font-size: 14px; color: var(--soft); background: none; border: 0; cursor: pointer; text-decoration: none; }
  .top a + button { margin-left: 0; }
  .top a:hover, .top button:hover { color: var(--ink); }
  main { max-width: 760px; margin: 0 auto; padding: 48px 20px 180px; }
  h1 { font-size: clamp(34px, 6vw, 56px); line-height: 1.04; letter-spacing: -.025em; margin: 0 0 14px; font-weight: 800; text-wrap: balance; }
  .lede { color: var(--soft); font-size: 19px; margin: 0 0 28px; max-width: 34em; }
  #chips { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 28px; }
  #chips[hidden] { display: none; }
  #chips button { font: inherit; font-size: 15px; padding: 9px 14px; border-radius: 999px; border: 1px solid var(--line); background: var(--paper); color: var(--ink); cursor: pointer; }
  #chips button:hover { border-color: var(--accent); color: var(--accent); }
  #thread { display: flex; flex-direction: column; gap: 14px; }
  .msg { display: flex; }
  .msg span { padding: 12px 16px; border-radius: 16px; max-width: 34em; white-space: pre-wrap; }
  .msg.you { justify-content: flex-end; }
  .msg.you span { background: var(--accent); color: var(--accent-ink); border-bottom-right-radius: 5px; }
  .msg.you img { max-width: 180px; border-radius: 10px; margin-right: 8px; align-self: flex-end; }
  .msg.gogh span { background: var(--wash); border-bottom-left-radius: 5px; }
  .msg.gogh .dots { color: var(--soft); }
  .msg.gogh .err { background: #fdecec; color: #8a1c1c; }
  .dock { position: fixed; left: 0; right: 0; bottom: 0; background: linear-gradient(transparent, var(--paper) 30%); padding: 26px 20px 22px; }
  form { max-width: 760px; margin: 0 auto; display: flex; gap: 10px; align-items: flex-end; background: var(--paper); border: 1px solid var(--line); border-radius: 18px; padding: 8px; box-shadow: 0 8px 30px rgba(22,24,28,.08); }
  textarea { flex: 1; resize: none; border: 0; outline: none; font: inherit; padding: 10px 10px; min-height: 48px; max-height: 160px; background: transparent; color: var(--ink); }
  .pic { width: 44px; height: 44px; border-radius: 12px; display: grid; place-items: center; color: var(--soft); cursor: pointer; flex: none; }
  .pic:hover { background: var(--wash); color: var(--ink); }
  #go { flex: none; height: 44px; padding: 0 20px; border-radius: 12px; border: 0; background: var(--ink); color: #fff; font: inherit; font-weight: 700; cursor: pointer; }
  #go:disabled { opacity: .45; cursor: default; }
  #shot { display: none; align-items: center; gap: 10px; max-width: 760px; margin: 0 auto 8px; font-size: 14px; color: var(--soft); }
  #shot img { height: 48px; border-radius: 8px; }
  #shot button { font: inherit; font-size: 13px; border: 0; background: none; color: var(--soft); text-decoration: underline; cursor: pointer; }
  .small { font-size: 13px; color: var(--soft); max-width: 760px; margin: 8px auto 0; text-align: center; }
  :focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
  @media (prefers-reduced-motion: reduce) { body { transition: none; } }
</style>
</head><body>
<div class="top"><div class="top-in">
  <span class="brand">gogh</span>
  <?php if ( $built ) : ?><a href="<?php echo esc_url( $site ); ?>"><?php esc_html_e( 'See my site', 'gogh-editor' ); ?></a><?php endif; ?>
  <button type="button" id="restart"><?php esc_html_e( 'Start again', 'gogh-editor' ); ?></button>
</div></div>
<main>
  <h1><?php echo esc_html( $built ? __( 'What would you like to change?', 'gogh-editor' ) : __( 'Let’s make your website.', 'gogh-editor' ) ); ?></h1>
  <p class="lede"><?php echo esc_html( $built ? __( 'Tell me in your own words. I will rebuild it right here, with the same pages you can still edit by hand.', 'gogh-editor' ) : __( 'Tell me what it is for and what it is called. I will ask a question or two, then build it right here: real pages, your words, pictures that fit, all of it yours to edit.', 'gogh-editor' ) ); ?></p>
  <div id="chips">
    <button type="button">A florist in Bath called Bloom &amp; Bough</button>
    <button type="button">A portfolio for my photography</button>
    <button type="button">A café with a menu and opening hours</button>
    <button type="button">A website for our wedding</button>
  </div>
  <div id="thread" aria-live="polite"></div>
</main>
<div class="dock">
  <div id="shot"><img id="shot-img" alt=""><span><?php esc_html_e( 'I will look at this picture', 'gogh-editor' ); ?></span><button type="button" id="shot-drop"><?php esc_html_e( 'Remove', 'gogh-editor' ); ?></button></div>
  <form id="f">
    <label class="pic" title="<?php esc_attr_e( 'Add a screenshot or a sketch', 'gogh-editor' ); ?>"><input type="file" id="file" accept="image/*" hidden><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg><span class="screen-reader-text" style="position:absolute;left:-9999px"><?php esc_html_e( 'Add a picture', 'gogh-editor' ); ?></span></label>
    <textarea id="q" rows="1" placeholder="<?php echo esc_attr( $built ? __( 'Make it warmer, add our opening hours…', 'gogh-editor' ) : __( 'A bakery in Frome called Crumb…', 'gogh-editor' ) ); ?>" aria-label="<?php esc_attr_e( 'Tell gogh about your site', 'gogh-editor' ); ?>"></textarea>
    <button id="go" type="submit"><?php esc_html_e( 'Send', 'gogh-editor' ); ?></button>
  </form>
  <p class="small"><?php esc_html_e( 'Your words go to gogh’s helper to write the site. Nothing is published anywhere else.', 'gogh-editor' ); ?></p>
</div>
<script>window.goghMake = <?php echo wp_json_encode( $cfg ); ?>;</script>
<script src="<?php echo esc_url( plugins_url( 'gogh-make.js', __FILE__ ) . '?ver=' . rawurlencode( GOGH_VERSION ) ); ?>"></script>
</body></html>
	<?php
}
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( ! current_user_can( 'manage_options' ) || ! get_option( 'gogh_make_made' ) || is_admin() ) {
		return;
	}
	$bar->add_node( array(
		'id'    => 'gogh-make',
		'title' => __( 'Chat', 'gogh-editor' ),
		'href'  => home_url( '/?gogh-make=1' ),
		'meta'  => array( 'title' => __( 'Change your site by chatting', 'gogh-editor' ) ),
	) );
}, 95 );

function gogh_helper_url() {
	return apply_filters( 'gogh_helper_url', 'https://gogh-helper.jamesmarsland.workers.dev' );
}
function gogh_boot_beacon() {
	$bp = get_option( 'gogh_booted_as', '' );
	if ( ! $bp || get_option( 'gogh_boot_pinged' ) ) {
		return;
	}
	update_option( 'gogh_boot_pinged', 1, false );
	$url  = gogh_helper_url() . '/api/boot';
	$body = wp_json_encode( array( 'bp' => sanitize_key( $bp ), 'v' => GOGH_VERSION ) );
	// a plain string body needs no preflight; the answer is not read
	echo '<script>try{var u=' . wp_json_encode( $url ) . ',b=' . wp_json_encode( $body ) . ';'
		. 'if(navigator.sendBeacon){navigator.sendBeacon(u,b)}else{fetch(u,{method:"POST",body:b,keepalive:true,mode:"no-cors"})}}catch(e){}</script>' . "\n";
}
add_action( 'wp_footer', 'gogh_boot_beacon', 99 );
add_action( 'admin_footer', 'gogh_boot_beacon', 99 );

// the running total, on the plugin's own row of the Plugins screen
function gogh_launch_count() {
	$c = get_transient( 'gogh_launch_count' );
	if ( false !== $c ) {
		return (int) $c;
	}
	$n = 0;
	$r = wp_remote_get( gogh_helper_url() . '/api/boot', array( 'timeout' => 4 ) );
	if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		$n = isset( $j['total'] ) ? (int) $j['total'] : 0;
	}
	set_transient( 'gogh_launch_count', $n, $n ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
	return $n;
}
add_filter( 'plugin_row_meta', function ( $links, $file ) {
	if ( plugin_basename( __FILE__ ) !== $file ) {
		return $links;
	}
	$n = gogh_launch_count();
	if ( $n ) {
		/* translators: %s: a number */
		$links[] = esc_html( sprintf( __( 'Launched %s times on Playground', 'gogh-editor' ), number_format_i18n( $n ) ) );
	}
	return $links;
}, 10, 2 );

// ---------- user testing ----------------------------------------------------
// A site booted with the gogh_user_test option (blueprint-usertest.json)
// shows a small card of tasks for the tester, a note box on each, and a
// wrap-up. Everything the card learns goes to the helper's /api/test under
// a random session id, and nothing else does: no page content, no name
// unless they type one. The list of tasks is the one below unless the
// option carries its own (an array under 'tasks'), or a filter changes it.
function gogh_user_test_tasks() {
	$opt = get_option( 'gogh_user_test' );
	if ( is_array( $opt ) && ! empty( $opt['tasks'] ) && is_array( $opt['tasks'] ) ) {
		return apply_filters( 'gogh_user_test_tasks', $opt['tasks'] );
	}
	$tasks = array(
		array( 'id' => 'name',    'title' => __( 'Change the site name to your business name.', 'gogh-editor' ),                                       'hint' => __( 'Click the header at the top of the page, then Logo & name.', 'gogh-editor' ) ),
		array( 'id' => 'words',   'title' => __( 'Change the big headline on the home page so it says what you do.', 'gogh-editor' ),                  'hint' => __( 'Click the words and type. Click away when you are done.', 'gogh-editor' ) ),
		array( 'id' => 'picture', 'title' => __( 'Swap one photo for a different one.', 'gogh-editor' ),                                             'hint' => __( 'Click a photo. The panel offers pictures to choose from, or upload your own.', 'gogh-editor' ) ),
		array( 'id' => 'look',    'title' => __( 'Give the site a different look, colours or fonts, and keep one you like.', 'gogh-editor' ),          'hint' => __( 'Press Styles at the top right, just left of the desktop and phone icons. Site style and Fonts are there.', 'gogh-editor' ) ),
		array( 'id' => 'contact', 'title' => __( 'Add a way for visitors to get in touch with you.', 'gogh-editor' ),                                 'hint' => __( 'Move the mouse over any section and press + Add at its top-left, then choose Form. It takes a name, an email and a message.', 'gogh-editor' ) ),
		array( 'id' => 'page',    'title' => __( 'Add a new page called Prices, put something on it, and make sure visitors can find it.', 'gogh-editor' ), 'hint' => __( 'Press Page on the left edge, then Add a page. When the new page opens, press Put it in the menu.', 'gogh-editor' ) ),
		array( 'id' => 'phone',   'title' => __( 'Check how the site looks on a phone, then publish and look at it the way a visitor would.', 'gogh-editor' ), 'hint' => __( 'Press the phone icon at the top right, just left of the ? help button. View site, at the top left, shows the site as visitors see it.', 'gogh-editor' ) ),
	);
	return apply_filters( 'gogh_user_test_tasks', $tasks );
}
function gogh_user_test_enqueue() {
	if ( ! get_option( 'gogh_user_test' ) || ! is_user_logged_in() || ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	$session = get_option( 'gogh_user_test_session', '' );
	if ( ! preg_match( '/^[a-z0-9]{8,32}$/', (string) $session ) ) {
		$session = strtolower( wp_generate_password( 12, false ) );
		update_option( 'gogh_user_test_session', $session, false );
	}
	$opt = get_option( 'gogh_user_test' );
	wp_enqueue_script( 'gogh-usertest', plugins_url( 'gogh-usertest.js', __FILE__ ), array(), GOGH_VERSION, true );
	wp_localize_script( 'gogh-usertest', 'GOGH_UT', array(
		'session' => $session,
		'helpUrl' => gogh_helper_url(),
		'version' => GOGH_VERSION,
		'tasks'   => array_values( gogh_user_test_tasks() ),
		'persona' => is_array( $opt ) && isset( $opt['persona'] ) ? sanitize_text_field( $opt['persona'] ) : '',
		'suite'   => 'gogh', // the core Site Editor test posts to the same store as 'core'
	) );
}
add_action( 'wp_enqueue_scripts', 'gogh_user_test_enqueue', 20 );

// the credit line, quiet at the foot of every page — removing it is one click
// in Settings, but it is on by default because it is the photographers' due
add_action( 'wp_footer', function () {
	$credits = get_option( 'gogh_picture_credits', array() );
	if ( ! $credits || ! is_array( $credits ) ) {
		return;
	}
	$names = array();
	foreach ( $credits as $c ) {
		if ( empty( $c['name'] ) ) {
			continue;
		}
		$names[] = ! empty( $c['link'] )
			? '<a href="' . esc_url( $c['link'] ) . '" rel="noopener nofollow">' . esc_html( $c['name'] ) . '</a>'
			: esc_html( $c['name'] );
	}
	if ( ! $names ) {
		return;
	}
	printf(
		'<p class="gogh-credits" style="text-align:center;font-size:0.78rem;opacity:0.55;margin:0;padding:1.4rem 1rem 2rem;">%s %s %s</p>',
		esc_html__( 'Photographs by', 'gogh-editor' ),
		wp_kses( implode( ', ', $names ), array( 'a' => array( 'href' => array(), 'rel' => array() ) ) ),
		'<a href="https://unsplash.com/?utm_source=gogh&utm_medium=referral" rel="noopener nofollow">' . esc_html__( 'on Unsplash', 'gogh-editor' ) . '</a>'
	);
}, 20 );

// a picture for a definition: a URL is sideloaded, a plugin path is copied
function gogh_site_def_picture( $src, $parent, $title ) {
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	try {
		if ( preg_match( '#^https?://#', $src ) ) {
			// media_sideload_image() refuses a URL with no image extension in its
			// path — every Unsplash picture (photo-<id>?w=1600&fm=jpg) — so those
			// pictures never became featured images. Fetch it ourselves, name the
			// file by what it turns out to be, and hand it to the media library.
			$tmp = download_url( esc_url_raw( $src ), 30 );
			if ( is_wp_error( $tmp ) ) {
				// a runtime whose HTTP layer cannot stream to a file (a blueprint
				// boot) still answers a plain request: take the body and write it
				gogh_site_def_log( 'download_url: ' . $tmp->get_error_message() . ' — ' . $src );
				$res = wp_remote_get( esc_url_raw( $src ), array( 'timeout' => 30 ) );
				$body = is_wp_error( $res ) ? '' : (string) wp_remote_retrieve_body( $res );
				if ( '' === $body ) {
					gogh_site_def_log( 'wp_remote_get: ' . ( is_wp_error( $res ) ? $res->get_error_message() : 'empty body, status ' . wp_remote_retrieve_response_code( $res ) ) . ' — ' . $src );
					return 0;
				}
				$tmp = wp_tempnam( 'picture' );
				if ( ! $tmp || false === file_put_contents( $tmp, $body ) ) {
					gogh_site_def_log( 'could not write a temp file — ' . $src );
					return 0;
				}
			}
			$info = @getimagesize( $tmp );
			$mime = $info && ! empty( $info['mime'] ) ? $info['mime'] : '';
			$ext  = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif' );
			if ( empty( $ext[ $mime ] ) ) {
				gogh_site_def_log( 'not an image (' . $mime . ') — ' . $src );
				@unlink( $tmp );
				return 0;
			}
			$name = sanitize_title( $title ? $title : 'picture' );
			$aid  = media_handle_sideload( array( 'name' => ( $name ? $name : 'picture' ) . '.' . $ext[ $mime ], 'tmp_name' => $tmp ), $parent, $title );
			if ( is_wp_error( $aid ) ) {
				gogh_site_def_log( 'media_handle_sideload: ' . $aid->get_error_message() . ' — ' . $src );
				@unlink( $tmp );
				return 0;
			}
			return (int) $aid;
		}
		if ( 0 === strpos( $src, '/wp-content/plugins/gogh/' ) ) {
			$file = WP_PLUGIN_DIR . '/gogh/' . substr( $src, strlen( '/wp-content/plugins/gogh/' ) );
			$file = realpath( $file );
			if ( $file && 0 === strpos( $file, realpath( WP_PLUGIN_DIR . '/gogh' ) ) && is_readable( $file ) ) {
				$tmp = wp_tempnam( basename( $file ) );
				copy( $file, $tmp );
				$aid = media_handle_sideload( array( 'name' => basename( $file ), 'tmp_name' => $tmp ), $parent, $title );
				return ( $aid && ! is_wp_error( $aid ) ) ? (int) $aid : 0;
			}
		}
	} catch ( \Throwable $e ) {
		gogh_site_def_log( 'picture: ' . $e->getMessage() . ' — ' . $src );
	}
	return 0;
}
// a short diary of what a site-definition boot could not do (pictures that
// never arrived), so a blueprint that came up bare can be read afterwards:
// `wp option get gogh_site_def_log`
function gogh_site_def_log( $line ) {
	$log   = get_option( 'gogh_site_def_log', array() );
	$log   = is_array( $log ) ? $log : array();
	$log[] = gmdate( 'H:i:s' ) . ' ' . $line;
	update_option( 'gogh_site_def_log', array_slice( $log, -20 ), false );
}
function gogh_starter_page_content( $slug, $pg ) {
	$file = __DIR__ . '/starters/' . $slug . '/' . basename( $pg['file'] );
	if ( ! is_readable( $file ) ) {
		return '';
	}
	return str_replace(
		array( '{{gogh_theme}}', '{{gogh_plugin}}' ),
		array( get_template_directory_uri(), untrailingslashit( plugins_url( '', __FILE__ ) ) ),
		file_get_contents( $file )
	);
}
/**
 * A starter's pictures become the site's own. A file under
 * starters/<slug>/ is sideloaded into the media library once — the
 * attachment remembers which file it came from — and any page or post
 * markup that reached for it under the plugin folder is rewritten to the
 * upload. The page keeps its pictures if the plugin ever goes, and the
 * site exports like any other, attachments and all (Ben loaded the
 * photographer's export without gogh: the Team page's portraits 404ed).
 */
function gogh_starter_sideload_file( $slug, $file, $title = '', $parent = 0 ) {
	$file = basename( $file );
	$src  = __DIR__ . '/starters/' . sanitize_key( $slug ) . '/' . $file;
	if ( ! file_exists( $src ) ) {
		return 0;
	}
	$key  = sanitize_key( $slug ) . '/' . $file;
	$have = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_gogh_starter_file', 'meta_value' => $key ) );
	if ( $have ) {
		// a picture adopted from a page arrived untitled; the manifest's media
		// list or a product may name it later
		if ( '' !== $title && get_the_title( (int) $have[0] ) === pathinfo( $file, PATHINFO_FILENAME ) ) {
			wp_update_post( array( 'ID' => (int) $have[0], 'post_title' => $title ) );
			update_post_meta( (int) $have[0], '_wp_attachment_image_alt', $title );
		}
		return (int) $have[0];
	}
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	try {
		$tmp = wp_tempnam( $file );
		if ( ! @copy( $src, $tmp ) ) {
			return 0;
		}
		$aid = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), (int) $parent, '' !== $title ? $title : null );
		if ( $aid && ! is_wp_error( $aid ) ) {
			update_post_meta( $aid, '_gogh_starter_file', $key );
			if ( '' !== $title ) {
				update_post_meta( $aid, '_wp_attachment_image_alt', $title );
			}
			return (int) $aid;
		}
	} catch ( \Throwable $e ) {}
	return 0;
}
function gogh_starter_adopt_pictures( $slug, $content ) {
	$base = untrailingslashit( plugins_url( '', __FILE__ ) ) . '/starters/' . sanitize_key( $slug ) . '/';
	if ( '' === $content || false === strpos( $content, $base ) ) {
		return $content;
	}
	if ( ! preg_match_all( '#' . preg_quote( $base, '#' ) . '([A-Za-z0-9._-]+\.(?:jpe?g|png|gif|webp|avif|svg))#i', $content, $m ) ) {
		return $content;
	}
	foreach ( array_unique( $m[1] ) as $file ) {
		$aid = gogh_starter_sideload_file( $slug, $file );
		$url = $aid ? wp_get_attachment_url( $aid ) : '';
		if ( $url ) {
			$content = str_replace( $base . $file, $url, $content );
		}
	}
	return $content;
}
/**
 * Stock a shop from a starter manifest: product categories (with a
 * picture each), global attributes with their terms, and products —
 * simple ones priced outright, variable ones with one variation per
 * term. Idempotent: a category, term or product that already exists
 * by slug or name is left alone, so re-applying a design never
 * doubles the shelves. Pictures come from files in the starter folder.
 */
function gogh_starter_apply_shop( $slug, $m ) {
	if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Product_Simple' ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$log      = array(); // what each picture did, kept in an option for support
	$sideload = function ( $file, $title, $parent = 0 ) use ( $slug, &$log ) {
		$aid = gogh_starter_sideload_file( $slug, $file, $title, $parent );
		$log[] = basename( $file ) . ( $aid ? ': #' . $aid : ': failed' );
		return $aid;
	};
	// categories
	$cats = array();
	foreach ( (array) ( isset( $m['categories'] ) ? $m['categories'] : array() ) as $c ) {
		if ( empty( $c['name'] ) ) {
			continue;
		}
		$cslug = ! empty( $c['slug'] ) ? sanitize_title( $c['slug'] ) : sanitize_title( $c['name'] );
		$t     = term_exists( $cslug, 'product_cat' );
		if ( ! $t ) {
			$t = wp_insert_term( $c['name'], 'product_cat', array( 'slug' => $cslug, 'description' => isset( $c['description'] ) ? $c['description'] : '' ) );
		}
		if ( ! $t || is_wp_error( $t ) ) {
			continue;
		}
		$tid            = (int) ( is_array( $t ) ? $t['term_id'] : $t );
		$cats[ $cslug ] = $tid;
		if ( ! empty( $c['image'] ) && ! get_term_meta( $tid, 'thumbnail_id', true ) ) {
			$aid = $sideload( $c['image'], $c['name'] );
			if ( $aid ) {
				update_term_meta( $tid, 'thumbnail_id', $aid );
			}
		}
	}
	// global attributes and their terms (a taxonomy created this request
	// is registered by hand so its terms can be added right away)
	$attrs = array();
	foreach ( (array) ( isset( $m['attributes'] ) ? $m['attributes'] : array() ) as $a ) {
		if ( empty( $a['name'] ) || ! function_exists( 'wc_create_attribute' ) ) {
			continue;
		}
		$aslug = sanitize_title( ! empty( $a['slug'] ) ? $a['slug'] : $a['name'] );
		$tax   = wc_attribute_taxonomy_name( $aslug );
		$aid   = (int) wc_attribute_taxonomy_id_by_name( $aslug );
		if ( ! $aid ) {
			$res = wc_create_attribute( array( 'name' => $a['name'], 'slug' => $aslug, 'type' => 'select', 'order_by' => 'menu_order', 'has_archives' => false ) );
			if ( is_wp_error( $res ) ) {
				continue;
			}
			$aid = (int) $res;
			delete_transient( 'wc_attribute_taxonomies' );
			if ( class_exists( 'WC_Cache_Helper' ) ) {
				WC_Cache_Helper::invalidate_cache_group( 'woocommerce-attributes' );
			}
		}
		if ( ! taxonomy_exists( $tax ) ) {
			register_taxonomy( $tax, array( 'product' ), array( 'hierarchical' => false, 'show_ui' => false, 'query_var' => true, 'rewrite' => false ) );
		}
		$terms = array();
		foreach ( (array) ( isset( $a['terms'] ) ? $a['terms'] : array() ) as $tn ) {
			$name  = is_array( $tn ) ? $tn['name'] : $tn;
			$tslug = sanitize_title( is_array( $tn ) && ! empty( $tn['slug'] ) ? $tn['slug'] : $name );
			$t     = term_exists( $tslug, $tax );
			if ( ! $t ) {
				$t = wp_insert_term( $name, $tax, array( 'slug' => $tslug ) );
			}
			if ( $t && ! is_wp_error( $t ) ) {
				$terms[ $tslug ] = (int) ( is_array( $t ) ? $t['term_id'] : $t );
			}
		}
		$attrs[ $aslug ] = array( 'id' => $aid, 'tax' => $tax, 'terms' => $terms );
	}
	// products
	$layout = ! empty( $m['shop']['product'] ) ? sanitize_key( $m['shop']['product'] ) : '';
	$plist  = (array) ( isset( $m['products'] ) ? $m['products'] : array() );
	$pn     = count( $plist );
	foreach ( $plist as $pi => $pd ) {
		if ( empty( $pd['name'] ) ) {
			continue;
		}
		$have = get_posts( array( 'post_type' => 'product', 'post_status' => 'any', 'title' => $pd['name'], 'numberposts' => 1, 'fields' => 'ids' ) );
		if ( $have ) {
			continue;
		}
		$variable = ! empty( $pd['variations'] ) && is_array( $pd['variations'] ) && class_exists( 'WC_Product_Variable' );
		$p        = $variable ? new WC_Product_Variable() : new WC_Product_Simple();
		$p->set_name( $pd['name'] );
		if ( ! empty( $pd['slug'] ) ) {
			$p->set_slug( sanitize_title( $pd['slug'] ) );
		}
		// manifest order is age: the last product listed is the newest, so a
		// 'newest first' rail shows the design's chosen four in its chosen order
		$p->set_date_created( time() - ( $pn - (int) $pi ) * HOUR_IN_SECONDS );
		if ( ! $variable && isset( $pd['price'] ) ) {
			$p->set_regular_price( (string) $pd['price'] );
			if ( ! empty( $pd['sale'] ) ) {
				$p->set_sale_price( (string) $pd['sale'] );
			}
		}
		$p->set_short_description( isset( $pd['short'] ) ? $pd['short'] : '' );
		$p->set_description( isset( $pd['description'] ) ? $pd['description'] : '' );
		$p->set_stock_status( ! empty( $pd['stock'] ) ? $pd['stock'] : 'instock' );
		if ( ! empty( $pd['sku'] ) ) {
			$p->set_sku( $pd['sku'] );
		}
		if ( ! empty( $pd['weight'] ) ) {
			$p->set_weight( $pd['weight'] );
		}
		if ( ! empty( $pd['category'] ) ) {
			$ids = array();
			foreach ( (array) $pd['category'] as $cs ) {
				if ( isset( $cats[ $cs ] ) ) {
					$ids[] = $cats[ $cs ];
				}
			}
			if ( $ids ) {
				$p->set_category_ids( $ids );
			}
		}
		$pattrs = array();
		foreach ( (array) ( isset( $pd['attributes'] ) ? $pd['attributes'] : array() ) as $aslug => $vals ) {
			if ( empty( $attrs[ $aslug ] ) || ! class_exists( 'WC_Product_Attribute' ) ) {
				continue;
			}
			$tids = array();
			foreach ( (array) $vals as $v ) {
				if ( isset( $attrs[ $aslug ]['terms'][ $v ] ) ) {
					$tids[] = $attrs[ $aslug ]['terms'][ $v ];
				}
			}
			if ( ! $tids ) {
				continue;
			}
			$wa = new WC_Product_Attribute();
			$wa->set_id( $attrs[ $aslug ]['id'] );
			$wa->set_name( $attrs[ $aslug ]['tax'] );
			$wa->set_options( $tids );
			$wa->set_position( count( $pattrs ) );
			$wa->set_visible( true );
			$wa->set_variation( $variable );
			$pattrs[] = $wa;
		}
		if ( $pattrs ) {
			$p->set_attributes( $pattrs );
		}
		$pid = $p->save();
		if ( ! $pid ) {
			continue;
		}
		if ( ! empty( $pd['image'] ) ) {
			$aid = $sideload( $pd['image'], $pd['name'], $pid );
			if ( $aid ) {
				$p->set_image_id( $aid );
				$p->save();
			}
		}
		$pl = ! empty( $pd['layout'] ) ? sanitize_key( $pd['layout'] ) : $layout;
		if ( $pl && function_exists( 'gogh_product_layouts' ) && array_key_exists( $pl, gogh_product_layouts() ) ) {
			update_post_meta( $pid, '_wp_page_template', $pl );
		}
		if ( $variable ) {
			foreach ( (array) $pd['variations'] as $var ) {
				if ( ! class_exists( 'WC_Product_Variation' ) ) {
					break;
				}
				$v  = new WC_Product_Variation();
				$va = array();
				foreach ( (array) ( isset( $var['attributes'] ) ? $var['attributes'] : array() ) as $aslug => $tslug ) {
					if ( isset( $attrs[ $aslug ] ) ) {
						$va[ $attrs[ $aslug ]['tax'] ] = sanitize_title( $tslug );
					}
				}
				$v->set_parent_id( $pid );
				$v->set_attributes( $va );
				$v->set_regular_price( (string) ( isset( $var['price'] ) ? $var['price'] : ( isset( $pd['price'] ) ? $pd['price'] : '' ) ) );
				if ( ! empty( $var['sale'] ) ) {
					$v->set_sale_price( (string) $var['sale'] );
				}
				$v->set_stock_status( 'instock' );
				$v->save();
			}
			WC_Product_Variable::sync( $pid );
		}
	}
	update_option( 'gogh_starter_shop_log', array_slice( $log, 0, 60 ), false );
}
add_action( 'init', function () {
	foreach ( gogh_starters() as $slug => $m ) {
		foreach ( $m['pages'] as $pg ) {
			if ( empty( $pg['file'] ) ) {
				continue; // a Woo page in the menu, nothing of ours to register
			}
			$content = gogh_starter_page_content( $slug, $pg );
			if ( '' === $content ) {
				continue;
			}
			register_block_pattern( 'gogh-starter/' . $slug . '-' . $pg['slug'], array(
				'title'    => $m['name'] . ' — ' . $pg['title'],
				'inserter' => false,
				'content'  => $content,
			) );
		}
	}
} );
add_action( 'rest_api_init', function () {
	// the editor asks this on window-focus: a tab that outlived a release
	// gets a quiet "reload" chip instead of silently missing features
	// (a stale tab ate two releases in one day — twice)
	register_rest_route( 'gogh/v1', '/version', array(
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'callback'            => function () {
			return array( 'build' => '0.99.650-chrome' );
		},
	) );
	register_rest_route( 'gogh/v1', '/starter', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'manage_options' );
		},
		'args'                => array( 'slug' => array( 'required' => true, 'type' => 'string' ) ),
		'callback'            => function ( $req ) {
			$starters = gogh_starters();
			$slug     = sanitize_key( $req['slug'] );
			if ( empty( $starters[ $slug ] ) ) {
				return new WP_Error( 'gogh_no_starter', __( 'Unknown site design.', 'gogh-editor' ), array( 'status' => 404 ) );
			}
			$m = $starters[ $slug ];
			// current pages step aside, restorably — never deleted
			$old = get_posts( array(
				'post_type'   => 'page',
				'post_status' => array( 'publish', 'draft', 'private', 'pending' ),
				'numberposts' => -1,
				'fields'      => 'ids',
			) );
			// WooCommerce's own pages (shop, cart, checkout, account) are rails,
			// never part of a design: they stay put — James lost them once
			$keep = array();
			if ( function_exists( 'wc_get_page_id' ) ) {
				foreach ( array( 'shop', 'cart', 'checkout', 'myaccount' ) as $wk ) {
					$wid = (int) wc_get_page_id( $wk );
					if ( $wid > 0 ) {
						$keep[] = $wid;
					}
				}
			}
			foreach ( $old as $oid ) {
				if ( in_array( (int) $oid, $keep, true ) ) {
					continue;
				}
				wp_trash_post( $oid );
			}
			$front = 0;
			$blog  = 0;
			$made  = array();
			// a design that needs the shop never applies without it
			if ( ! empty( $m['requires'] ) && 'woo' === $m['requires'] && ! class_exists( 'WooCommerce' ) ) {
				return new WP_Error( 'gogh_needs_woo', __( 'This design needs WooCommerce.', 'gogh-editor' ), array( 'status' => 400 ) );
			}
			foreach ( $m['pages'] as $pg ) {
				if ( ! empty( $pg['woo'] ) ) {
					// Woo's own page (shop, cart, account) takes its seat in the menu — never re-made
					$wid = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( sanitize_key( $pg['woo'] ) ) : 0;
					if ( $wid > 0 ) {
						$made[] = array( 'id' => $wid, 'title' => $pg['title'], 'no_menu' => isset( $pg['menu'] ) && false === $pg['menu'] );
					}
					continue;
				}
				$id = wp_insert_post( array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $pg['title'],
					'post_name'    => $pg['slug'],
					// wp_insert_post unslashes its input — without wp_slash it strips
					// the backslashes from the JSON < / " / - escapes in
					// the gogh/section model, so a widget's whtml became literal
					// "u003cdiv…" text in the editor ("issues with the blueprint")
					'post_content' => wp_slash( gogh_starter_adopt_pictures( $slug, gogh_starter_page_content( $slug, $pg ) ) ),
					'meta_input'   => empty( $pg['template'] ) ? array()
						: array( '_wp_page_template' => sanitize_key( $pg['template'] ) ),
				) );
				if ( ! $id || is_wp_error( $id ) ) {
					continue;
				}
				$made[] = array(
					'id'      => $id,
					'title'   => $pg['title'],
					'no_menu' => isset( $pg['menu'] ) && false === $pg['menu'],
				);
				if ( ! empty( $pg['front'] ) ) {
					$front = $id;
				}
				if ( ! empty( $pg['blog'] ) ) {
					$blog = $id;
				}
			}
			if ( ! $made ) {
				return new WP_Error( 'gogh_starter_failed', __( 'The site design could not be applied.', 'gogh-editor' ), array( 'status' => 500 ) );
			}
			if ( ! empty( $m['shop'] ) && is_array( $m['shop'] ) && function_exists( 'gogh_shop_looks' ) ) {
				$looks = gogh_shop_looks();
				if ( isset( $m['shop']['layout'] ) && array_key_exists( $m['shop']['layout'], $looks ) ) {
					update_option( 'gogh_shop_layout', $m['shop']['layout'] );
				}
				if ( isset( $m['shop']['category'] ) && array_key_exists( $m['shop']['category'], $looks ) ) {
					update_option( 'gogh_category_layout', $m['shop']['category'] );
				}
			}
			// starter posts: the notebook arrives lived-in, and gogh write
			// has a finished example on the shelf
			if ( ! empty( $m['posts'] ) ) {
				foreach ( $m['posts'] as $ps ) {
					$pid = wp_insert_post( array(
						'post_type'    => 'post',
						'post_status'  => 'publish',
						'post_title'   => $ps['title'],
						'post_name'    => $ps['slug'],
						'post_content' => wp_slash( gogh_starter_adopt_pictures( $slug, gogh_starter_page_content( $slug, $ps ) ) ), // see the page insert above
					) );
					// a post may open in one of gogh's reading looks from day one (the
					// Manual look builds its contents from the headings), and carry a
					// picture from the starter's folder as its featured image
					if ( $pid && ! is_wp_error( $pid ) && ! empty( $ps['style'] ) ) {
						update_post_meta( $pid, '_gogh_post_style', sanitize_key( $ps['style'] ) );
					}
					if ( $pid && ! is_wp_error( $pid ) && ! empty( $ps['image'] ) ) {
						// one attachment per starter file, shared with pages that show it
						$paid = gogh_starter_sideload_file( $slug, $ps['image'], $ps['title'], $pid );
						if ( $paid ) {
							set_post_thumbnail( $pid, $paid );
						}
					}
					if ( $pid && ! is_wp_error( $pid ) && ! empty( $ps['category'] ) ) {
						$term = term_exists( $ps['category'], 'category' );
						if ( ! $term ) {
							$term = wp_insert_term( $ps['category'], 'category' );
						}
						if ( $term && ! is_wp_error( $term ) ) {
							$tid = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
							wp_set_post_terms( $pid, array( $tid ), 'category' );
						}
					}
				}
			}
			// starter media: pictures the design wants in the library from day
			// one (a logo to pick, photographs to swap in) — files shipped in
			// the starter's folder, or addresses fetched on the way in. Best
			// effort, and never twice: a re-applied design finds its own
			if ( ! empty( $m['media'] ) && is_array( $m['media'] ) ) {
				require_once ABSPATH . 'wp-admin/includes/media.php';
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/image.php';
				foreach ( $m['media'] as $md ) {
					$title = isset( $md['title'] ) ? sanitize_text_field( $md['title'] ) : '';
					if ( $title ) {
						$have = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'title' => $title, 'numberposts' => 1, 'fields' => 'ids' ) );
						if ( $have ) {
							continue;
						}
					}
					$aid = null;
					try {
						if ( ! empty( $md['file'] ) ) {
							// one attachment per starter file, however many pages show it
							$aid = gogh_starter_sideload_file( $slug, $md['file'], $title );
							if ( ! $aid ) {
								$aid = null;
							}
						} elseif ( ! empty( $md['url'] ) ) {
							$aid = media_sideload_image( esc_url_raw( $md['url'] ), 0, $title, 'id' );
						}
					} catch ( \Throwable $e ) {
						$aid = null;
					}
					if ( $aid && ! is_wp_error( $aid ) ) {
						if ( $title ) {
							wp_update_post( array( 'ID' => $aid, 'post_title' => $title ) );
							update_post_meta( $aid, '_wp_attachment_image_alt', $title );
						}
					}
				}
			}
			gogh_starter_apply_chrome( $m, $made );
			gogh_starter_apply_styles( $m );
			if ( class_exists( 'WooCommerce' ) && ( ! empty( $m['products'] ) || ! empty( $m['categories'] ) ) ) {
				try {
					gogh_starter_apply_shop( $slug, $m );
				} catch ( \Throwable $e ) {}
			}
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $front ? $front : $made[0]['id'] );
			update_option( 'page_for_posts', $blog ? $blog : 0 );
			return array( 'home' => get_permalink( $front ? $front : $made[0]['id'] ) );
		},
	) );

	register_rest_route( 'gogh/v1', '/site-def', array(
		array(
			'methods'             => 'POST',
			'permission_callback' => 'gogh_can_build_site',
			'callback'            => function ( $req ) {
				$def = $req->get_json_params();
				// the Make chat rebuilds in place: the pages and posts the
				// last chat made go to the bin first, and this build's are
				// remembered for next time (never anything the person made)
				$replace = (bool) $req->get_param( 'replace' );
				if ( $replace ) {
					gogh_make_clear();
				}
				$before = gogh_make_ids();
				$r      = gogh_site_def_boot( is_array( $def ) ? $def : array() );
				if ( $replace && ! is_wp_error( $r ) ) {
					update_option( 'gogh_make_made', array_values( array_diff( gogh_make_ids(), $before ) ), false );
				}
				return $r;
			},
		),
		array(
			'methods'             => 'DELETE',
			'permission_callback' => 'gogh_can_build_site',
			'callback'            => function () {
				delete_option( 'gogh_site_def' );
				return array( 'cleared' => true );
			},
		),
	) );

	register_rest_route( 'gogh/v1', '/type-scale', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_theme_options' );
		},
		'args'                => array( 'scale' => array( 'required' => true, 'type' => 'number' ) ),
		'callback'            => function ( $req ) {
			$scale = max( 80, min( 140, (int) $req['scale'] ) );
			update_option( 'gogh_type_scale', $scale );
			return array( 'scale' => $scale );
		},
	) );

	register_rest_route( 'gogh/v1', '/blog-style', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_theme_options' );
		},
		'args'                => array( 'key' => array( 'required' => true, 'type' => 'string' ) ),
		'callback'            => function ( $req ) {
			$key = sanitize_key( $req['key'] );
			if ( ! in_array( $key, gogh_blog_styles(), true ) ) {
				return new WP_Error( 'gogh_bad_blog_style', __( 'Unknown blog style.', 'gogh-editor' ), array( 'status' => 400 ) );
			}
			update_option( 'gogh_blog_style', $key );
			return array( 'key' => $key );
		},
	) );

	register_rest_route( 'gogh/v1', '/motion', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_theme_options' );
		},
		'args'                => array( 'key' => array( 'required' => true, 'type' => 'string' ) ),
		'callback'            => function ( $req ) {
			$key = sanitize_key( $req['key'] );
			if ( ! in_array( $key, gogh_motion_styles(), true ) ) {
				return new WP_Error( 'gogh_bad_motion', __( 'Unknown motion style.', 'gogh-editor' ), array( 'status' => 400 ) );
			}
			update_option( 'gogh_motion', $key );
			return array( 'key' => $key );
		},
	) );

	// ---------- Ask Gogh, phase 2: the imagination tier ----------
	// The vocabulary answers instantly and locally; asks it cannot read
	// come here — a real model that NEVER writes markup. It returns
	// changes to the section MODEL (the same ops the vocabulary emits),
	// the client validates and clamps every field, and the solver
	// renders. The key lives server-side only — the browser never sees it.
	register_rest_route( 'gogh/v1', '/ask', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_theme_options' );
		},
		'callback'            => 'gogh_ask_handler',
	) );

	// ✦ Imagine an experience: the gallery hangs wild paintings on calm
	// walls. Full-creative-mode HTML, model-written, uploaded to the
	// user's OWN media library and framed in the sandboxed Experience
	// element — the walls stay themed, the frame holds the madness.
	// Gated like the manual upload: this mints text/html attachments.
	register_rest_route( 'gogh/v1', '/imagine-exp', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'upload_files' ) && current_user_can( 'unfiltered_html' );
		},
		'callback'            => 'gogh_imagine_exp_handler',
	) );

	// the key door: paste once in the Ask panel, gone from sight forever.
	// Admins only (it's a billing credential), shape-checked, write-only —
	// an empty key forgets it. A wp-config constant outranks the option.
	register_rest_route( 'gogh/v1', '/ask-key', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'manage_options' );
		},
		'callback'            => function ( $req ) {
			$p = $req->get_json_params();
			// each field only moves when it's PRESENT in the payload — a
			// workspace-only save must never brush against the stored key
			if ( is_array( $p ) && array_key_exists( 'key', $p ) ) {
				$key = trim( (string) $p['key'] );
				if ( '' === $key ) {
					delete_option( 'gogh_ask_key' );
					delete_option( 'gogh_ask_workspace' );
				} elseif ( ! preg_match( '/^sk-ant-[A-Za-z0-9_\-]{10,250}$/', $key ) ) {
					return new WP_Error( 'gogh_ask_key_shape', __( 'That doesn’t look like an Anthropic key (they start sk-ant-…).', 'gogh-editor' ), array( 'status' => 400 ) );
				} else {
					update_option( 'gogh_ask_key', $key, false );
				}
			}
			// identity-linked keys act inside a workspace — the id is an
			// identifier, not a secret, but it gets the same write-only home
			if ( is_array( $p ) && array_key_exists( 'workspace', $p ) ) {
				$ws = trim( (string) $p['workspace'] );
				if ( '' === $ws ) {
					delete_option( 'gogh_ask_workspace' );
				} elseif ( ! preg_match( '/^wrkspc_[A-Za-z0-9_\-]{4,80}$/', $ws ) ) {
					return new WP_Error( 'gogh_ask_ws_shape', __( 'That doesn’t look like a Workspace ID (they start wrkspc_…).', 'gogh-editor' ), array( 'status' => 400 ) );
				} else {
					update_option( 'gogh_ask_workspace', $ws, false );
				}
			}
			// 'on' lights the section tier (labs-gated); 'exp' lights Experiences
			return array( 'on' => (bool) ( gogh_ask_key() && gogh_labs_ask() ), 'exp' => (bool) gogh_ask_key() );
		},
	) );
	// the miss-log: an ask that missed, errored, or was instantly undone
	// IS a bug report — a quiet capped list, so gaps surface as data
	// instead of screenshots. Write-only from the editor; read as admin.
	// the first minute retires here — outcome to user meta, the honest
	// clock to a small capped log (did the 60-second promise hold?)
	register_rest_route( 'gogh/v1', '/menu-style', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_theme_options' );
		},
		'callback'            => function ( $req ) {
			$p   = $req->get_json_params();
			$cur = gogh_menu_style();
			$next = array(
				'layout'    => isset( $p['layout'] ) ? sanitize_key( $p['layout'] ) : $cur['layout'],
				'ground'    => isset( $p['ground'] ) ? sanitize_key( $p['ground'] ) : $cur['ground'],
				'phone'     => isset( $p['phone'] ) ? sanitize_text_field( $p['phone'] ) : $cur['phone'],
				'email'     => isset( $p['email'] ) ? sanitize_email( $p['email'] ) : $cur['email'],
				'account'   => isset( $p['account'] ) ? (bool) $p['account'] : $cur['account'],
				'phoneMenu' => isset( $p['phoneMenu'] ) ? (int) $p['phoneMenu'] : $cur['phoneMenu'],
			);
			update_option( 'gogh_menu_style', $next, true );
			return array( 'ok' => true, 'style' => gogh_menu_style() );
		},
	) );
	register_rest_route( 'gogh/v1', '/first-minute', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'callback'            => function ( $req ) {
			$p       = $req->get_json_params();
			$outcome = isset( $p['outcome'] ) && 'skipped' === $p['outcome'] ? 'skipped' : 'done';
			update_user_meta( get_current_user_id(), '_gogh_first_minute', $outcome );
			$log   = get_option( 'gogh_first_minute_log', array() );
			$log[] = array(
				't'    => time(),
				'o'    => $outcome,
				'secs' => isset( $p['secs'] ) ? min( 9999, absint( $p['secs'] ) ) : null,
			);
			if ( count( $log ) > 50 ) {
				$log = array_slice( $log, -50 );
			}
			update_option( 'gogh_first_minute_log', $log, false );
			return array( 'ok' => true );
		},
	) );
	register_rest_route( 'gogh/v1', '/ask-log', array(
		array(
			'methods'             => 'POST',
			'permission_callback' => function () {
				return current_user_can( 'edit_theme_options' );
			},
			'callback'            => function ( $req ) {
				$p   = $req->get_json_params();
				$ask = isset( $p['ask'] ) ? substr( sanitize_text_field( (string) $p['ask'] ), 0, 120 ) : '';
				$o   = isset( $p['outcome'] ) ? sanitize_key( $p['outcome'] ) : '';
				if ( '' === $ask || ! in_array( $o, array( 'miss', 'refused', 'model-error', 'undone', 'seam-miss' ), true ) ) {
					return new WP_Error( 'gogh_ask_log_bad', __( 'Nothing to log.', 'gogh-editor' ), array( 'status' => 400 ) );
				}
				$log = get_option( 'gogh_ask_log', array() );
				if ( ! is_array( $log ) ) {
					$log = array();
				}
				$log[] = array( 't' => time(), 'ask' => $ask, 'o' => $o );
				if ( count( $log ) > 100 ) {
					$log = array_slice( $log, -100 );
				}
				update_option( 'gogh_ask_log', $log, false );
				return array( 'n' => count( $log ) );
			},
		),
		array(
			'methods'             => 'GET',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'callback'            => function () {
				return array( 'log' => get_option( 'gogh_ask_log', array() ) );
			},
		),
	) );

	register_rest_route( 'gogh/v1', '/active-style', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_theme_options' );
		},
		'args'                => array( 'name' => array( 'required' => true, 'type' => 'string' ) ),
		'callback'            => function ( $req ) {
			$name = sanitize_text_field( $req['name'] );
			update_option( 'gogh_active_style', $name );
			return array( 'name' => $name );
		},
	) );

	// products live outside wp/v2 — gogh's own save route speaks the same
	// minimal contract the editor already uses (GET raw, POST content,
	// autosaves), registered under wp/v2 so the editor's root-splitting
	// URL arithmetic keeps working
	$gogh_product_perm = function ( $req ) {
		return current_user_can( 'edit_post', (int) $req['id'] );
	};
	$gogh_product_get = function ( $req ) {
		$p = get_post( (int) $req['id'] );
		if ( ! $p || 'product' !== $p->post_type ) {
			return new WP_Error( 'gogh_no_product', 'Not a product', array( 'status' => 404 ) );
		}
		return array( 'id' => $p->ID, 'content' => array( 'raw' => $p->post_content ) );
	};
	register_rest_route( 'wp/v2', '/gogh-product/(?P<id>\d+)', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => $gogh_product_perm,
			'callback'            => $gogh_product_get,
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => $gogh_product_perm,
			'callback'            => function ( $req ) use ( $gogh_product_get ) {
				$id = (int) $req['id'];
				$p  = get_post( $id );
				if ( ! $p || 'product' !== $p->post_type ) {
					return new WP_Error( 'gogh_no_product', 'Not a product', array( 'status' => 404 ) );
				}
				wp_update_post( array( 'ID' => $id, 'post_content' => (string) $req['content'] ) );
				return $gogh_product_get( $req );
			},
		),
	) );
	register_rest_route( 'wp/v2', '/gogh-product/(?P<id>\d+)/autosaves', array(
		'methods'             => 'POST',
		'permission_callback' => $gogh_product_perm,
		'callback'            => function ( $req ) {
			$id = (int) $req['id'];
			$p  = get_post( $id );
			if ( ! $p || 'product' !== $p->post_type ) {
				return new WP_Error( 'gogh_no_product', 'Not a product', array( 'status' => 404 ) );
			}
			if ( ! function_exists( 'wp_create_post_autosave' ) ) {
				require_once ABSPATH . 'wp-admin/includes/post.php';
			}
			$aid = wp_create_post_autosave( array(
				'post_ID'      => $id,
				'post_content' => (string) $req['content'],
				'post_title'   => $p->post_title,
				'post_type'    => 'product',
			) );
			return array( 'id' => is_wp_error( $aid ) ? 0 : (int) $aid );
		},
	) );
} );

/**
 * Product layouts: a FEW fixed, opinionated templates to pick from — never
 * a template editor. Classic is WooCommerce's own untouched template; the
 * gogh layouts add a content canvas below the buy box. Picking happens in
 * the admin bar, one click, per product.
 */
function gogh_product_layouts() {
	// no 'Classic' any more: a layout where gogh cannot edit confused people
	// (James: 'why cant we let folks use gogh on every product layout?').
	// Story IS Woo's buy box — with gogh's canvas beneath it.
	return array(
		'gogh-product-story'   => __( 'Standard — buy box, then your sections', 'gogh-editor' ),
		'gogh-product-showcase' => __( 'Showcase — image-led and centred', 'gogh-editor' ),
		'gogh-product-hero'    => __( 'Hero — the product picture fills the screen', 'gogh-editor' ),
	);
}
add_action( 'init', function () {
	if ( ! function_exists( 'register_block_template' ) || ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	register_block_template( 'gogh//gogh-product-showcase', array(
		'title'       => __( 'Product showcase (gogh)', 'gogh-editor' ),
		'description' => __( 'Image first, everything centred; your sections below.', 'gogh-editor' ),
		'post_types'  => array( 'product' ),
		'content'     => '<!-- wp:template-part {"slug":"header"} /-->' .
			'<!-- wp:group {"tagName":"main","layout":{"inherit":true,"type":"constrained"},"style":{"spacing":{"blockGap":"0","margin":{"top":"0","bottom":"0"}}}} -->' .
			'<main class="wp-block-group" style="margin-top:0;margin-bottom:0">' .
			'<!-- wp:woocommerce/store-notices /-->' .
			'<!-- wp:group {"layout":{"type":"constrained","contentSize":"760px"},"style":{"spacing":{"padding":{"top":"2.5rem","bottom":"2.5rem"},"blockGap":"1rem"}}} --><div class="wp-block-group" style="padding-top:2.5rem;padding-bottom:2.5rem">' .
			'<!-- wp:woocommerce/product-image-gallery /-->' .
			'<!-- wp:post-title {"level":1,"textAlign":"center","__woocommerceNamespace":"woocommerce/product-query/product-title"} /-->' .
			'<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} --><div class="wp-block-group">' .
			'<!-- wp:woocommerce/product-price {"isDescendentOfSingleProductTemplate":true,"textAlign":"center","fontSize":"large"} /-->' .
			'<!-- wp:woocommerce/add-to-cart-form /-->' .
			'</div><!-- /wp:group -->' .
			'</div><!-- /wp:group -->' .
			// the story's SLOT exists even while the description is empty (an empty
			// post-content block renders nothing, and the editor mounted the first
			// section after the related row — James: 'it does not appear there in the editor')
			'<!-- wp:group {"align":"full","className":"gogh-story-slot","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} --><div class="wp-block-group alignfull gogh-story-slot" style="margin-top:0;margin-bottom:0"><!-- wp:post-content {"align":"full","layout":{"type":"constrained"}} /--></div><!-- /wp:group -->' .
			'<!-- wp:group {"align":"wide","className":"gogh-related","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"},"blockGap":"1.25rem"}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-related" style="padding-top:3rem;padding-bottom:3rem">' .
			'<!-- wp:heading {"level":2,"align":"wide"} --><h2 class="wp-block-heading alignwide">' . esc_html__( 'You might also like', 'gogh-editor' ) . '</h2><!-- /wp:heading -->' .
			'<!-- wp:woocommerce/product-collection {"collection":"woocommerce/product-collection/related","query":{"perPage":3,"pages":1,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":false,"taxQuery":{},"isProductCollectionBlock":true,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"flex","columns":3},"align":"wide","className":"gogh-shop gogh-shop-grid"} --><div class="wp-block-woocommerce-product-collection alignwide gogh-shop gogh-shop-grid">' .
			'<!-- wp:woocommerce/product-template --><!-- wp:woocommerce/product-image {"showSaleBadge":true,"isDescendentOfQueryLoop":true,"aspectRatio":"1"} --><!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /--><!-- /wp:woocommerce/product-image -->' .
			'<!-- wp:post-title {"level":3,"isLink":true,"__woocommerceNamespace":"woocommerce/product-collection/product-title","style":{"spacing":{"margin":{"top":"12px","bottom":"6px"}}}} /-->' .
			'<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /--><!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true} /--><!-- /wp:woocommerce/product-template -->' .
			'</div><!-- /wp:woocommerce/product-collection -->' .
			'</div><!-- /wp:group -->' .
			'</main><!-- /wp:group -->' .
			'<!-- wp:template-part {"slug":"footer"} /-->',
	) );
	register_block_template( 'gogh//gogh-product-story', array(
		'title'       => __( 'Product standard (gogh)', 'gogh-editor' ),
		'description' => __( 'Woo sells up top; gogh tells the story below.', 'gogh-editor' ),
		'post_types'  => array( 'product' ),
		'content'     => '<!-- wp:template-part {"slug":"header"} /-->' .
			'<!-- wp:group {"tagName":"main","layout":{"inherit":true,"type":"constrained"},"style":{"spacing":{"blockGap":"0","margin":{"top":"0","bottom":"0"}}}} -->' .
			'<main class="wp-block-group" style="margin-top:0;margin-bottom:0">' .
			'<!-- wp:woocommerce/store-notices /-->' .
			// the buy box is WIDE at the root (a nested constrained group clamped
			// it to the theme's narrow content width — the 370px gallery James
			// saw); the story follows; related products close the page so a
			// product without a story never ends at the footer
			'<!-- wp:columns {"align":"wide","verticalAlignment":"center","style":{"spacing":{"padding":{"top":"2.5rem","bottom":"2.5rem"},"blockGap":{"left":"3rem"}}}} --><div class="wp-block-columns alignwide are-vertically-aligned-center" style="padding-top:2.5rem;padding-bottom:2.5rem">' .
			'<!-- wp:column {"width":"55%","verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:woocommerce/product-image-gallery /--></div><!-- /wp:column -->' .
			'<!-- wp:column {"width":"45%","verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%">' .
			'<!-- wp:post-title {"level":1,"__woocommerceNamespace":"woocommerce/product-query/product-title"} /-->' .
			'<!-- wp:woocommerce/product-price {"isDescendentOfSingleProductTemplate":true,"fontSize":"large"} /-->' .
			'<!-- wp:woocommerce/product-summary {"isDescendentOfSingleProductTemplate":true} /-->' .
			'<!-- wp:woocommerce/add-to-cart-form /-->' .
			'<!-- wp:woocommerce/product-meta {"isDescendentOfSingleProductTemplate":true} --><div class="wp-block-woocommerce-product-meta"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"typography":{"fontSize":"0.9rem"}}} --><div class="wp-block-group" style="font-size:0.9rem"><!-- wp:woocommerce/product-sku {"isDescendentOfSingleProductTemplate":true} /--><!-- wp:post-terms {"term":"product_cat","prefix":"' . esc_html__( 'In ', 'gogh-editor' ) . '"} /--></div><!-- /wp:group --></div><!-- /wp:woocommerce/product-meta -->' .
			'</div><!-- /wp:column -->' .
			'</div><!-- /wp:columns -->' .
			// the story's SLOT exists even while the description is empty (an empty
			// post-content block renders nothing, and the editor mounted the first
			// section after the related row — James: 'it does not appear there in the editor')
			'<!-- wp:group {"align":"full","className":"gogh-story-slot","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} --><div class="wp-block-group alignfull gogh-story-slot" style="margin-top:0;margin-bottom:0"><!-- wp:post-content {"align":"full","layout":{"type":"constrained"}} /--></div><!-- /wp:group -->' .
			'<!-- wp:group {"align":"wide","className":"gogh-related","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"},"blockGap":"1.25rem"}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-related" style="padding-top:3rem;padding-bottom:3rem">' .
			'<!-- wp:heading {"level":2,"align":"wide"} --><h2 class="wp-block-heading alignwide">' . esc_html__( 'You might also like', 'gogh-editor' ) . '</h2><!-- /wp:heading -->' .
			'<!-- wp:woocommerce/product-collection {"collection":"woocommerce/product-collection/related","query":{"perPage":3,"pages":1,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":false,"taxQuery":{},"isProductCollectionBlock":true,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"flex","columns":3},"align":"wide","className":"gogh-shop gogh-shop-grid"} --><div class="wp-block-woocommerce-product-collection alignwide gogh-shop gogh-shop-grid">' .
			'<!-- wp:woocommerce/product-template --><!-- wp:woocommerce/product-image {"showSaleBadge":true,"isDescendentOfQueryLoop":true,"aspectRatio":"1"} --><!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /--><!-- /wp:woocommerce/product-image -->' .
			'<!-- wp:post-title {"level":3,"isLink":true,"__woocommerceNamespace":"woocommerce/product-collection/product-title","style":{"spacing":{"margin":{"top":"12px","bottom":"6px"}}}} /-->' .
			'<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /--><!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true} /--><!-- /wp:woocommerce/product-template -->' .
			'</div><!-- /wp:woocommerce/product-collection -->' .
			'</div><!-- /wp:group -->' .
			'</main><!-- /wp:group -->' .
			'<!-- wp:template-part {"slug":"footer"} /-->',
	) );
} );

add_action( 'init', function () {
	if ( ! function_exists( 'register_block_template' ) || ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	// HERO (James: 'takes the product image and sets it as a big hero,
	// with product info beautifully arranged within it'): the product's
	// own picture fills the screen under a soft contrast tint; the buy box
	// sits bottom-left on a glass panel; the story and related products
	// follow as in the other layouts
	register_block_template( 'gogh//gogh-product-hero', array(
		'title'       => __( 'Product hero (gogh)', 'gogh-editor' ),
		'description' => __( 'The product picture fills the screen; the buy box sits on it.', 'gogh-editor' ),
		'post_types'  => array( 'product' ),
		'content'     => '<!-- wp:template-part {"slug":"header"} /-->' .
			'<!-- wp:group {"tagName":"main","layout":{"inherit":true,"type":"constrained"},"style":{"spacing":{"blockGap":"0","margin":{"top":"0","bottom":"0"}}}} -->' .
			'<main class="wp-block-group" style="margin-top:0;margin-bottom:0">' .
			'<!-- wp:woocommerce/store-notices /-->' .
			'<!-- wp:cover {"useFeaturedImage":true,"dimRatio":30,"overlayColor":"contrast","isUserOverlayColor":true,"minHeight":86,"minHeightUnit":"vh","contentPosition":"bottom left","isDark":true,"align":"full","className":"gogh-prod-hero","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}}} -->' .
			'<div class="wp-block-cover alignfull is-position-bottom-left gogh-prod-hero" style="padding-top:3rem;padding-right:var(--wp--preset--spacing--50);padding-bottom:3rem;padding-left:var(--wp--preset--spacing--50);min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-contrast-background-color has-background-dim-30 has-background-dim"></span><div class="wp-block-cover__inner-container">' .
			'<!-- wp:group {"className":"gogh-prod-hero-panel","layout":{"type":"constrained","contentSize":"520px","justifyContent":"left"},"style":{"spacing":{"blockGap":"0.9rem"}}} --><div class="wp-block-group gogh-prod-hero-panel">' .
			'<!-- wp:post-title {"level":1,"__woocommerceNamespace":"woocommerce/product-query/product-title","fontSize":"xx-large"} /-->' .
			'<!-- wp:woocommerce/product-price {"isDescendentOfSingleProductTemplate":true,"fontSize":"large"} /-->' .
			'<!-- wp:woocommerce/product-summary {"isDescendentOfSingleProductTemplate":true} /-->' .
			'<!-- wp:woocommerce/add-to-cart-form /-->' .
			'</div><!-- /wp:group -->' .
			'</div></div><!-- /wp:cover -->' .
			// the story's SLOT exists even while the description is empty (an empty
			// post-content block renders nothing, and the editor mounted the first
			// section after the related row — James: 'it does not appear there in the editor')
			'<!-- wp:group {"align":"full","className":"gogh-story-slot","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} --><div class="wp-block-group alignfull gogh-story-slot" style="margin-top:0;margin-bottom:0"><!-- wp:post-content {"align":"full","layout":{"type":"constrained"}} /--></div><!-- /wp:group -->' .
			'<!-- wp:group {"align":"wide","className":"gogh-related","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"},"blockGap":"1.25rem"}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-related" style="padding-top:3rem;padding-bottom:3rem">' .
			'<!-- wp:heading {"level":2,"align":"wide"} --><h2 class="wp-block-heading alignwide">' . esc_html__( 'You might also like', 'gogh-editor' ) . '</h2><!-- /wp:heading -->' .
			'<!-- wp:woocommerce/product-collection {"collection":"woocommerce/product-collection/related","query":{"perPage":3,"pages":1,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":false,"taxQuery":{},"isProductCollectionBlock":true,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"flex","columns":3},"align":"wide","className":"gogh-shop gogh-shop-grid"} --><div class="wp-block-woocommerce-product-collection alignwide gogh-shop gogh-shop-grid">' .
			'<!-- wp:woocommerce/product-template --><!-- wp:woocommerce/product-image {"showSaleBadge":true,"isDescendentOfQueryLoop":true,"aspectRatio":"1"} --><!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /--><!-- /wp:woocommerce/product-image -->' .
			'<!-- wp:post-title {"level":3,"isLink":true,"__woocommerceNamespace":"woocommerce/product-collection/product-title","style":{"spacing":{"margin":{"top":"12px","bottom":"6px"}}}} /-->' .
			'<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /--><!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true} /--><!-- /wp:woocommerce/product-template -->' .
			'</div><!-- /wp:woocommerce/product-collection -->' .
			'</div><!-- /wp:group -->' .
			'</main><!-- /wp:group -->' .
			'<!-- wp:template-part {"slug":"footer"} /-->',
	) );
} );

/**
 * Shop looks (James: 'give folks some options to change the design of the
 * shop page and product category pages — these are the main things folks
 * want to customize'). A FEW fixed looks for the shop page and for category
 * pages, built from Woo's own blocks over the inherited archive query —
 * filters, sorting, pagination and add-to-cart are all Woo's. One choice
 * per kind, site-wide, from the admin bar. Classic leaves Woo's template
 * untouched.
 */
function gogh_shop_looks() {
	return array(
		''          => __( 'Classic — WooCommerce\'s own', 'gogh-editor' ),
		'editorial' => __( 'Editorial — big title, tall pictures, no buttons', 'gogh-editor' ),
		'gallery'   => __( 'Gallery — four across, pictures first', 'gogh-editor' ),
		'catalogue' => __( 'Catalogue — filters beside a three-up grid', 'gogh-editor' ),
	);
}
function gogh_shop_look_kind() {
	if ( ! function_exists( 'is_shop' ) ) {
		return '';
	}
	if ( is_shop() ) {
		return 'shop';
	}
	if ( is_product_category() || is_product_tag() ) {
		return 'category';
	}
	return '';
}
function gogh_shop_look_active( $kind = null ) {
	$kind = null === $kind ? gogh_shop_look_kind() : $kind;
	if ( ! $kind ) {
		return '';
	}
	// an editor hovering the admin bar's Shop or Category layout menu tries
	// a look on by fetching this page with ?gogh-shoplook=<slug> (empty or
	// 'classic' for Woo's own): worn for that one request, nothing stored
	if ( isset( $_GET['gogh-shoplook'] ) && current_user_can( 'edit_theme_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation-only preview
		$try = sanitize_key( $_GET['gogh-shoplook'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' === $try || 'classic' === $try ) {
			return '';
		}
		if ( array_key_exists( $try, gogh_shop_looks() ) ) {
			return $try;
		}
	}
	if ( 'category' === $kind && ( is_product_category() || is_product_tag() ) ) {
		// this category's own choice wins (James: 'different layouts for
		// different category pages'); 'classic' is an explicit Woo's-own
		$own = (string) get_term_meta( get_queried_object_id(), '_gogh_shop_look', true );
		if ( 'classic' === $own ) {
			return '';
		}
		if ( $own && array_key_exists( $own, gogh_shop_looks() ) ) {
			return $own;
		}
	}
	$look = (string) get_option( 'shop' === $kind ? 'gogh_shop_layout' : 'gogh_category_layout', '' );
	return array_key_exists( $look, gogh_shop_looks() ) ? $look : '';
}
function gogh_shop_archive_markup( $look, $kind ) {
	$coll_query = '"query":{"woocommerceAttributes":[],"woocommerceStockStatus":["instock","outofstock","onbackorder"],"taxQuery":{},"isProductCollectionBlock":true,"perPage":12,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"title","author":"","search":"","exclude":[],"sticky":"","inherit":true}';
	$cols       = 'gallery' === $look ? 4 : 3;
	$cls        = 'gogh-shop gogh-shop-grid gogh-shoplook-' . $look;
	$ratio      = 'editorial' === $look ? '3/4' : '1';
	$collection = '<!-- wp:woocommerce/product-collection {"queryId":0,' . $coll_query . ',"tagName":"div","dimensions":{"widthType":"fill","fixedWidth":""},"displayLayout":{"type":"flex","columns":' . $cols . ',"shrinkColumns":true},"convertedFromProducts":false,"queryContextIncludes":["collection"],"align":"wide","className":"' . $cls . '"} -->' .
		'<div class="wp-block-woocommerce-product-collection alignwide ' . $cls . '">' .
		'<!-- wp:woocommerce/product-template -->' .
		'<!-- wp:woocommerce/product-image {"showSaleBadge":true,"imageSizing":"thumbnail","isDescendentOfQueryLoop":true,"aspectRatio":"' . $ratio . '"} --><!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /--><!-- /wp:woocommerce/product-image -->' .
		'<!-- wp:post-title {"level":3,"isLink":true,"__woocommerceNamespace":"woocommerce/product-collection/product-title","style":{"spacing":{"margin":{"top":"12px","bottom":"6px"}}}} /-->' .
		'<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /-->' .
		( 'catalogue' === $look ? '<!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true} /-->' : '' ) .
		'<!-- /wp:woocommerce/product-template -->' .
		'<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"center"}} --><!-- wp:query-pagination-previous /--><!-- wp:query-pagination-numbers /--><!-- wp:query-pagination-next /--><!-- /wp:query-pagination -->' .
		'<!-- wp:woocommerce/product-collection-no-results --><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center","flexWrap":"wrap"}} --><div class="wp-block-group"><!-- wp:pattern {"slug":"woocommerce/no-products-found-clear-filters"} /--></div><!-- /wp:group --><!-- /wp:woocommerce/product-collection-no-results -->' .
		'</div><!-- /wp:woocommerce/product-collection -->';
	$toolbar = '<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"},"className":"gogh-shop-toolbar"} --><div class="wp-block-group alignwide gogh-shop-toolbar"><!-- wp:woocommerce/product-results-count /--><!-- wp:woocommerce/catalog-sorting /--></div><!-- /wp:group -->';
	$chips   = ( 'shop' === $kind )
		? '<!-- wp:woocommerce/product-categories {"hasCount":false,"hasImage":false,"isDropdown":false,"className":"gogh-catchips"} /-->'
		: '';
	// Editorial, on a category with a picture: the picture becomes the
	// banner — a Cover, the name and description at its foot
	$banner_id = 0;
	if ( 'editorial' === $look && 'category' === $kind && ( is_product_category() || is_product_tag() ) ) {
		$banner_id = (int) get_term_meta( get_queried_object_id(), 'thumbnail_id', true );
		if ( $banner_id && ! wp_get_attachment_image_url( $banner_id, 'full' ) ) {
			$banner_id = 0;
		}
	}
	if ( $banner_id ) {
		$src  = wp_get_attachment_image_url( $banner_id, 'full' );
		$head = '<!-- wp:cover {"url":"' . esc_url( $src ) . '","id":' . $banner_id . ',"dimRatio":50,"minHeight":380,"minHeightUnit":"px","contentPosition":"bottom left","align":"full","className":"gogh-shop-banner","layout":{"type":"constrained"}} -->' .
			'<div class="wp-block-cover alignfull has-custom-content-position is-position-bottom-left gogh-shop-banner" style="min-height:380px">' .
			'<span aria-hidden="true" class="wp-block-cover__background has-background-dim-50 has-background-dim"></span>' .
			'<img class="wp-block-cover__image-background wp-image-' . $banner_id . '" alt="" src="' . esc_url( $src ) . '" data-object-fit="cover"/>' .
			'<div class="wp-block-cover__inner-container">' .
			'<!-- wp:group {"align":"wide","className":"gogh-shop-head gogh-shop-head-editorial gogh-shop-head-banner","layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-shop-head gogh-shop-head-editorial gogh-shop-head-banner">' .
			'<!-- wp:query-title {"type":"archive","showPrefix":false,"align":"wide","className":"gogh-shop-title"} /-->' .
			'<!-- wp:term-description {"align":"wide","className":"gogh-shop-desc"} /-->' .
			'</div><!-- /wp:group -->' .
			'</div></div><!-- /wp:cover -->';
		$body = $toolbar . $collection;
	} elseif ( 'editorial' === $look ) {
		$head = '<!-- wp:group {"align":"wide","className":"gogh-shop-head gogh-shop-head-editorial","style":{"spacing":{"padding":{"top":"2.5rem","bottom":"1.5rem"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-shop-head gogh-shop-head-editorial" style="padding-top:2.5rem;padding-bottom:1.5rem">' .
			'<!-- wp:query-title {"type":"archive","showPrefix":false,"align":"wide","className":"gogh-shop-title"} /-->' .
			'<!-- wp:term-description {"align":"wide","className":"gogh-shop-desc"} /-->' .
			$chips . '</div><!-- /wp:group -->';
		$body = $toolbar . $collection;
	} elseif ( 'gallery' === $look ) {
		$head = '<!-- wp:group {"align":"wide","className":"gogh-shop-head gogh-shop-head-gallery","style":{"spacing":{"padding":{"top":"2rem","bottom":"1rem"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-shop-head gogh-shop-head-gallery" style="padding-top:2rem;padding-bottom:1rem">' .
			'<!-- wp:query-title {"type":"archive","showPrefix":false,"textAlign":"center","className":"gogh-shop-title"} /-->' .
			'<!-- wp:term-description {"align":"wide","className":"gogh-shop-desc"} /-->' .
			$chips . '</div><!-- /wp:group -->';
		$body = $toolbar . $collection;
	} else { // catalogue
		$filters = '<!-- wp:woocommerce/product-filters --><div class="wp-block-woocommerce-product-filters">' .
			'<!-- wp:woocommerce/product-filter-active --><div class="wp-block-woocommerce-product-filter-active"></div><!-- /wp:woocommerce/product-filter-active -->' .
			'<!-- wp:woocommerce/product-filter-price --><div class="wp-block-woocommerce-product-filter-price"><!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">' . esc_html__( 'Price', 'gogh-editor' ) . '</h3><!-- /wp:heading --><!-- wp:woocommerce/product-filter-price-slider /--></div><!-- /wp:woocommerce/product-filter-price -->';
		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			foreach ( wc_get_attribute_taxonomies() as $attr ) {
				$filters .= '<!-- wp:woocommerce/product-filter-attribute {"attributeId":' . (int) $attr->attribute_id . '} --><div class="wp-block-woocommerce-product-filter-attribute"><!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">' . esc_html( $attr->attribute_label ) . '</h3><!-- /wp:heading --><!-- wp:woocommerce/product-filter-checkbox-list /--></div><!-- /wp:woocommerce/product-filter-attribute -->';
			}
		}
		$filters .= '<!-- wp:woocommerce/product-filter-status --><div class="wp-block-woocommerce-product-filter-status"><!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">' . esc_html__( 'Availability', 'gogh-editor' ) . '</h3><!-- /wp:heading --><!-- wp:woocommerce/product-filter-checkbox-list /--></div><!-- /wp:woocommerce/product-filter-status -->' .
			'</div><!-- /wp:woocommerce/product-filters -->';
		$head = '<!-- wp:woocommerce/breadcrumbs {"align":"wide"} /-->' .
			'<!-- wp:group {"align":"wide","className":"gogh-shop-head gogh-shop-head-catalogue","style":{"spacing":{"padding":{"top":"1.5rem","bottom":"1rem"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group alignwide gogh-shop-head gogh-shop-head-catalogue" style="padding-top:1.5rem;padding-bottom:1rem">' .
			'<!-- wp:query-title {"type":"archive","showPrefix":false,"align":"wide","className":"gogh-shop-title"} /-->' .
			'<!-- wp:term-description {"align":"wide","className":"gogh-shop-desc"} /--></div><!-- /wp:group -->';
		$body = '<!-- wp:columns {"align":"wide","className":"gogh-shop-catalogue","style":{"spacing":{"blockGap":{"left":"3rem"}}}} --><div class="wp-block-columns alignwide gogh-shop-catalogue">' .
			'<!-- wp:column {"width":"26%","className":"gogh-shop-side"} --><div class="wp-block-column gogh-shop-side" style="flex-basis:26%">' . $filters . '</div><!-- /wp:column -->' .
			'<!-- wp:column {"width":"74%"} --><div class="wp-block-column" style="flex-basis:74%">' . $toolbar . $collection . '</div><!-- /wp:column -->' .
			'</div><!-- /wp:columns -->';
	}
	return '<!-- wp:template-part {"slug":"header"} /-->' .
		'<!-- wp:group {"tagName":"main","layout":{"inherit":true,"type":"constrained"},"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} --><main class="wp-block-group" style="margin-top:0;margin-bottom:0">' .
		$head . '<!-- wp:woocommerce/store-notices /-->' . $body .
		'</main><!-- /wp:group -->' .
		'<!-- wp:template-part {"slug":"footer"} /-->';
}
// the swap: when a look is chosen for this kind of page, the archive
// template's CONTENT is gogh's — the template itself, its slug and Woo's
// ownership stay exactly as they were (Classic = no swap at all)
add_filter( 'get_block_templates', function ( $templates, $query, $template_type ) {
	if ( 'wp_template' !== $template_type || is_admin() || ! is_array( $templates ) ) {
		return $templates;
	}
	$kind = gogh_shop_look_kind();
	$look = $kind ? gogh_shop_look_active( $kind ) : '';
	if ( ! $look ) {
		return $templates;
	}
	foreach ( $templates as $t ) {
		if ( is_object( $t ) && isset( $t->slug ) && in_array( $t->slug, array( 'archive-product', 'taxonomy-product_cat', 'taxonomy-product_tag' ), true ) ) {
			$t->content = gogh_shop_archive_markup( $look, $kind );
			$t->description = 'gogh · ' . $look;
		}
	}
	return $templates;
}, 20, 3 );
add_filter( 'body_class', function ( $classes ) {
	$kind = gogh_shop_look_kind();
	$look = $kind ? gogh_shop_look_active( $kind ) : '';
	if ( $look ) {
		$classes[] = 'gogh-shoplook-' . $look;
		$classes[] = 'gogh-shoplook-kind-' . $kind;
	}
	return $classes;
}, 20 );
add_action( 'admin_post_gogh_shop_layout', function () {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You cannot change the shop layout.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_shop_layout' );
	$kind   = isset( $_GET['kind'] ) && 'category' === $_GET['kind'] ? 'category' : 'shop';
	$layout = isset( $_GET['layout'] ) ? sanitize_key( wp_unslash( $_GET['layout'] ) ) : '';
	if ( ! array_key_exists( $layout, gogh_shop_looks() ) ) {
		wp_die( esc_html__( 'Unknown layout.', 'gogh-editor' ) );
	}
	$term = isset( $_GET['term'] ) ? (int) $_GET['term'] : 0;
	$all  = isset( $_GET['all'] ) && '1' === $_GET['all'];
	if ( 'category' === $kind && $term && ! $all ) {
		// one category's own look ('classic' records an explicit Woo's-own)
		update_term_meta( $term, '_gogh_shop_look', '' === $layout ? 'classic' : $layout );
	} else {
		update_option( 'shop' === $kind ? 'gogh_shop_layout' : 'gogh_category_layout', $layout );
		if ( 'category' === $kind ) {
			// stamp every category — each can still be changed afterwards, one at a time
			foreach ( get_terms( array( 'taxonomy' => array( 'product_cat', 'product_tag' ), 'hide_empty' => false, 'fields' => 'ids' ) ) as $tid ) {
				delete_term_meta( $tid, '_gogh_shop_look' );
			}
		}
	}
	$back = isset( $_GET['back'] ) ? esc_url_raw( wp_unslash( $_GET['back'] ) ) : '';
	wp_safe_redirect( $back ? $back : home_url( '/' ) );
	exit;
} );
// ---------- Variations: one modal with a live preview (phase two, admin) ----------
// Where beginners abandon Woo: attributes on one tab, variations on another,
// a 'Generate' button hidden in a dropdown. Gogh asks one question — what
// varies? — draws the storefront selector as you type, and creates every
// combination itself. Woo's own tab stays for stock, SKUs and the rest.
add_action( 'add_meta_boxes_product', function ( $post ) {
	if ( ! function_exists( 'wc_get_product' ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return;
	}
	add_meta_box( 'gogh-variations', __( 'Variations', 'gogh-editor' ), function ( $post ) {
		$product  = wc_get_product( $post->ID );
		$is_draft = 'auto-draft' === get_post_status( $post );
		$n        = $product && $product->is_type( 'variable' ) ? count( $product->get_children() ) : 0;
		$names    = array();
		if ( $product ) {
			foreach ( $product->get_attributes() as $attr ) {
				if ( is_object( $attr ) && $attr->get_variation() ) {
					$names[] = wc_attribute_label( $attr->get_name() );
				}
			}
		}
		echo '<div id="gogh-variations-box" data-product="' . (int) $post->ID . '">';
		if ( $n ) {
			/* translators: 1: variation count, 2: attribute names */
			echo '<p class="gogh-var-summary"><strong>' . esc_html( sprintf( _n( '%1$d variation', '%1$d variations', $n, 'gogh-editor' ), $n ) ) . '</strong> · ' . esc_html( implode( ' · ', $names ) ) . '</p>';
		} else {
			echo '<p class="gogh-var-summary">' . esc_html__( 'One of a kind so far.', 'gogh-editor' ) . '</p>';
		}
		if ( $is_draft ) {
			echo '<button type="button" class="button" disabled>' . esc_html__( 'Set up variations', 'gogh-editor' ) . '</button>';
			echo '<p class="description">' . esc_html__( 'Save the product once, then come back here.', 'gogh-editor' ) . '</p>';
		} else {
			echo '<button type="button" class="button button-primary gogh-var-open">' . esc_html( $n ? __( 'Edit variations', 'gogh-editor' ) : __( 'Set up variations', 'gogh-editor' ) ) . '</button>';
			echo '<p class="description">' . esc_html__( 'Colour, size, whatever varies — one screen, and every combination is created for you.', 'gogh-editor' ) . '</p>';
		}
		echo '</div>';
	}, 'product', 'side', 'high' );
} );
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ! function_exists( 'wc_get_product' ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$post   = get_post();
	if ( ! $screen || 'product' !== $screen->id || ! $post ) {
		return;
	}
	$product = wc_get_product( $post->ID );
	$globals = array();
	if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
		foreach ( wc_get_attribute_taxonomies() as $tax ) {
			$globals[] = $tax->attribute_label;
		}
	}
	wp_enqueue_script( 'gogh-admin', plugins_url( 'gogh-admin.js', __FILE__ ), array(), '0.99.650-chrome', true );
	wp_enqueue_style( 'gogh-admin', plugins_url( 'gogh-admin.css', __FILE__ ), array(), '0.99.650-chrome' );
	wp_localize_script( 'gogh-admin', 'GOGH_ADMIN', array(
		'restUrl'   => esc_url_raw( rest_url( 'wc/v3/' ) ),
		'nonce'     => wp_create_nonce( 'wp_rest' ),
		'productId' => $post->ID,
		'name'      => get_the_title( $post ),
		'price'     => $product ? (string) $product->get_regular_price() : '',
		'currency'  => function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ) : '',
		'thumb'     => get_the_post_thumbnail_url( $post, 'medium' ) ?: '',
		'globals'   => $globals,
	) );
} );
// the product form wears gogh's shape only on the classic product screen
add_filter( 'admin_body_class', function ( $classes ) {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && 'product' === $screen->id && 'post' === $screen->base && function_exists( 'wc_get_product' ) ) {
		$classes .= ' gogh-productform';
	}
	return $classes;
} );
// a placeholder that teaches: a name people would say out loud
add_filter( 'enter_title_here', function ( $text, $post ) {
	if ( $post && 'product' === $post->post_type ) {
		return __( 'Product name — e.g. Lavender bar, cut by hand', 'gogh-editor' );
	}
	return $text;
}, 10, 2 );
add_action( 'admin_notices', function () {
	if ( isset( $_GET['gogh-variations'] ) && 'done' === $_GET['gogh-variations'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Variations created. They are in the Variations tab below, priced and ready to sell.', 'gogh-editor' ) . '</p></div>';
	}
} );
// ---------- Launch: a goal-grouped checklist, not a wizard (phase two) ----------
// Woo's onboarding stops when the settings are filled in. A shop that is set
// up but looks like nothing is not launched — so this list runs on through
// design, and it reads the site's real state every time (nothing to tick).
function gogh_launch_groups() {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$products = wc_get_products( array( 'status' => 'publish', 'limit' => -1 ) );
	$no_pic   = 0;
	$virtual  = count( $products ) > 0;
	foreach ( $products as $pr ) {
		if ( ! $pr->get_image_id() ) {
			$no_pic++;
		}
		if ( ! $pr->is_virtual() ) {
			$virtual = false;
		}
	}
	$shipping = $virtual;
	if ( ! $shipping && class_exists( 'WC_Shipping_Zones' ) ) {
		foreach ( WC_Shipping_Zones::get_zones() as $z ) {
			if ( ! empty( $z['shipping_methods'] ) ) {
				$shipping = true;
			}
		}
		if ( ! $shipping && count( ( new WC_Shipping_Zone( 0 ) )->get_shipping_methods( true ) ) ) {
			$shipping = true;
		}
	}
	$gateways = array();
	if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
		foreach ( WC()->payment_gateways()->payment_gateways() as $g ) {
			if ( 'yes' === $g->enabled ) {
				$gateways[] = $g->get_title();
			}
		}
	}
	$orders   = function_exists( 'wc_get_orders' ) ? count( wc_get_orders( array( 'limit' => 1, 'return' => 'ids' ) ) ) : 0;
	$page_ok  = function ( $id ) { return $id && 'publish' === get_post_status( (int) $id ); };
	$front    = (int) get_option( 'page_on_front' );
	$front_ok = 'page' === get_option( 'show_on_front' ) && $front && false !== strpos( (string) get_post_field( 'post_content', $front ), 'wp:gogh/section' );
	$name     = trim( (string) get_option( 'blogname' ) );
	$soon     = 'yes' === get_option( 'woocommerce_coming_soon' );
	$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
	$item     = function ( $title, $why, $done, $verb, $url ) {
		return array( 'title' => $title, 'why' => $why, 'done' => (bool) $done, 'verb' => $verb, 'url' => $url );
	};
	return array(
		array( 'title' => __( 'Set up your shop', 'gogh-editor' ), 'items' => array(
			$item( __( 'Name your shop', 'gogh-editor' ), __( 'It heads every page, every email and every receipt.', 'gogh-editor' ), $name && ! in_array( strtolower( $name ), array( 'my wordpress', 'wordpress', 'my site', 'site title' ), true ), __( 'Name it', 'gogh-editor' ), admin_url( 'options-general.php' ) ),
			$item( __( 'Add your first product', 'gogh-editor' ), __( 'A name and a price make it sellable.', 'gogh-editor' ), count( $products ) > 0, __( 'Add a product', 'gogh-editor' ), admin_url( 'post-new.php?post_type=product' ) ),
			/* translators: %d: products without a picture */
			$item( __( 'Give every product a picture', 'gogh-editor' ), $no_pic ? sprintf( _n( '%d product has no picture yet.', '%d products have no picture yet.', $no_pic, 'gogh-editor' ), $no_pic ) : __( 'People buy what they can see.', 'gogh-editor' ), count( $products ) > 0 && 0 === $no_pic, __( 'See products', 'gogh-editor' ), admin_url( 'edit.php?post_type=product' ) ),
			$item( __( 'Country and currency', 'gogh-editor' ), __( 'Prices, tax and shipping all follow from these two.', 'gogh-editor' ), get_option( 'woocommerce_default_country' ) && get_option( 'woocommerce_currency' ), __( 'Check settings', 'gogh-editor' ), admin_url( 'admin.php?page=wc-settings' ) ),
			$item( __( 'Your store address', 'gogh-editor' ), __( 'It appears on receipts, and shipping rates start from here.', 'gogh-editor' ), '' !== trim( (string) get_option( 'woocommerce_store_address' ) ), __( 'Add address', 'gogh-editor' ), admin_url( 'admin.php?page=wc-settings' ) ),
			$item( __( 'A way to ship', 'gogh-editor' ), $virtual ? __( 'Everything you sell is digital — nothing to post.', 'gogh-editor' ) : __( 'One zone with one rate is enough to start: flat rate, or free.', 'gogh-editor' ), $shipping, __( 'Set up shipping', 'gogh-editor' ), admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ),
		) ),
		array( 'title' => __( 'Get paid', 'gogh-editor' ), 'items' => array(
			$item( __( 'A way to take payment', 'gogh-editor' ), $gateways ? sprintf( __( 'On: %s.', 'gogh-editor' ), implode( ', ', $gateways ) ) : __( 'Cards and wallets in one step, everything else behind a link.', 'gogh-editor' ), count( $gateways ) > 0, __( 'Get paid', 'gogh-editor' ), admin_url( 'admin.php?page=gogh-payments' ) ),
			$item( __( 'Place a test order', 'gogh-editor' ), __( 'Buy something from yourself once — checkout, the email, the order screen.', 'gogh-editor' ), $orders > 0, __( 'Go to the shop', 'gogh-editor' ), $shop_url ),
		) ),
		array( 'title' => __( 'Legal pages', 'gogh-editor' ), 'items' => array(
			$item( __( 'Privacy policy', 'gogh-editor' ), __( 'WordPress drafts one for you; publish it and point to it.', 'gogh-editor' ), $page_ok( get_option( 'wp_page_for_privacy_policy' ) ), __( 'Privacy settings', 'gogh-editor' ), admin_url( 'options-privacy.php' ) ),
			$item( __( 'Terms and conditions', 'gogh-editor' ), __( 'Shown at checkout; a short, honest page beats a long copied one.', 'gogh-editor' ), $page_ok( get_option( 'woocommerce_terms_page_id' ) ), __( 'Choose the page', 'gogh-editor' ), admin_url( 'admin.php?page=wc-settings&tab=advanced' ) ),
			$item( __( 'Refunds and returns', 'gogh-editor' ), __( 'Say what happens when something goes wrong, before it does.', 'gogh-editor' ), $page_ok( get_option( 'woocommerce_refund_returns_page_id' ) ), __( 'Choose the page', 'gogh-editor' ), admin_url( 'admin.php?page=wc-settings&tab=advanced' ) ),
		) ),
		array( 'title' => __( 'Ready to launch', 'gogh-editor' ), 'items' => array(
			$item( __( 'A home page with a story', 'gogh-editor' ), __( 'The first thing anyone sees. Designed with gogh, it says who you are.', 'gogh-editor' ), $front_ok, __( 'Design the home page', 'gogh-editor' ), $front ? add_query_arg( 'gogh-edit', '1', get_permalink( $front ) ) : home_url( '/?gogh-edit=1' ) ),
			$item( __( 'A look for the shop page', 'gogh-editor' ), __( 'Editorial, Gallery or Catalogue — pick it from the bar on the shop page.', 'gogh-editor' ), '' !== (string) get_option( 'gogh_shop_layout', '' ), __( 'Open the shop', 'gogh-editor' ), $shop_url ),
			$item( __( 'Your logo in the header', 'gogh-editor' ), __( 'Click the header while editing any page to place it.', 'gogh-editor' ), (int) get_theme_mod( 'custom_logo' ) > 0, __( 'Edit the header', 'gogh-editor' ), home_url( '/?gogh-edit=1' ) ),
			$item( __( 'Open the doors', 'gogh-editor' ), $soon ? __( 'The shop is behind Coming soon. When the rest is done, let people in.', 'gogh-editor' ) : __( 'The shop is live for everyone.', 'gogh-editor' ), ! $soon, __( 'Site visibility', 'gogh-editor' ), admin_url( 'admin.php?page=wc-settings&tab=site-visibility' ) ),
		) ),
	);
}
function gogh_launch_progress() {
	$done = 0;
	$all  = 0;
	foreach ( gogh_launch_groups() as $g ) {
		foreach ( $g['items'] as $it ) {
			$all++;
			if ( $it['done'] ) {
				$done++;
			}
		}
	}
	return array( $done, $all );
}
add_action( 'admin_menu', function () {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return;
	}
	add_submenu_page( 'woocommerce', __( 'Launch your shop', 'gogh-editor' ), __( 'Launch', 'gogh-editor' ), 'manage_woocommerce', 'gogh-launch', 'gogh_launch_page', 1 );
	// off the menu (Launch is its door); a hidden page gets no title of its own, so admin_title supplies one below
	add_submenu_page( '', __( 'Get paid', 'gogh-editor' ), '', 'manage_woocommerce', 'gogh-payments', 'gogh_payments_page' );
}, 60 );
add_filter( 'admin_title', function ( $title ) {
	if ( isset( $_GET['page'] ) && 'gogh-payments' === $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return __( 'Get paid', 'gogh-editor' ) . ' &lsaquo; ' . get_bloginfo( 'name' ) . ' &#8212; WordPress';
	}
	return $title;
} );
function gogh_launch_css() {
	return '.gogh-launch{max-width:860px;margin:24px 0}.gogh-launch h1{font-size:28px;font-weight:600;letter-spacing:-.01em;margin:0 0 6px}.gogh-launch-lede{font-size:15px;color:#50575e;margin:0 0 18px;max-width:60ch}' .
		'.gogh-launch-bar{height:8px;border-radius:999px;background:#e5e7eb;overflow:hidden;margin:0 0 6px}.gogh-launch-bar i{display:block;height:100%;background:#1f5a3f;border-radius:999px;transition:width .4s}' .
		'.gogh-launch-count{font-size:13px;color:#646970;margin:0 0 26px}' .
		'.gogh-launch-group{background:#fff;border:1px solid #dcdcde;border-radius:12px;margin:0 0 18px;overflow:hidden}.gogh-launch-group h2{display:flex;justify-content:space-between;align-items:baseline;margin:0;padding:14px 20px;font-size:16px;font-weight:600;border-bottom:1px solid #f0f0f1}.gogh-launch-group h2 span{font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#646970}.gogh-launch-group h2 span.is-done{color:#1e5631}' .
		'.gogh-launch-item{display:grid;grid-template-columns:28px 1fr auto;gap:0 14px;align-items:center;padding:14px 20px;border-bottom:1px solid #f0f0f1}.gogh-launch-item:last-child{border-bottom:0}' .
		'.gogh-launch-mark{width:22px;height:22px;border-radius:50%;border:2px solid #c3c4c7;display:grid;place-items:center;font-size:13px;color:#fff}.gogh-launch-item.is-done .gogh-launch-mark{background:#1f5a3f;border-color:#1f5a3f}' .
		'.gogh-launch-item strong{display:block;font-size:14px;color:#1d2327}.gogh-launch-item.is-done strong{color:#646970;text-decoration:line-through;text-decoration-color:#c3c4c7}.gogh-launch-item small{display:block;font-size:13px;color:#646970;margin-top:2px}' .
		'.gogh-launch-item .button{white-space:nowrap}.gogh-launch-item.is-done .button{visibility:hidden}' .
		'.gogh-launch-foot{font-size:13px;color:#646970;margin:8px 0 0}' .
		'.gogh-pay-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:22px 24px;margin:0 0 16px;max-width:640px}.gogh-pay-card h2{margin:0 0 6px;font-size:18px;font-weight:600}.gogh-pay-card p{margin:0 0 12px;font-size:14px;color:#50575e;max-width:56ch}.gogh-pay-badges{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 14px}.gogh-pay-badges span{border:1px solid #dcdcde;border-radius:999px;padding:4px 10px;font-size:12px;color:#1d2327;background:#f6f7f7}' .
		'.gogh-pay-on{display:inline-block;background:#e6f4ea;color:#1e5631;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:600;margin:0 0 10px}' .
		'.gogh-pay-more summary{cursor:pointer;font-size:14px;color:#1f5a3f;font-weight:600}.gogh-pay-more ul{margin:10px 0 0 0;padding:0;list-style:none}.gogh-pay-more li{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f1;font-size:14px}.gogh-pay-more li em{font-style:normal;color:#646970}';
}
function gogh_launch_page() {
	$groups = gogh_launch_groups();
	list( $done, $all ) = gogh_launch_progress();
	echo '<style>' . gogh_launch_css() . '</style><div class="wrap gogh-launch">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<h1>' . esc_html__( 'Launch your shop', 'gogh-editor' ) . '</h1>';
	echo '<p class="gogh-launch-lede">' . esc_html__( 'Not a wizard — a list that reads your shop as it really is, and keeps going past the settings, through design, until people can buy.', 'gogh-editor' ) . '</p>';
	$pct = $all ? round( $done / $all * 100 ) : 0;
	echo '<div class="gogh-launch-bar"><i style="width:' . (int) $pct . '%"></i></div>';
	/* translators: 1: done, 2: total */
	echo '<p class="gogh-launch-count">' . esc_html( sprintf( __( '%1$d of %2$d done', 'gogh-editor' ), $done, $all ) ) . ( $done === $all ? ' — ' . esc_html__( 'the doors are open.', 'gogh-editor' ) : '' ) . '</p>';
	foreach ( $groups as $g ) {
		$gd = count( array_filter( $g['items'], function ( $i ) { return $i['done']; } ) );
		$ga = count( $g['items'] );
		echo '<section class="gogh-launch-group"><h2>' . esc_html( $g['title'] ) . '<span class="' . ( $gd === $ga ? 'is-done' : '' ) . '">' . (int) $gd . '/' . (int) $ga . '</span></h2>';
		foreach ( $g['items'] as $it ) {
			echo '<div class="gogh-launch-item' . ( $it['done'] ? ' is-done' : '' ) . '">' .
				'<span class="gogh-launch-mark" aria-hidden="true">' . ( $it['done'] ? '&#10003;' : '' ) . '</span>' .
				'<div><strong>' . esc_html( $it['title'] ) . '</strong><small>' . esc_html( $it['why'] ) . '</small></div>' .
				'<a class="button" href="' . esc_url( $it['url'] ) . '">' . esc_html( $it['verb'] ) . '</a></div>';
		}
		echo '</section>';
	}
	echo '<p class="gogh-launch-foot">' . esc_html__( 'Nothing here is ticked by hand: fix the thing and the list notices.', 'gogh-editor' ) . '</p></div>';
}
// one path to getting paid: cards and wallets in a step, the rest behind a link
function gogh_payments_page() {
	$installed = file_exists( WP_PLUGIN_DIR . '/woocommerce-payments/woocommerce-payments.php' );
	$active    = class_exists( 'WC_Payments' ) || is_plugin_active( 'woocommerce-payments/woocommerce-payments.php' );
	$enabled   = false;
	$others    = array();
	if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
		foreach ( WC()->payment_gateways()->payment_gateways() as $g ) {
			if ( 'woocommerce_payments' === $g->id ) {
				$enabled = 'yes' === $g->enabled;
			} else {
				$others[] = array( 'title' => $g->get_method_title(), 'on' => 'yes' === $g->enabled );
			}
		}
	}
	echo '<style>' . gogh_launch_css() . '</style><div class="wrap gogh-launch">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<h1>' . esc_html__( 'Get paid', 'gogh-editor' ) . '</h1>';
	echo '<p class="gogh-launch-lede">' . esc_html__( 'One way to take cards and wallets, set up in a few minutes. Everything else lives behind a link, for the day you need it.', 'gogh-editor' ) . '</p>';
	echo '<div class="gogh-pay-card">';
	if ( $enabled ) {
		echo '<span class="gogh-pay-on">' . esc_html__( 'On', 'gogh-editor' ) . '</span>';
	}
	echo '<h2>WooPayments</h2>';
	echo '<div class="gogh-pay-badges"><span>Visa</span><span>Mastercard</span><span>Amex</span><span>Apple Pay</span><span>Google Pay</span></div>';
	echo '<p>' . esc_html__( 'Built by the people who make WooCommerce. A small fee per sale and nothing monthly; the money lands in your bank account on a schedule you choose. Available in most countries — the setup tells you at once if yours is not.', 'gogh-editor' ) . '</p>';
	if ( $enabled ) {
		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=wc-admin&path=/payments/overview' ) ) . '">' . esc_html__( 'Open WooPayments', 'gogh-editor' ) . '</a>';
	} elseif ( $active ) {
		echo '<a class="button button-primary button-hero" href="' . esc_url( admin_url( 'admin.php?page=wc-admin&path=/payments/connect' ) ) . '">' . esc_html__( 'Finish setting up WooPayments', 'gogh-editor' ) . '</a>';
	} elseif ( $installed && current_user_can( 'activate_plugins' ) ) {
		echo '<a class="button button-primary button-hero" href="' . esc_url( wp_nonce_url( self_admin_url( 'plugins.php?action=activate&plugin=woocommerce-payments/woocommerce-payments.php' ), 'activate-plugin_woocommerce-payments/woocommerce-payments.php' ) ) . '">' . esc_html__( 'Turn on WooPayments', 'gogh-editor' ) . '</a>';
	} elseif ( current_user_can( 'install_plugins' ) ) {
		echo '<a class="button button-primary button-hero" href="' . esc_url( wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=woocommerce-payments' ), 'install-plugin_woocommerce-payments' ) ) . '">' . esc_html__( 'Add WooPayments', 'gogh-editor' ) . '</a>';
		echo '<p style="margin-top:10px">' . esc_html__( 'Installs the free WooPayments plugin from WordPress.org, then walks you through connecting a bank account.', 'gogh-editor' ) . '</p>';
	} else {
		echo '<p>' . esc_html__( 'Ask an administrator to add the WooPayments plugin.', 'gogh-editor' ) . '</p>';
	}
	echo '</div>';
	echo '<details class="gogh-pay-more gogh-pay-card"><summary>' . esc_html__( 'More payment options', 'gogh-editor' ) . '</summary>';
	echo '<p style="margin-top:10px">' . esc_html__( 'Bank transfer, cash on delivery, PayPal and the rest. Turn one on if that is how your customers already pay you.', 'gogh-editor' ) . '</p><ul>';
	foreach ( $others as $o ) {
		echo '<li>' . esc_html( $o['title'] ) . '<em>' . ( $o['on'] ? esc_html__( 'on', 'gogh-editor' ) : esc_html__( 'off', 'gogh-editor' ) ) . '</em></li>';
	}
	echo '</ul><p style="margin-top:12px"><a class="button" href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) . '">' . esc_html__( 'All payment settings', 'gogh-editor' ) . '</a></p></details>';
	echo '<p class="gogh-launch-foot"><a href="' . esc_url( admin_url( 'admin.php?page=gogh-launch' ) ) . '">&larr; ' . esc_html__( 'Back to Launch your shop', 'gogh-editor' ) . '</a></p></div>';
}
// the count rides the admin bar until the doors are open
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( ! is_admin() || ! function_exists( 'wc_get_products' ) || ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	list( $done, $all ) = gogh_launch_progress();
	if ( ! $all || $done === $all ) {
		return;
	}
	$bar->add_node( array(
		'id'    => 'gogh-launch',
		'title' => '🚀 ' . sprintf( __( 'Launch %1$d/%2$d', 'gogh-editor' ), $done, $all ),
		'href'  => admin_url( 'admin.php?page=gogh-launch' ),
		'meta'  => array( 'title' => __( 'Launch your shop — what is left', 'gogh-editor' ) ),
	) );
}, 90 );
// 'You might also like' on product pages: on by default (it sells), one
// click off for a maker with three products (James: 'folks might want
// to hide the you might also like section')
add_filter( 'render_block_core/group', function ( $html, $block ) {
	$cls = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( false !== strpos( $cls, 'gogh-related' ) && '0' === (string) get_option( 'gogh_product_related', '1' ) ) {
		return '';
	}
	return $html;
}, 10, 2 );
add_action( 'admin_post_gogh_product_related', function () {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You cannot change this.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_product_related' );
	update_option( 'gogh_product_related', '0' === (string) get_option( 'gogh_product_related', '1' ) ? '1' : '0' );
	$back = isset( $_GET['back'] ) ? esc_url_raw( wp_unslash( $_GET['back'] ) ) : '';
	wp_safe_redirect( $back ? $back : home_url( '/' ) );
	exit;
} );

add_action( 'admin_post_gogh_product_layout_all', function () {
	$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
	if ( ! current_user_can( 'edit_others_posts' ) ) {
		wp_die( esc_html__( 'You cannot change other products.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_product_layout_all' );
	$layout = $id ? get_page_template_slug( $id ) : '';
	if ( ! array_key_exists( $layout, gogh_product_layouts() ) ) {
		$layout = '';
	}
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	) );
	foreach ( $ids as $prod_id ) {
		if ( '' === $layout ) {
			delete_post_meta( $prod_id, '_wp_page_template' );
		} else {
			update_post_meta( $prod_id, '_wp_page_template', $layout );
		}
	}
	wp_safe_redirect( $id ? get_permalink( $id ) : home_url( '/' ) );
	exit;
} );

/**
 * Post layouts: the reading looks, as a fixed menu on the admin bar —
 * one per post, or stamped across every post in one click.
 */
function gogh_post_layouts() {
	return array(
		''           => __( 'Theme default — the theme\'s own post', 'gogh-editor' ),
		'magazine'   => __( 'Magazine — big opener, generous columns', 'gogh-editor' ),
		'journal'    => __( 'Journal — quiet, dated, personal', 'gogh-editor' ),
		'essay'      => __( 'Essay — one calm column of type', 'gogh-editor' ),
		'gazette'    => __( 'Gazette — newspaper rhythm', 'gogh-editor' ),
		'photostory' => __( 'Photo story — pictures lead', 'gogh-editor' ),
		'feature'    => __( 'Feature — long-form, art-directed', 'gogh-editor' ),
		'cover'      => __( 'Cover — the photo is the title page', 'gogh-editor' ),
		'manual'     => __( 'Manual — side contents, tables and code', 'gogh-editor' ),
	);
}
add_action( 'admin_post_gogh_blog_layout', function () {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You cannot change the blog layout.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_blog_layout' );
	$layout = isset( $_GET['layout'] ) ? sanitize_key( wp_unslash( $_GET['layout'] ) ) : '';
	if ( ! in_array( $layout, gogh_blog_styles(), true ) ) {
		wp_die( esc_html__( 'Unknown layout.', 'gogh-editor' ) );
	}
	update_option( 'gogh_blog_style', $layout );
	$back = isset( $_GET['back'] ) ? esc_url_raw( wp_unslash( $_GET['back'] ) ) : '';
	wp_safe_redirect( $back ? $back : home_url( '/' ) );
	exit;
} );
add_action( 'admin_post_gogh_post_layout', function () {
	$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
	$layout = isset( $_GET['layout'] ) ? sanitize_key( wp_unslash( $_GET['layout'] ) ) : '';
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		wp_die( esc_html__( 'You cannot edit this post.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_post_layout_' . $id );
	if ( ! array_key_exists( $layout, gogh_post_layouts() ) ) {
		wp_die( esc_html__( 'Unknown layout.', 'gogh-editor' ) );
	}
	if ( '' === $layout ) {
		delete_post_meta( $id, '_gogh_post_style' );
	} else {
		update_post_meta( $id, '_gogh_post_style', $layout );
	}
	wp_safe_redirect( get_permalink( $id ) );
	exit;
} );
add_action( 'admin_post_gogh_post_layout_all', function () {
	$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
	if ( ! current_user_can( 'edit_others_posts' ) ) {
		wp_die( esc_html__( 'You cannot change other posts.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_post_layout_all' );
	$layout = $id ? (string) get_post_meta( $id, '_gogh_post_style', true ) : '';
	if ( ! array_key_exists( $layout, gogh_post_layouts() ) ) {
		$layout = '';
	}
	$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
	foreach ( $ids as $pid ) {
		if ( '' === $layout ) {
			delete_post_meta( $pid, '_gogh_post_style' );
		} else {
			update_post_meta( $pid, '_gogh_post_style', $layout );
		}
	}
	wp_safe_redirect( $id ? get_permalink( $id ) : home_url( '/' ) );
	exit;
} );
// a product that never chose a layout wears Story — so gogh works on every
// product page from the first one, and 'Edit with gogh' is never a dead door
add_filter( 'get_post_metadata', function ( $value, $object_id, $meta_key, $single ) {
	if ( '_wp_page_template' !== $meta_key || is_admin() || ! class_exists( 'WooCommerce' ) ) {
		return $value;
	}
	if ( 'product' !== get_post_type( $object_id ) ) {
		return $value;
	}
	// an editor hovering the admin bar's Product layout menu tries a layout
	// on by fetching this page with ?gogh-layout=<slug>: worn for that one
	// request, nothing stored (the menu's click is the commit)
	if ( isset( $_GET['gogh-layout'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation-only preview
		$try = sanitize_key( $_GET['gogh-layout'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $try && function_exists( 'gogh_product_layouts' ) && array_key_exists( $try, gogh_product_layouts() ) && current_user_can( 'edit_post', $object_id ) ) {
			return $single ? $try : array( $try );
		}
	}
	static $guard = false;
	if ( $guard ) {
		return $value;
	}
	$guard = true;
	$real  = get_post_meta( $object_id, '_wp_page_template', true );
	$guard = false;
	if ( $real && 'default' !== $real ) {
		return $value;
	}
	return $single ? 'gogh-product-story' : array( 'gogh-product-story' );
}, 10, 4 );
// ---------- layout auditions from the admin bar ----------
// hovering a look in the admin bar's Product / Post / Blog / Shop / Category
// layout menus tries it on before the click commits it: the die, the transition chips
// and the blog pill all audition, and a menu that reloaded on click was
// the odd one out (James: 'do you think these should audition?'). Blog
// and reading looks are body classes and swap live (the Manual look's
// contents rail is built on the spot); a product layout is a block
// template, so the page is fetched wearing ?gogh-layout=<slug> and its
// main swapped in, the original kept aside for the moment the pointer
// leaves the menu; a shop look changes the grid's markup, so it goes the
// same way with ?gogh-shoplook=<slug>. Nothing is stored until the click.
add_action( 'wp_footer', function () {
	// editors only; where a page carries none of the menus the script is a
	// no-op with its two verbs exposed (the suite drives them on the fixture)
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	$js = <<<'JS'
(function () {
  var body = document.body;
  var KINDS = {
    'gogh-product-layout': { fetch: 'gogh-layout' },
    'gogh-post-layout': { cls: 'gogh-read-', toc: true },
    'gogh-blog-layout': { cls: 'gogh-blog-' },
    'gogh-shop-layout': { fetch: 'gogh-shoplook' },
    'gogh-category-layout': { fetch: 'gogh-shoplook' }
  };
  var snapClass = null, origMain = null, shownMain = null, seq = 0, cache = {}, tocMade = false;
  var content = function () { return document.querySelector('.entry-content, .wp-block-post-content'); };
  var tocOn = function () {
    var root = content();
    if (root && window.goghManualToc && !root.querySelector(':scope > .gogh-toc')) { window.goghManualToc(root); tocMade = true; }
  };
  var tocOff = function () {
    if (!tocMade) return;
    var root = content(), nav = root && root.querySelector(':scope > .gogh-toc');
    if (nav) nav.remove();
    if (root) root.classList.remove('gogh-has-toc');
    tocMade = false;
  };
  var restore = function () {
    seq++;
    if (shownMain && origMain && shownMain !== origMain && shownMain.parentNode) shownMain.replaceWith(origMain);
    shownMain = null;
    tocOff();
    if (snapClass !== null) body.className = snapClass;
    snapClass = null;
  };
  var wearClass = function (prefix, slug) {
    body.className = body.className.split(/\s+/).filter(function (c) { return c && c.indexOf(prefix) !== 0; }).join(' ') + (slug ? ' ' + prefix + slug : '');
  };
  var preview = function (id, slug) {
    var kind = KINDS[id];
    if (!kind) return;
    if (snapClass === null) snapClass = body.className;
    if (kind.cls) {
      wearClass(kind.cls, slug);
      body.classList.add('gogh-auditioning');
      if (kind.toc) { if (slug === 'manual') tocOn(); else tocOff(); }
      return;
    }
    var my = ++seq;
    var url = new URL(location.href);
    url.searchParams.set(kind.fetch, slug);
    var key = url.toString();
    if (!cache[key]) {
      cache[key] = fetch(key, { credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (t) {
        var doc = new DOMParser().parseFromString(t, 'text/html');
        return { main: doc.querySelector('main'), cls: doc.body.className };
      });
    }
    cache[key].then(function (got) {
      if (my !== seq || !got.main) return;
      var cur = document.querySelector('main');
      if (!cur) return;
      if (!origMain) origMain = cur;
      var fresh = got.main.cloneNode(true);
      // Woo's gallery waits at opacity 0 for a script that will not run on a
      // preview; show the picture as it is
      [].slice.call(fresh.querySelectorAll('.woocommerce-product-gallery')).forEach(function (g) { g.style.opacity = '1'; });
      // pictures born in a parsed document never start loading: set them
      // eager and hand them their address again
      [].slice.call(fresh.querySelectorAll('img')).forEach(function (im) { im.loading = 'eager'; var src = im.getAttribute('src'); if (src) { im.removeAttribute('src'); im.setAttribute('src', src); } });
      cur.replaceWith(fresh);
      shownMain = fresh;
      body.className = got.cls + ' gogh-auditioning';
    }).catch(function () {});
  };
  // the admin bar prints at the very end of the footer: bind once it exists
  var bind = function () { Object.keys(KINDS).forEach(function (id) {
    var menu = document.getElementById('wp-admin-bar-' + id);
    var list = document.getElementById('wp-admin-bar-' + id + '-default');
    if (!menu || !list) return;
    [].slice.call(list.querySelectorAll(':scope > li > a')).forEach(function (a) {
      a.addEventListener('mouseenter', function () {
        var slug = '';
        try { slug = new URL(a.href, location.href).searchParams.get('layout') || ''; } catch (e) {}
        preview(id, slug);
      });
    });
    menu.addEventListener('mouseleave', restore);
  }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
  window.goghAudition = { preview: preview, restore: restore };
})();
JS;
	echo wp_get_inline_script_tag( $js, array( 'id' => 'gogh-audition' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a script tag built by core from a literal
}, 5 ); // before the footer's enqueued scripts (the suite among them) and the admin bar
add_action( 'admin_post_gogh_product_layout', function () {
	$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
	$layout = isset( $_GET['layout'] ) ? sanitize_text_field( wp_unslash( $_GET['layout'] ) ) : '';
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		wp_die( esc_html__( 'You cannot edit this product.', 'gogh-editor' ) );
	}
	check_admin_referer( 'gogh_product_layout_' . $id );
	if ( ! array_key_exists( $layout, gogh_product_layouts() ) ) {
		wp_die( esc_html__( 'Unknown layout.', 'gogh-editor' ) );
	}
	if ( '' === $layout ) {
		delete_post_meta( $id, '_wp_page_template' );
		wp_safe_redirect( get_permalink( $id ) );
	} else {
		update_post_meta( $id, '_wp_page_template', $layout );
		wp_safe_redirect( add_query_arg( 'gogh-edit', '1', get_permalink( $id ) ) );
	}
	exit;
} );

/**
 * Wrapped images: text flows around a floated image's silhouette via
 * shape-outside. KSES must not strip the properties (or the img style) for
 * users below unfiltered_html.
 */
add_filter( 'safe_style_css', function ( $props ) {
	$props[] = 'float';
	$props[] = 'shape-outside';
	$props[] = 'shape-margin';
	$props[] = 'shape-image-threshold';
	$props[] = 'object-position'; // break-image focal point rides inline
	return $props;
} );
add_filter( 'wp_kses_allowed_html', function ( $tags, $context ) {
	if ( 'post' === $context && isset( $tags['img'] ) ) {
		$tags['img']['style'] = true;
	}
	if ( 'post' === $context ) {
		// video elements and backgrounds: a silent, looping, inline-playing
		// <video> must survive KSES for authors without unfiltered_html
		$tags['video'] = array_merge( isset( $tags['video'] ) ? $tags['video'] : array(), array(
			'class' => true, 'src' => true, 'poster' => true, 'autoplay' => true, 'muted' => true, 'loop' => true,
			'playsinline' => true, 'controls' => true, 'preload' => true, 'aria-hidden' => true, 'tabindex' => true,
		) );
	}
	return $tags;
}, 10, 2 );

/**
 * Core keys plugin-registered templates by NAME ('gogh//blank-canvas') when
 * it merges them into get_block_templates() results, but wp-includes/
 * block-editor.php reads [0] from that array — on a page using our Blank
 * canvas template the block editor emits warnings and white-screens.
 * Reindexing costs nothing and keeps every caller's expectation of a list.
 */
add_filter( 'get_block_templates', function ( $templates ) {
	return is_array( $templates ) ? array_values( $templates ) : $templates;
} );

/**
 * Pattern previews: core's block-renderer returns markup WITHOUT the
 * per-instance layout CSS (flex/grid/gap rules the style engine generates
 * during render), so grids collapse into a squished huddle in the picker.
 * This route renders a pattern and hands back that CSS alongside the markup.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'gogh/v1', '/pattern', array(
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'args'                => array( 'slug' => array( 'required' => true, 'type' => 'string' ) ),
		'callback'            => function ( $req ) {
			$pat = WP_Block_Patterns_Registry::get_instance()->get_registered( (string) $req['slug'] );
			if ( ! $pat ) {
				return new WP_Error( 'gogh_no_pattern', __( 'Unknown pattern.', 'gogh-editor' ), array( 'status' => 404 ) );
			}
			// a preview is a PICTURE of the page: rails elements show the
			// model's own sample shop rather than asking Woo for a query that
			// renders nothing outside a real page (the Shop card was blank)
			$GLOBALS['gogh_pattern_preview'] = true;
			$html = do_blocks( (string) $pat['content'] );
			$GLOBALS['gogh_pattern_preview'] = false;
			// BOTH style-engine stores, the /render lesson: with the
			// Gutenberg plugin active its namespaced store holds the layout
			// rules and core's sits empty — querying only core collapsed
			// every pattern card to a stacked strip ("really weird and small")
			$css = '';
			if ( function_exists( 'gutenberg_style_engine_get_stylesheet_from_context' ) ) {
				$css .= (string) gutenberg_style_engine_get_stylesheet_from_context( 'block-supports' );
			}
			if ( function_exists( 'wp_style_engine_get_stylesheet_from_context' ) ) {
				$css .= (string) wp_style_engine_get_stylesheet_from_context( 'block-supports' );
			}
			return array( 'rendered' => $html, 'css' => $css );
		},
	) );
} );

/**
 * Last line of defence for site chrome: gogh's editor UI classes must never
 * appear in STORED template parts or navigation menus. If they do, some
 * DOM-derived markup is being saved by mistake (this once replaced a header
 * with its own rendered DOM, add-page buttons included) — refuse the write
 * loudly instead of corrupting every page on the site.
 */
add_action( 'rest_api_init', function () {
	$guard = function ( $prepared ) {
		$c = is_object( $prepared ) && isset( $prepared->post_content ) ? $prepared->post_content : '';
		foreach ( array( 'gogh-navadd', 'gogh-pendbar', 'gogh-storedrm', 'gogh-convertbtn', 'gogh-selbox', 'data-gogh' ) as $mark ) {
			if ( false !== strpos( $c, $mark ) ) {
				return new WP_Error(
					'gogh_artifact_in_chrome',
					__( 'gogh blocked this save: editor-only markup was about to be stored in site chrome.', 'gogh-editor' ),
					array( 'status' => 400 )
				);
			}
		}
		return $prepared;
	};
	add_filter( 'rest_pre_insert_wp_template_part', $guard );
	add_filter( 'rest_pre_insert_wp_navigation', $guard );
} );

/**
 * Your brand: a small recipe (four colours, two font slugs) stored as a
 * site option and editable over the core settings REST route. Applying it
 * writes user Global Styles through the same path as theme variations.
 */
add_action( 'init', function () {
	register_setting( 'options', 'gogh_brand', array(
		'type'         => 'object',
		'default'      => null,
		'show_in_rest' => array(
			'schema' => array(
				'type'                 => 'object',
				'properties'           => array(
					'colors' => array(
						'type'       => 'object',
						'properties' => array(
							'background' => array( 'type' => 'string' ),
							'text'       => array( 'type' => 'string' ),
							'accent'     => array( 'type' => 'string' ),
							'accent2'    => array( 'type' => 'string' ),
						),
					),
					'fonts'  => array(
						'type'       => 'object',
						'properties' => array(
							'heading' => array( 'type' => 'string' ),
							'body'    => array( 'type' => 'string' ),
						),
					),
					// families the brand had installed (a guideline naming a font the
					// site lacked): name, slug, fontFamily and the faces' self-hosted
					// files, so Remix and a later keep can write them back into styles
					'families' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'name'       => array( 'type' => 'string' ),
								'slug'       => array( 'type' => 'string' ),
								'fontFamily' => array( 'type' => 'string' ),
								'fontFace'   => array(
									'type'  => 'array',
									'items' => array(
										'type'       => 'object',
										'properties' => array(
											'fontFamily' => array( 'type' => 'string' ),
											'fontStyle'  => array( 'type' => 'string' ),
											'fontWeight' => array( 'type' => 'string' ),
											'src'        => array( 'type' => 'string' ),
										),
									),
								),
							),
						),
					),
				),
				'additionalProperties' => false,
			),
		),
	) );
} );

/**
 * Experience bundles are plain .html uploads — allowed only for users who
 * may already publish arbitrary markup (unfiltered_html), so this grants
 * no capability they don't have.
 */
add_filter( 'upload_mimes', function ( $mimes ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		$mimes['html'] = 'text/html';
	}
	return $mimes;
} );

/**
 * SPIKE variant B: rebake. On every save — by anyone, including users whose
 * content KSES just filtered — regenerate the baked <style> inside each v3
 * section from its attributes. The plugin authors these bytes server-side,
 * so the saver's capabilities are irrelevant; deactivation keeps the look.
 * ADOPTED as production behaviour (variant B won the matrix): default ON,
 * gogh_rebake_enabled filter remains as the escape hatch.
 */
function gogh_rebake_post_data( $data ) {
	if ( ! apply_filters( 'gogh_rebake_enabled', true ) ) {
		return $data;
	}
	if ( empty( $data['post_content'] ) || false === strpos( $data['post_content'], 'wp:gogh/section' ) ) {
		return $data;
	}
	$content = wp_unslash( $data['post_content'] );
	$blocks  = parse_blocks( $content );
	$changed = false;
	foreach ( $blocks as &$b ) {
		if ( 'gogh/section' !== $b['blockName'] || empty( $b['attrs'] ) ) {
			continue;
		}
		$css = gogh_css_from_attrs( $b['attrs'] );
		if ( '' === $css || false !== strpos( (string) $b['innerHTML'], 'class="gogh-style"' ) ) {
			continue;
		}
		$style = '<style class="gogh-style">' . $css . '</style>';
		foreach ( array( 'innerHTML', 'innerContent' ) as $k ) {
			if ( 'innerContent' === $k ) {
				foreach ( $b['innerContent'] as &$chunk ) {
					if ( is_string( $chunk ) && false !== strpos( $chunk, 'wp-block-gogh-section' ) ) {
						$chunk   = gogh_sweep_css_residue( $chunk );
						$chunk   = preg_replace( '/(<div class="wp-block-gogh-section[^"]*">)/', '$1' . $style, $chunk, 1 );
						$changed = true;
						break;
					}
				}
			} else {
				$b[ $k ] = gogh_sweep_css_residue( (string) $b[ $k ] );
				$b[ $k ] = preg_replace( '/(<div class="wp-block-gogh-section[^"]*">)/', '$1' . $style, $b[ $k ], 1 );
			}
		}
	}
	unset( $b );
	if ( $changed ) {
		$data['post_content'] = wp_slash( serialize_blocks( $blocks ) );
	}
	return $data;
}
add_filter( 'wp_insert_post_data', 'gogh_rebake_post_data', 20 );

/**
 * ✦ Answer-ready — the page's meaning, emitted as JSON-LD.
 *
 * Schema is to meaning what cssT is to looks: a second projection of the
 * same section model. The designer composed an FAQ accordion, so the model
 * literally stores the questions and answers — no inference, no settings
 * screen. On save the graph is computed once into _gogh_schema; wp_head
 * just echoes the cached bytes.
 *
 * Guardrails: emit only what the design states. An FAQPage needs a real
 * question AND answer; anything incomplete simply doesn't emit. Yoast and
 * RankMath own the graph when they're active, and gogh_schema_enabled is
 * the escape hatch.
 */
function gogh_schema_collect_els( $els, &$faq, &$first_para ) {
	foreach ( (array) $els as $e ) {
		if ( ! empty( $e['faq'] ) && is_array( $e['faq'] ) ) {
			foreach ( $e['faq'] as $item ) {
				$q = trim( wp_strip_all_tags( (string) ( $item['q'] ?? '' ) ) );
				$a = trim( wp_strip_all_tags( (string) ( $item['a'] ?? '' ) ) );
				if ( '' !== $q && '' !== $a ) {
					$faq[] = array( 'q' => $q, 'a' => $a );
				}
			}
		}
		if ( '' === $first_para && ( $e['type'] ?? '' ) === 'para' && ! empty( $e['text'] ) ) {
			$first_para = trim( wp_strip_all_tags( (string) $e['text'] ) );
		}
		if ( ! empty( $e['kids'] ) && is_array( $e['kids'] ) ) {
			gogh_schema_collect_els( $e['kids'], $faq, $first_para );
		}
	}
}

function gogh_schema_build( $post ) {
	$faq        = array();
	$first_para = '';
	foreach ( parse_blocks( gogh_html_unpark_content( $post->post_content ) ) as $b ) {
		if ( 'gogh/section' !== ( $b['blockName'] ?? '' ) ) {
			continue;
		}
		if ( ! empty( $b['attrs']['model']['elements'] ) ) {
			gogh_schema_collect_els( $b['attrs']['model']['elements'], $faq, $first_para );
		} elseif ( ! empty( $b['innerHTML'] ) &&
			preg_match( '/<script type="application\/json" class="gogh-model">(.*?)<\/script>/s', $b['innerHTML'], $m ) ) {
			// legacy v2 sections carry the model in a script tag, not attrs
			$j = json_decode( $m[1], true );
			if ( ! empty( $j['elements'] ) ) {
				gogh_schema_collect_els( $j['elements'], $faq, $first_para );
			}
		}
	}
	$home = home_url( '/' );
	$org  = array(
		'@type' => 'Organization',
		'@id'   => $home . '#org',
		'name'  => get_bloginfo( 'name' ),
		'url'   => $home,
	);
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$logo = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $logo ) {
			$org['logo'] = $logo;
		}
	}
	if ( 'post' === $post->post_type ) {
		// Write posts are pure core blocks (deactivation-safe by design), so
		// the Article's facts come from WordPress itself — headline, dates,
		// author, image. Nothing here is inferred; every field is a fact WP
		// already asserts about the post.
		$page = array(
			'@type'            => 'Article',
			'headline'         => mb_substr( get_the_title( $post ), 0, 110 ),
			'url'              => get_permalink( $post ),
			'mainEntityOfPage' => get_permalink( $post ),
			'datePublished'    => get_post_time( 'c', true, $post ),
			'dateModified'     => get_post_modified_time( 'c', true, $post ),
			'publisher'        => array( '@id' => $home . '#org' ),
		);
		$author = get_the_author_meta( 'display_name', $post->post_author );
		if ( $author ) {
			$page['author'] = array( '@type' => 'Person', 'name' => $author );
		}
		$img = get_the_post_thumbnail_url( $post, 'full' );
		if ( ! $img && preg_match( '/<img[^>]+src="([^"]+)"/', $post->post_content, $im ) ) {
			$img = $im[1]; // the first break/splash image stands in for a missing featured image
		}
		if ( $img ) {
			$page['image'] = $img;
		}
		// the writer's own words WIN: the excerpt (edited on the search-
		// preview card) beats every derived fallback
		$hand = trim( wp_strip_all_tags( (string) $post->post_excerpt ) );
		$desc = '' !== $hand ? $hand
			: ( '' !== $first_para ? $first_para
				: wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 28, '…' ) );
		if ( $desc ) {
			$page['description'] = mb_substr( $desc, 0, '' !== $hand ? 300 : 160 );
		}
	} else {
		$page = array(
			'@type'        => 'WebPage',
			'name'         => get_the_title( $post ),
			'url'          => get_permalink( $post ),
			'dateModified' => get_post_modified_time( 'c', true, $post ),
			'publisher'    => array( '@id' => $home . '#org' ),
		);
		// same law as posts: the writer's own words WIN — the excerpt
		// (edited on the search-preview card) beats the derived first line
		$hand = trim( wp_strip_all_tags( (string) $post->post_excerpt ) );
		$desc = '' !== $hand ? $hand : $first_para;
		if ( '' !== $desc ) {
			$page['description'] = mb_substr( $desc, 0, '' !== $hand ? 300 : 160 );
		}
	}
	$graph = array( $org, $page );
	if ( $faq ) {
		$graph[] = array(
			'@type'      => 'FAQPage',
			'mainEntity' => array_map( function ( $p ) {
				return array(
					'@type'          => 'Question',
					'name'           => $p['q'],
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => $p['a'],
					),
				);
			}, $faq ),
		);
	}
	return apply_filters( 'gogh_schema', array( '@context' => 'https://schema.org', '@graph' => $graph ), $post );
}

add_action( 'save_post', function ( $post_id, $post ) {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	if ( ! in_array( $post->post_type, array( 'page', 'post' ), true ) ) {
		return;
	}
	// pages carry meaning in their section models — no sections, no graph.
	// POSTS always emit: the Article's facts (title, dates, author, image)
	// are WordPress's own assertions, true whether or not the words were
	// written in gogh's Write room ("does this work with write?").
	if ( 'page' === $post->post_type && ! has_block( 'gogh/section', $post ) ) {
		delete_post_meta( $post_id, '_gogh_schema' );
		return;
	}
	if ( 'publish' !== $post->post_status && 'post' === $post->post_type && ! has_block( 'gogh/section', $post ) ) {
		return; // drafts keep whatever they had; the graph lands on publish
	}
	$graph = gogh_schema_build( $post );
	if ( $graph ) {
		// HEX_TAG keeps </script> impossible inside the JSON; wp_slash
		// survives the meta layer's stripslashes so \u escapes hold
		update_post_meta( $post_id, '_gogh_schema', wp_slash( wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) ) );
	} else {
		delete_post_meta( $post_id, '_gogh_schema' );
	}
}, 10, 2 );

add_action( 'wp_head', function () {
	if ( ! is_singular() ) {
		return;
	}
	if ( defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) ) {
		return; // the SEO plugin owns the graph — no duplicate-schema fights
	}
	if ( ! apply_filters( 'gogh_schema_enabled', true ) ) {
		return;
	}
	$json = get_post_meta( get_the_ID(), '_gogh_schema', true );
	if ( $json ) {
		echo '<script type="application/ld+json" class="gogh-schema">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- pre-encoded JSON authored server-side
	}
} );

/**
 * ✦ The deactivation promise: switch gogh off and the site keeps its look.
 * Section layout is already baked into the saved content (the rebake), but
 * the splash and widget presentation lived only in enqueued CSS — a
 * carousel collapsed to a stack the moment the plugin went quiet. On
 * deactivation this writes the presentation CSS into the theme's own
 * Additional CSS (no plugin required to serve it); reactivation removes
 * the marked block again so nothing is ever doubled.
 */
function gogh_leavebehind_css() {
	return gogh_splash_css() . gogh_widget_css() .
		// the template-level gap zeroing keeps painted bands touching
		'.wp-site-blocks > header, .wp-site-blocks > main, .wp-site-blocks > footer, .wp-site-blocks > .wp-block-template-part { margin-block: 0 !important; }' .
		'.gogh-wrap { margin-block: 0 !important; min-width: 100%; }' .
		'.entry-content:has(> .gogh-wrap) { margin-block: 0 !important; }' .
		'.gogh-section > .wp-block-group { padding: 0 !important; box-sizing: border-box; }' .
		'.gogh-section > * { box-sizing: border-box; }' .
		// video backgrounds: the loop sits under everything; its poster (the
		// section image) shows until it plays, and whenever motion is off
		'.gogh-section > .gogh-bgvideo { position: absolute; inset: 0; z-index: -1; margin: 0 !important; padding: 0 !important; pointer-events: none; overflow: hidden; }' .
		'.gogh-section > .gogh-bgvideo video { width: 100%; height: 100%; object-fit: cover; display: block; }' .
		'.gogh-bgvideo-btn { position: absolute; right: 14px; bottom: 14px; z-index: 60; width: 36px; height: 36px; border-radius: 50%; border: 0; padding: 0; cursor: pointer; background: rgba(15,23,42,0.55); color: #fff; display: grid; place-items: center; opacity: 0.72; transition: opacity 0.2s; }' .
		'.gogh-bgvideo-btn:hover, .gogh-bgvideo-btn:focus-visible { opacity: 1; }' .
		'.gogh-bgvideo-btn svg { width: 14px; height: 14px; display: block; }' .
		'@media (prefers-reduced-motion: reduce) { .gogh-section > .gogh-bgvideo, .gogh-bgvideo-btn { display: none; } }' .
		// the video element: the frame is the design's, the player fills it
		'.gogh-section > .gogh-vid { overflow: hidden; overflow: clip; }' .
		'.gogh-section > .gogh-vid video, .gogh-section > .gogh-vid iframe { width: 100%; height: 100%; object-fit: cover; display: block; border: 0; border-radius: inherit; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper { position: relative; height: 100%; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper::before { content: none !important; padding: 0 !important; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper iframe { position: absolute; inset: 0; }' .
		'.gogh-section-html { box-sizing: border-box !important; width: 100vw !important; max-width: 100vw !important; margin-inline: calc(50% - 50vw) !important; margin-block: 0 !important; }' .
		'.gogh-paste-plain { padding-block: 2.5rem; } .gogh-paste-plain > :where(section, article, div, main, header, footer) { max-width: 46rem; margin-inline: auto; padding-inline: 1.25rem; } .gogh-paste-plain img { display: block; max-width: 100%; height: auto; max-height: min(55vh, 480px); object-fit: cover; margin-block: 1rem; border-radius: 6px; } .gogh-paste-plain :where(section, article, div) > a { display: inline-block; margin: 0.5rem 0.75rem 0.5rem 0; } .gogh-paste-plain h1 { font-size: 2.2em; line-height: 1.1; margin-block: 0.4em; } .gogh-paste-plain h2 { font-size: 1.6em; margin-block: 1.4em 0.4em; } .gogh-paste-plain h3 { font-size: 1.15em; margin-block: 1.2em 0.3em; }' .
		'html { overflow-x: clip; }' .
		'.entry-content > .gogh-wrap + .alignfull, .entry-content > .alignfull + .gogh-wrap, .entry-content > .alignfull + .alignfull { margin-block-start: 0; }';
}
function gogh_strip_leavebehind( $css ) {
	return preg_replace( '/\n?\/\* gogh:keep-the-look start \*\/.*?\/\* gogh:keep-the-look end \*\/\n?/s', '', (string) $css );
}
// keep the BLOCKS too: a self-contained helper goes into mu-plugins so the
// block editor still knows gogh/section (and gogh/form) with Gogh away —
// "gogh Section" with its inner blocks, not "Unsupported" and a Keep-as-HTML
// button that flattens them. The helper deletes itself once Gogh is back.
function gogh_keep_blocks_target() {
	return trailingslashit( defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins' ) . 'gogh-keep-blocks.php';
}
function gogh_keep_blocks_leave() {
	$src = __DIR__ . '/gogh-keep-blocks.php';
	$dst = gogh_keep_blocks_target();
	if ( ! is_readable( $src ) ) {
		return false;
	}
	$dir = dirname( $dst );
	if ( ! is_dir( $dir ) ) {
		@wp_mkdir_p( $dir );
	}
	if ( ! is_dir( $dir ) || ! wp_is_writable( $dir ) ) {
		return false; // nothing changes from today: pages still render, the wrapper reads as unsupported
	}
	// the helper carries the plugin's own editor canvas rules, as of now
	$code = file_get_contents( $src );
	if ( false === $code ) {
		return false;
	}
	$code = str_replace(
		'/*GOGH_HELPER_HEADER*/',
		"/**\n * Plugin Name: Gogh — keep the blocks\n * Description: Left behind when Gogh is deactivated so its sections stay ordinary, editable blocks in the block editor. Removes itself when Gogh is active again.\n * Version: " . GOGH_VERSION . "\n */",
		$code
	);
	$code = str_replace( "'/*GOGH_EDITOR_CANVAS_CSS*/'", var_export( gogh_editor_canvas_css(), true ), $code );
	$code = str_replace( "'/*GOGH_EDITOR_FLATTEN_CSS*/'", var_export( gogh_editor_flatten_css(), true ), $code );
	return (bool) @file_put_contents( $dst, $code );
}
function gogh_keep_blocks_take_back() {
	$dst = gogh_keep_blocks_target();
	if ( file_exists( $dst ) ) {
		@unlink( $dst );
	}
	delete_option( 'gogh_keep_blocks_noted' ); // the note says its piece again next time
}
register_deactivation_hook( __FILE__, function () {
	$css = gogh_strip_leavebehind( wp_get_custom_css() );
	wp_update_custom_css_post( $css . "\n/* gogh:keep-the-look start */\n" . gogh_leavebehind_css() . "\n/* gogh:keep-the-look end */\n" );
	gogh_keep_blocks_leave();
} );
register_activation_hook( __FILE__, function () {
	$css   = wp_get_custom_css();
	$clean = gogh_strip_leavebehind( $css );
	if ( $clean !== $css ) {
		wp_update_custom_css_post( $clean );
	}
	gogh_keep_blocks_take_back();
} );

/**
 * FAQ + Tabs widget polish — one source for the front end, the editor,
 * and the deactivation leave-behind.
 */
function gogh_widget_css() {
	return
		// FAQ + Tabs widgets: quiet, theme-inked styling for the real blocks —
		// the same rules dress the editor preview (the edit page IS the front)
		// the theme's flow blockGap dresses accordion internals like prose —
		// big margins between item, heading and panel (James: "formatting
		// breakage"). The widget owns its rhythm.
		// the widget wrapper is display:flex (it centres SMALL widgets — nav,
		// site title); accordion and tabs are block content and must fill the
		// box, not shrink to their words (the "narrow accordion" report)
		'.gogh-widget > .wp-block-accordion, .gogh-widget > .wp-block-tabs { flex: 1 1 100%; width: 100%; }' .
		'.gogh-widget .wp-block-accordion > *, .gogh-widget .wp-block-accordion-item > *, .gogh-widget .wp-block-tabs > *, .gogh-widget .wp-block-accordion-panel__content > *, .gogh-widget .wp-block-accordion-panel > *, .gogh-widget .wp-block-tab-panel > * { margin-block: 0 !important; }' .
		'.gogh-widget .wp-block-accordion-item { border-top: 1px solid color-mix(in srgb, currentColor 16%, transparent); }' .
		'.gogh-widget .wp-block-accordion-item:last-child { border-bottom: 1px solid color-mix(in srgb, currentColor 16%, transparent); }' .
		'.gogh-widget .wp-block-accordion-heading { margin: 0; font-size: 1.02em; }' .
		'.gogh-widget .wp-block-accordion-heading__toggle { display: flex; width: 100%; justify-content: space-between; align-items: center; gap: 1em; padding: 0.9em 0; background: none; border: 0; font: inherit; font-weight: 600; color: inherit; cursor: pointer; text-align: left; }' .
		'.gogh-widget .wp-block-accordion-heading__icon::before { content: "+"; font-size: 1.25em; font-weight: 400; opacity: 0.55; line-height: 1; }' .
		'.gogh-widget .is-open .wp-block-accordion-heading__icon::before, .gogh-widget .wp-block-accordion-item.is-open .wp-block-accordion-heading__icon::before { content: "\2212"; }' .
		// core 6.9 markup: the icon is a literal + in __toggle-icon — rotating
		// it 45° reads as × when open, and the transition makes it turn
		'.gogh-widget .wp-block-accordion-heading__toggle-icon { font-size: 1.25em; font-weight: 400; opacity: 0.55; line-height: 1; transition: rotate 0.3s ease; }' .
		'.gogh-widget .wp-block-accordion-heading button[aria-expanded="true"] .wp-block-accordion-heading__toggle-icon { rotate: 45deg; }' .
		'.gogh-widget .wp-block-accordion-panel__content { padding: 0 0 1.1em; opacity: 0.85; }' .
		'.gogh-widget .wp-block-accordion-panel > p { padding: 0 0 1.1em; opacity: 0.85; }' .
		'.gogh-widget .wp-block-tab-list { display: flex; gap: 0.25em; border-bottom: 1px solid color-mix(in srgb, currentColor 16%, transparent); margin-bottom: 1.2em; }' .
		'.gogh-widget .wp-block-tab-list__tab, .gogh-widget .wp-block-tab-list > button { padding: 0.7em 1em; background: none; border: 0; border-bottom: 2px solid transparent; margin-bottom: -1px; font: inherit; font-weight: 600; color: inherit; opacity: 0.55; cursor: pointer; }' .
		'.gogh-widget .wp-block-tab-list__tab[aria-selected="true"], .gogh-widget .wp-block-tab-list > button[aria-selected="true"] { opacity: 1; border-bottom-color: currentColor; }' .
		'.gogh-widget .wp-block-tab-panel { padding-top: 0.2em; }' .
		// ---- smooth open/close (James: "kinda harsh and janky") ----
		// The accordion's closed panel wears hidden=until-found (still
		// display:block), so with interpolate-size the height can transition
		// 0 ↔ auto; content-visibility transitions discretely, staying visible
		// while the panel closes. Pure view-time CSS — nothing stored — and
		// browsers without support keep today's instant toggle.
		// (accordion/tab open motion is WAAPI in gogh-view below — CSS
		// transitions AND animations freeze inside the accordion's
		// content-visibility-skipped panel, and transitioning
		// content-visibility itself froze the tab. element.animate on the
		// just-revealed panel is immune to all of it.)
		// motion is a garnish, never a requirement
		'@media (prefers-reduced-motion: reduce) { .gogh-widget .wp-block-accordion-heading__toggle-icon { transition: none; } }';
}

/**
 * ✦ Splash presentation — the carousel, photo wall, break image, and glass
 * card are pure core blocks wearing gogh classes; THIS css is their whole
 * look. Shared verbatim between the front end and the block editor so a
 * splash never "breaks in the gutenberg view": same rules, both rooms.
 * (Interactivity — arrows, autoplay, lightbox, parallax — stays view-time
 * and front-end only; the editor just has to look right.)
 */
function gogh_splash_css() {
	return
		// CSS-only carousel: flex + scroll-snap does all the work — zero JS,
		// deactivation-safe. Chrome's CSS carousel spec (scroll markers)
		// lights the dots up as a free progressive enhancement.
		'.gogh-carousel { display: flex; flex-wrap: nowrap; gap: 14px; overflow-x: auto; scroll-snap-type: x mandatory; overscroll-behavior-x: contain; scrollbar-width: none; -webkit-overflow-scrolling: touch; }' .
		'.gogh-carousel::-webkit-scrollbar { display: none; }' .
		'.gogh-carousel > .wp-block-image.gogh-slide { flex: 0 0 min(72%, 460px); scroll-snap-align: center; margin: 0 !important; }' .
		'.gogh-carousel .gogh-slide img { width: 100%; aspect-ratio: 3 / 2; object-fit: cover; border-radius: 14px; display: block; }' .
		'.gogh-carousel .gogh-slide figcaption { text-align: center; font-size: 0.85em; opacity: 0.72; margin-top: 8px; }' .
		// the photo wall: CSS columns ARE the masonry — no measuring, no JS
		'.gogh-wall { columns: 3; gap: 14px; }' .
		'.gogh-wall-2 { columns: 2; } .gogh-wall-4 { columns: 4; }' .
		'@media (max-width: 700px) { .gogh-wall, .gogh-wall-4 { columns: 2; } }' .
		'.gogh-wall > .gogh-brick { break-inside: avoid; margin: 0 0 14px !important; display: block; }' .
		'.gogh-wall .gogh-brick img { width: 100%; height: auto; border-radius: 12px; display: block; }' .
		'.gogh-wall .gogh-brick figcaption { font-size: 0.85em; opacity: 0.72; margin-top: 6px; }' .
		// the chapter-break image: a fixed window over a cover-fit photo.
		// figure.wp-block-image.gogh-splash-break outguns the theme's
		// .wp-block-image.alignfull img { height: auto } — without it the
		// break renders at the photo's full natural height.
		// crop from the TOP, not the centre: faces live in the top of
		// photographs, and a centre-cropped portrait loses its head ("images
		// are cropping"). Tested 50% 25% first — an extreme portrait still
		// lost the head; top-anchoring never does. Landscape sources are
		// untouched either way (wide images crop their sides, not their top).
		'.gogh-splash-break { overflow: clip; margin-block: 0; }' .
		'.gogh-splash-break img, figure.wp-block-image.gogh-splash-break img { width: 100%; height: min(66vh, 640px); object-fit: cover; object-position: 50% 0%; display: block; }' .
		// the frosted call-out
		'.gogh-splash-glasswrap { min-height: min(70vh, 560px); display: flex; align-items: center; justify-content: center; padding: 6vh 6vw; }' .
		'.gogh-glass { max-width: 480px; padding: 2.2rem 2.4rem; border-radius: 24px; background: color-mix(in srgb, #ffffff 72%, transparent); -webkit-backdrop-filter: blur(18px) saturate(1.35); backdrop-filter: blur(18px) saturate(1.35); border: 1px solid color-mix(in srgb, #ffffff 55%, transparent); box-shadow: 0 30px 60px -22px rgba(0,0,0,0.45); text-align: center; }' .
		'.gogh-glass-kicker { font-size: 0.78rem; font-weight: 700; letter-spacing: 0.16em; text-transform: uppercase; opacity: 0.6; margin-bottom: 0.4rem; }';
}

// does this page carry a thing? singular pages answer from their own
// content; lists of posts cannot know, so they say yes and load it
function gogh_page_has( $needle ) {
	if ( ! is_singular() ) {
		return true;
	}
	$p = get_queried_object();
	return ! $p || ! isset( $p->post_content ) || false !== strpos( (string) $p->post_content, $needle );
}
// ---------- pictures published light ----------------------------------------
// gogh's pictures leave the editor as plain <img src> — a starter's photos,
// a card's picture — with no attachment id and no size, so WordPress could
// not give them srcset, sizes, lazy loading or a fetch priority: the 2560px
// original went to every phone (the speed pass: a photographer's home was
// 3MB, LCP 7.8s). This pass runs on the content just before core's own
// (priority 12): it finds the attachment behind each upload URL, adds the
// wp-image class and the intrinsic size, and core does the rest. A
// section's background photo gets a phone-sized variant under a media
// query, and the first section's is preloaded. Nothing to republish — it
// reaches every page ever published.
function gogh_media_id_for_url( $url ) {
	static $seen = array();
	$key = md5( $url );
	if ( isset( $seen[ $key ] ) ) {
		return $seen[ $key ];
	}
	$map = get_transient( 'gogh_img_ids' );
	if ( ! is_array( $map ) ) {
		$map = array();
	}
	if ( isset( $map[ $key ] ) ) {
		$seen[ $key ] = (int) $map[ $key ];
		return $seen[ $key ];
	}
	$base = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $url );
	$id   = attachment_url_to_postid( $base );
	if ( ! $id && $base !== $url ) {
		$id = attachment_url_to_postid( $url );
	}
	$map[ $key ] = (int) $id;
	if ( count( $map ) > 400 ) {
		$map = array_slice( $map, -300, null, true );
	}
	set_transient( 'gogh_img_ids', $map, DAY_IN_SECONDS );
	$seen[ $key ] = (int) $id;
	return (int) $id;
}
// this picture at a phone's width: an upload's 'large' size, or an Unsplash
// URL asked for at w=900; null when there is nothing smaller to offer
function gogh_phone_image_url( $src ) {
	if ( 0 === strpos( $src, 'https://images.unsplash.com/' ) ) {
		$w = preg_match( '/[?&]w=(\d+)/', $src, $wm ) ? (int) $wm[1] : 1800;
		return $w > 900 ? preg_replace( '/([?&])w=\d+/', '${1}w=900', $src ) : null;
	}
	$id = gogh_media_id_for_url( $src );
	if ( ! $id ) {
		return null;
	}
	$large = wp_get_attachment_image_src( $id, 'large' );
	if ( ! $large || empty( $large[0] ) || $large[0] === $src || (int) $large[1] >= 1400 ) {
		return null;
	}
	return $large[0];
}
function gogh_light_images( $html ) {
	if ( is_admin() || ! is_string( $html ) || '' === $html ) {
		return $html;
	}
	$up   = wp_get_upload_dir();
	$base = $up['baseurl'];
	if ( false !== strpos( $html, '<img' ) ) {
		$html = preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) use ( $base ) {
			$tag = $m[0];
			$has_id  = (bool) preg_match( '/\bwp-image-\d+/', $tag );
			$has_dim = preg_match( '/\swidth=/', $tag ) && preg_match( '/\sheight=/', $tag );
			if ( $has_id && $has_dim ) {
				return $tag;
			}
			if ( ! preg_match( '/\ssrc=["\']([^"\']+)["\']/', $tag, $sm ) || 0 !== strpos( $sm[1], $base ) ) {
				return $tag;
			}
			$src = $sm[1];
			$id  = preg_match( '/\bwp-image-(\d+)/', $tag, $im ) ? (int) $im[1] : gogh_media_id_for_url( $src );
			if ( ! $id ) {
				return $tag;
			}
			$meta = wp_get_attachment_metadata( $id );
			if ( ! $has_id ) {
				$tag = preg_match( '/\sclass=["\']/', $tag )
					? preg_replace( '/\sclass=(["\'])/', ' class=$1wp-image-' . $id . ' ', $tag, 1 )
					: preg_replace( '/^<img/i', '<img class="wp-image-' . $id . '"', $tag, 1 );
			}
			if ( ! $has_dim && is_array( $meta ) && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
				$w = (int) $meta['width'];
				$h = (int) $meta['height'];
				if ( preg_match( '/-(\d+)x(\d+)\.[a-z0-9]+$/i', $src, $dm ) ) {
					$w = (int) $dm[1];
					$h = (int) $dm[2];
				}
				$tag = preg_replace( '/\swidth=["\'][^"\']*["\']|\sheight=["\'][^"\']*["\']/', '', $tag );
				$tag = preg_replace( '/^<img/i', '<img width="' . $w . '" height="' . $h . '"', $tag, 1 );
			}
			return $tag;
		}, $html );
	}
	// the starters' photos come from Unsplash by URL, sized by a w= parameter:
	// the same URL at smaller widths is a srcset, so a phone asks for a
	// phone's worth (the InstaWP measure: a 640KB hero on a 412px screen)
	if ( false !== strpos( $html, 'images.unsplash.com' ) ) {
		$nth = 0;
		$html = preg_replace_callback( '/<img\b[^>]*\ssrc=["\']https:\/\/images\.unsplash\.com\/[^"\']+["\'][^>]*>/i', function ( $m ) use ( &$nth ) {
			$tag = $m[0];
			$nth++;
			if ( preg_match( '/\ssrcset=/', $tag ) ) {
				return $tag;
			}
			preg_match( '/\ssrc=["\']([^"\']+)["\']/', $tag, $sm );
			$src = html_entity_decode( $sm[1], ENT_QUOTES );
			$w   = preg_match( '/[?&]w=(\d+)/', $src, $wm ) ? (int) $wm[1] : 1800;
			$set = array();
			foreach ( array( 480, 768, 1024, 1400, 1800, 2400 ) as $cw ) {
				if ( $cw < $w ) {
					$set[] = esc_url( preg_replace( '/([?&])w=\d+/', '${1}w=' . $cw, $src ) ) . ' ' . $cw . 'w';
				}
			}
			$set[] = esc_url( $src ) . ' ' . $w . 'w';
			$attrs = ' srcset="' . implode( ', ', $set ) . '" sizes="(max-width: 700px) 100vw, min(100vw, ' . $w . 'px)"';
			// the first picture is likely the largest paint: fetch it first; the rest can wait
			if ( ! preg_match( '/\sloading=|\sfetchpriority=/', $tag ) ) {
				$attrs .= 1 === $nth ? ' fetchpriority="high"' : ' loading="lazy"';
			}
			return preg_replace( '/^<img/i', '<img' . $attrs, $tag, 1 );
		}, $html );
	}
	// a section's background photo: the same picture at 'large' on phones
	if ( false !== strpos( $html, 'gogh-style' ) && false !== strpos( $html, 'url(' ) ) {
		$html = preg_replace_callback( '/<style class="gogh-style">(.*?)<\/style>/s', function ( $m ) use ( $base ) {
			$css   = $m[1];
			$extra = '';
			if ( preg_match_all( '/([^{}]+)\{([^{}]*url\(["\']?((?:' . preg_quote( $base, '/' ) . '|https:\/\/images\.unsplash\.com\/)[^"\')]+)["\']?\)[^{}]*)\}/', $css, $rules, PREG_SET_ORDER ) ) {
				foreach ( $rules as $r ) {
					$sel = trim( $r[1] ); // the section's rule, or its tint layer's ::before: both carry the url
					if ( '' === $sel || '@' === $sel[0] ) {
						continue;
					}
					$src   = $r[3];
					$phone = gogh_phone_image_url( $src );
					if ( ! $phone ) {
						continue;
					}
					$extra .= '@media (max-width: 700px) { ' . $sel . ' { ' . str_replace( $src, $phone, $r[2] ) . ' } }';
				}
			}
			return $extra ? '<style class="gogh-style">' . $css . $extra . '</style>' : $m[0];
		}, $html );
	}
	return $html;
}
add_filter( 'the_content', 'gogh_light_images', 11 );

// the first picture on the page is the largest paint on most gogh homes,
// and a background is only found after the page's CSS is parsed: say so up
// front, the phone size for phones and the full size for the rest
add_action( 'wp_head', function () {
	if ( ! is_singular() ) {
		return;
	}
	$p = get_queried_object();
	if ( ! $p || empty( $p->post_content ) || false === strpos( $p->post_content, 'gogh-' ) ) {
		return;
	}
	$c     = $p->post_content;
	$up    = wp_get_upload_dir();
	$hosts = '(?:' . preg_quote( $up['baseurl'], '/' ) . '|https:\/\/images\.unsplash\.com\/)';
	$bg    = preg_match( '/<style class="gogh-style">.*?url\(["\']?(' . $hosts . '[^"\')]+)["\']?\)/s', $c, $bm, PREG_OFFSET_CAPTURE ) ? $bm : null;
	$img   = preg_match( '/<img\b[^>]*\ssrc=["\'](' . $hosts . '[^"\']+)["\']/', $c, $im, PREG_OFFSET_CAPTURE ) ? $im : null;
	if ( ! $bg && ! $img ) {
		return;
	}
	$first = ( $bg && ( ! $img || $bg[0][1] < $img[0][1] ) ) ? $bg : $img;
	$src   = html_entity_decode( $first[1][0], ENT_QUOTES );
	// an Unsplash picture tag carries a srcset (added as the content is
	// served): the preload must offer the SAME candidates, or the browser
	// fetches the preload and then the picture's own pick — twice the hero
	if ( $first === $img && 0 === strpos( $src, 'https://images.unsplash.com/' ) ) {
		$w   = preg_match( '/[?&]w=(\d+)/', $src, $wm ) ? (int) $wm[1] : 1800;
		$set = array();
		foreach ( array( 480, 768, 1024, 1400, 1800, 2400 ) as $cw ) {
			if ( $cw < $w ) {
				$set[] = esc_url( preg_replace( '/([?&])w=\d+/', '${1}w=' . $cw, $src ) ) . ' ' . $cw . 'w';
			}
		}
		$set[] = esc_url( $src ) . ' ' . $w . 'w';
		$share = gogh_piece_share( $c, $img[0][1] );
		$sizes = null !== $share ? '(max-width: 700px) 100vw, ' . $share . 'vw' : '(max-width: 700px) 100vw, min(100vw, ' . $w . 'px)';
		echo '<link rel="preload" as="image" imagesrcset="' . implode( ', ', $set ) . '" imagesizes="' . $sizes . '" fetchpriority="high">' . "\n";
		return;
	}
	$phone = gogh_phone_image_url( $src );
	if ( $phone ) {
		echo '<link rel="preload" as="image" href="' . esc_url( $phone ) . '" media="(max-width: 700px)" fetchpriority="high">' . "\n";
		echo '<link rel="preload" as="image" href="' . esc_url( $src ) . '" media="(min-width: 701px)" fetchpriority="high">' . "\n";
	} else {
		echo '<link rel="preload" as="image" href="' . esc_url( $src ) . '" fetchpriority="high">' . "\n";
	}
}, 2 );

// ---------- an honest sizes attribute ---------------------------------------
// WordPress guesses every picture is as wide as the screen, so a phone asks
// for the biggest candidate. gogh knows better: a section is a grid whose
// columns are shares of its width (cqw), and each piece names the columns
// it spans. Read those back from the stored CSS and tell the browser the
// picture's real share, so it picks the candidate that fits the box
// (PageSpeed on the hosted photographer: a 1400px copy for a 708px box).
// the share of the section's width a piece takes, in whole vw, read from the
// stored CSS: the section's grid columns (cqw) and the piece's grid-area.
// $at is the offset of the piece's <img> in $html; null when unknowable.
function gogh_piece_share( $html, $at ) {
	$before = substr( $html, 0, $at );
	$fpos   = strrpos( $before, '<figure class="' );
	if ( false === $fpos || ! preg_match( '/^<figure class="[^"]*\bgogh-el-(\d+)\b/', substr( $html, $fpos, 200 ), $fm ) ) {
		return null;
	}
	$el  = (int) $fm[1];
	$pos = strrpos( $before, 'data-gogh-scope="' );
	if ( false === $pos || ! preg_match( '/^data-gogh-scope="(gogh-sec-[a-z0-9]+)"/', substr( $html, $pos, 60 ), $sm ) ) {
		return null;
	}
	$scope = $sm[1];
	if ( ! preg_match( '/\.' . preg_quote( $scope, '/' ) . '\s*\{[^}]*grid-template-columns:\s*([^;]+);/', $html, $cm ) ) {
		return null;
	}
	$cols = array();
	foreach ( preg_split( '/\s+/', trim( $cm[1] ) ) as $tok ) {
		$cols[] = preg_match( '/^([\d.]+)cqw$/', $tok, $tm ) ? (float) $tm[1] : null;
	}
	if ( ! preg_match( '/\.' . preg_quote( $scope, '/' ) . ' \.gogh-el-' . $el . '\s*\{[^}]*grid-area:\s*(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)/', $html, $gm ) ) {
		return null;
	}
	$w = 0.0;
	for ( $c = (int) $gm[2]; $c < (int) $gm[4]; $c++ ) {
		if ( ! isset( $cols[ $c - 1 ] ) || null === $cols[ $c - 1 ] ) {
			return null;
		}
		$w += $cols[ $c - 1 ];
	}
	return ( $w < 5 || $w > 100 ) ? null : (int) round( $w );
}
function gogh_honest_sizes( $html ) {
	if ( is_admin() || ! is_string( $html ) || false === strpos( $html, 'gogh-section' ) || false === strpos( $html, 'srcset=' ) ) {
		return $html;
	}
	if ( ! preg_match_all( '/<figure class="[^"]*\bgogh-el-\d+\b[^"]*">\s*(<img\b[^>]*\ssrcset=[^>]*>)/i', $html, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
		return $html;
	}
	for ( $k = count( $ms ) - 1; $k >= 0; $k-- ) { // from the end, so earlier offsets stay true
		$img = $ms[ $k ][1][0];
		$at  = $ms[ $k ][1][1];
		$w   = gogh_piece_share( $html, $at );
		if ( null === $w ) {
			continue;
		}
		// a lazy picture may keep 'auto': the browser then measures the box itself
		$lead  = preg_match( '/\sloading=["\']lazy["\']/', $img ) ? 'auto, ' : '';
		$sizes = ' sizes="' . $lead . '(max-width: 700px) 100vw, ' . $w . 'vw"';
		$new   = preg_match( '/\ssizes=["\'][^"\']*["\']/', $img ) ? preg_replace( '/\ssizes=["\'][^"\']*["\']/', $sizes, $img, 1 ) : preg_replace( '/^<img/i', '<img' . $sizes, $img, 1 );
		$html  = substr_replace( $html, $new, $at, strlen( $img ) );
	}
	return $html;
}
add_filter( 'the_content', 'gogh_honest_sizes', 13 ); // after core has written its own guess

// ---------- a description for every page ------------------------------------
// gogh pages carry no meta description unless an SEO plugin writes one, and
// PageSpeed marks the absence. The page can describe itself: its excerpt if
// someone wrote one, else its first paragraph, else the site's tagline.
function gogh_page_description( $post ) {
	$d = is_object( $post ) && ! empty( $post->post_excerpt ) ? $post->post_excerpt : '';
	if ( '' === $d && is_object( $post ) && ! empty( $post->post_content ) ) {
		// the first paragraph that reads as a sentence — an eyebrow line
		// ('People · Places · Quiet moments') describes nothing; the intro under it does
		$paras = array();
		$walk  = function ( $els ) use ( &$walk, &$paras ) {
			foreach ( (array) $els as $e ) {
				if ( ( $e['type'] ?? '' ) === 'para' && ! empty( $e['text'] ) ) {
					$paras[] = trim( wp_strip_all_tags( (string) $e['text'] ) );
				}
				if ( ! empty( $e['kids'] ) && is_array( $e['kids'] ) ) {
					$walk( $e['kids'] );
				}
			}
		};
		foreach ( parse_blocks( gogh_html_unpark_content( $post->post_content ) ) as $b ) {
			if ( 'gogh/section' === ( $b['blockName'] ?? '' ) && ! empty( $b['attrs']['model']['elements'] ) ) {
				$walk( $b['attrs']['model']['elements'] );
			}
		}
		foreach ( $paras as $t ) {
			if ( mb_strlen( $t ) >= 40 && preg_match( '/[a-z]{3,}\s+[a-z]{2,}/i', $t ) ) {
				$d = $t;
				break;
			}
		}
		if ( '' === $d && $paras ) {
			$d = $paras[0];
		}
	}
	if ( '' === $d ) {
		$d = get_bloginfo( 'description' );
	}
	$d = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( html_entity_decode( (string) $d, ENT_QUOTES ) ) ) );
	if ( mb_strlen( $d ) > 158 ) {
		$cut = mb_substr( $d, 0, 155 );
		$sp  = mb_strrpos( $cut, ' ' );
		$d   = ( $sp > 80 ? mb_substr( $cut, 0, $sp ) : $cut ) . '…';
	}
	return $d;
}
add_action( 'wp_head', function () {
	if ( ! is_singular() && ! is_front_page() ) {
		return;
	}
	// an SEO plugin owns this tag when one is present
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\Load' ) || function_exists( 'slim_seo' ) || defined( 'SMARTCRAWL_VERSION' ) || ( class_exists( 'Jetpack' ) && method_exists( 'Jetpack', 'is_module_active' ) && Jetpack::is_module_active( 'seo-tools' ) ) ) {
		return;
	}
	$p = get_queried_object();
	$d = gogh_page_description( $p );
	if ( '' === $d ) {
		return;
	}
	echo '<meta name="description" content="' . esc_attr( $d ) . '">' . "\n";
	// pictures from Unsplash: open the connection before the browser finds the first one
	if ( $p && ! empty( $p->post_content ) && false !== strpos( $p->post_content, 'images.unsplash.com' ) ) {
		echo '<link rel="preconnect" href="https://images.unsplash.com">' . "\n";
	}
}, 1 );

// ✦ looks and motion serve EVERY visitor on every page — no gate. A post
// wearing Magazine must read as Magazine logged-out, and the site's gait
// is site-wide; both packs are a few KB of pure CSS.
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'gogh-looks', false, array(), '0.99.650-chrome' );
	wp_enqueue_style( 'gogh-looks' );
	// the reading looks dress single posts; the blog looks dress lists of
	// posts (the posts page, archives, a page carrying a posts rail); motion
	// is site-wide. Each pack loads only where it can apply (the speed pass:
	// 30KB of look CSS rode on every page, a text page paid for it all)
	$reading = is_singular( 'post' ) || ( is_singular() && isset( $_GET['gogh-look'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation-only preview
	$lists   = is_home() || is_archive() || is_search() || ( is_singular() && has_block( 'core/query' ) );
	wp_add_inline_style( 'gogh-looks', ( $reading ? gogh_reading_style_css() : '' ) . gogh_motion_css() . ( $lists ? gogh_blog_style_css() : '' ) );

	// the Blog style chooser pill retired (James: 'remove the pill for the
	// posts page - lets have consistency') — the admin bar's Blog layout
	// menu is the one door, like Product layout and Post layout
} );

/**
 * Front-end editor: enqueue for users who can edit the current page.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! is_singular() ) {
		return;
	}
	$post      = get_post();
	if ( ! $post ) {
		return;
	}
	$has_gogh  = false !== strpos( $post->post_content, 'gogh-section' );
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view toggle; editor assets are capability-gated below.
	$want_edit = isset( $_GET['gogh-edit'] );
	$can_edit  = current_user_can( 'edit_post', $post->ID );
	// products: the editor belongs on gogh's own layouts only — on Woo's
	// classic template the description hides in tabs and the canvas would
	// fight the buy box (the admin bar's layout menu is the door)
	if ( 'product' === $post->post_type &&
		! in_array( get_page_template_slug( $post ), array( 'gogh-product-story', 'gogh-product-showcase', 'gogh-product-hero' ), true ) ) {
		return;
	}
	// visitors only need assets on gogh pages; EDITORS get the editor on
	// every singular page — gating on 'gogh-section' in the content is why
	// the floating edit pill never appeared on untouched or empty pages
	if ( ! $has_gogh && ! $want_edit && ! $can_edit ) {
		return;
	}

	// for every visitor: neutralise theme spacing around gogh sections, even
	// on pages whose stored stylesheets predate this rule
	wp_register_style( 'gogh-base', false, array(), '0.99.650-chrome' );
	// (the splash presentation itself lives in gogh_splash_css(), shared with
	// the block editor — a wall in Gutenberg must look like a wall)
	wp_register_script( 'gogh-view', false, array(), '0.99.650-chrome', true );
	wp_enqueue_script( 'gogh-view' );
	wp_add_inline_script( 'gogh-view',
		// mega menu panels: hover opens with intent on fine pointers; the chevron
		// opens for keyboards and touch; Escape and a click away close; one at a
		// time; in the phone overlay the same class folds the link list instead
		'(function(){var html=document.documentElement;if(html.classList.contains("gogh-editing"))return;' .
		'var items=[].slice.call(document.querySelectorAll(".wp-block-navigation-item.gogh-has-panel"));if(!items.length)return;' .
		'var fine=window.matchMedia&&window.matchMedia("(hover: hover) and (pointer: fine)").matches;var openLi=null;' .
		'function inOverlay(li){return !!li.closest(".wp-block-navigation__responsive-container.is-menu-open");}' .
		'function place(li,panel){var hdr=li.closest("header, .wp-block-template-part")||li.closest(".wp-block-navigation");var hr=hdr.getBoundingClientRect(),lr=li.getBoundingClientRect();panel.style.left=(hr.left-lr.left)+"px";panel.style.width=hr.width+"px";panel.style.top=(hr.bottom-lr.top)+"px";}' .
		'function setOpen(li,on){var panel=li.querySelector(":scope > .gogh-mega");var btn=li.querySelector(":scope > .gogh-mega-toggle");li.classList.toggle("is-open",on);if(btn)btn.setAttribute("aria-expanded",on?"true":"false");' .
		'if(panel&&!inOverlay(li)){if(on){place(li,panel);panel.hidden=false;}else{panel.hidden=true;}}' .
		'if(on){if(openLi&&openLi!==li)setOpen(openLi,false);openLi=li;}else if(openLi===li)openLi=null;}' .
		'items.forEach(function(li){var btn=li.querySelector(":scope > .gogh-mega-toggle");var t=null;' .
		'if(btn)btn.addEventListener("click",function(ev){ev.preventDefault();ev.stopPropagation();setOpen(li,!li.classList.contains("is-open"));});' .
		'if(fine){li.addEventListener("mouseenter",function(){if(inOverlay(li))return;clearTimeout(t);t=setTimeout(function(){setOpen(li,true);},120);});' .
		'li.addEventListener("mouseleave",function(){if(inOverlay(li))return;clearTimeout(t);t=setTimeout(function(){setOpen(li,false);},220);});}' .
		'li.addEventListener("keydown",function(ev){if(ev.key==="Escape"&&li.classList.contains("is-open")){setOpen(li,false);if(btn)btn.focus();}});});' .
		'document.addEventListener("click",function(ev){if(openLi&&!openLi.contains(ev.target))setOpen(openLi,false);});' .
		'document.addEventListener("keydown",function(ev){if(ev.key==="Escape"&&openLi)setOpen(openLi,false);});' .
		'window.addEventListener("resize",function(){if(openLi)setOpen(openLi,false);},{passive:true});})();'
	);
	// (the Manual look dresses posts only; the suite's fixture is a page, so
	// the test run carries it too)
	if ( is_singular( 'post' ) || isset( $_GET['gogh-test'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- test flag
		wp_add_inline_script( 'gogh-view',
			// the Manual look's contents: built from the post's own h2/h3, ids
			// minted where missing, the current section marked as you read.
			// Exposed as window.goghManualToc(root) so the suite can drive it.
			'(function(){function slug(t){return (t||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60)||"section";}' .
			'window.goghManualToc=function(root){if(!root)return null;var heads=[].slice.call(root.querySelectorAll(":scope > h2, :scope > h3, :scope > .wp-block-group h2, :scope > .wp-block-group h3")).filter(function(h){return (h.textContent||"").trim();});' .
			'if(heads.length<2)return null;var old=root.querySelector(":scope > .gogh-toc");if(old)old.remove();var seen={};' .
			'heads.forEach(function(h){if(!h.id){var b=slug(h.textContent),id=b,n=2;while(seen[id]||document.getElementById(id)){id=b+"-"+(n++);}h.id=id;}seen[h.id]=1;});' .
			'var nav=document.createElement("nav");nav.className="gogh-toc";nav.setAttribute("aria-label","On this page");' .
			'nav.innerHTML="<span class=\"gogh-toc-title\">On this page</span>";var ol=document.createElement("ol");' .
			'var calm=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;' .
			'heads.forEach(function(h){var li=document.createElement("li");li.className="gogh-toc-"+h.tagName.toLowerCase();var a=document.createElement("a");a.href="#"+h.id;a.textContent=h.textContent.trim();' .
			'a.addEventListener("click",function(ev){ev.preventDefault();h.scrollIntoView({block:"start",behavior:calm?"auto":"smooth"});try{history.replaceState(null,"","#"+h.id);}catch(e){}});li.appendChild(a);ol.appendChild(li);});' .
			'nav.appendChild(ol);root.insertBefore(nav,root.firstChild);root.classList.add("gogh-has-toc");' .
			'var place=function(){var first=[].slice.call(root.children).filter(function(c){return c!==nav;})[0];var left=first?first.getBoundingClientRect().left-252:0;' .
			'if(left>=72){nav.classList.add("gogh-toc-side");nav.classList.remove("gogh-toc-boxed");nav.style.left=Math.round(left)+"px";}else{nav.classList.remove("gogh-toc-side");nav.classList.add("gogh-toc-boxed");nav.style.left="";}};' .
			'place();window.addEventListener("resize",place,{passive:true});' .
			'if(window.IntersectionObserver){var links={};[].slice.call(ol.querySelectorAll("a")).forEach(function(a){links[a.getAttribute("href").slice(1)]=a;});var here=null;' .
			'var mark=function(id){if(here)here.classList.remove("is-here");here=links[id]||null;if(here)here.classList.add("is-here");};' .
			'var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)mark(e.target.id);});},{rootMargin:"-10% 0px -70% 0px",threshold:0});heads.forEach(function(h){io.observe(h);});mark(heads[0].id);}' .
			'return nav;};' .
			'var html=document.documentElement;if(html.classList.contains("gogh-editing"))return;' .
			// the writing room: the same contents, read-only and OUTSIDE the content
			// (no ids minted, nothing for the serializer to meet), placed beside
			// the column and rebuilt as the words change or the look auditions
			'if(document.body.classList.contains("gogh-writing")){var room=null,timer=null;' .
			'var build=function(){var root=document.querySelector(".entry-content, .wp-block-post-content");if(room){room.remove();room=null;}' .
			'if(!root||!document.body.classList.contains("gogh-read-manual"))return;' .
			'var heads=[].slice.call(root.querySelectorAll("h2, h3")).filter(function(h){return (h.textContent||"").trim();});if(heads.length<2)return;' .
			'var first=root.querySelector("p, h2, h3, ul, ol, figure");var colLeft=(first||root).getBoundingClientRect().left;var left=colLeft-252;' .
			'var panel=document.querySelector(".gogh-w-stylepop");if(panel&&!panel.hidden){var pr=panel.getBoundingClientRect();if(pr.right>left-16)left=pr.right+24;}' .
			'if(left<72||left+220>colLeft-16)return;' .
			'room=document.createElement("nav");room.className="gogh-toc gogh-toc-room";room.setAttribute("aria-hidden","true");room.contentEditable="false";room.style.left=Math.round(left)+"px";' .
			'room.innerHTML="<span class=\"gogh-toc-title\">On this page</span>";var ol=document.createElement("ol");' .
			'heads.forEach(function(h){var li=document.createElement("li");li.className="gogh-toc-"+h.tagName.toLowerCase();var a=document.createElement("a");a.textContent=h.textContent.trim();' .
			'a.addEventListener("mousedown",function(ev){ev.preventDefault();h.scrollIntoView({block:"start",behavior:(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches)?"auto":"smooth"});});li.appendChild(a);ol.appendChild(li);});' .
			'room.appendChild(ol);document.body.appendChild(room);};' .
			'var later=function(){clearTimeout(timer);timer=setTimeout(build,350);};' .
			'new MutationObserver(later).observe(document.body,{attributes:true,attributeFilter:["class"]});' .
			'document.addEventListener("input",later,true);window.addEventListener("resize",later,{passive:true});' .
			'document.addEventListener("gogh:ready",later);setTimeout(build,600);return;}' .
			'if(!document.body.classList.contains("gogh-read-manual"))return;' .
			'window.goghManualToc(document.querySelector(".entry-content, .wp-block-post-content"));})();'
		);
	}
	if ( gogh_page_has( 'gogh-bgvideo' ) ) {
		wp_add_inline_script( 'gogh-view',
			// video backgrounds: a pause control per section (moving content that
			// starts on its own must be stoppable), and no autoplay at all for
			// people who asked their system for less motion
			'(function(){var rm=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;' .
			'document.querySelectorAll(".gogh-section > .gogh-bgvideo video").forEach(function(v){' .
			'var sec=v.closest(".gogh-section");if(!sec)return;' .
			'if(rm){v.removeAttribute("autoplay");try{v.pause();}catch(e){}return;}' .
			'var b=document.createElement("button");b.type="button";b.className="gogh-bgvideo-btn";' .
			'var paint=function(){var on=!v.paused;b.setAttribute("aria-label",on?"Pause background video":"Play background video");' .
			'b.innerHTML=on?\'<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>\'' .
			':\'<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5l11 7-11 7z"/></svg>\';};' .
			'b.addEventListener("click",function(){if(v.paused){var p=v.play();if(p&&p.catch)p.catch(function(){});}else{v.pause();}paint();});' .
			'v.addEventListener("play",paint);v.addEventListener("pause",paint);paint();sec.appendChild(b);' .
			'var p0=v.play&&v.play();if(p0&&p0.catch)p0.catch(function(){paint();});});})();'
		);
	}
	// the stored markup says gogh-carousel / gogh-wall / gogh-brick; the crsl
	// and lbx classes are view-time and never saved, so they are not gates
	if ( gogh_page_has( 'gogh-carousel' ) || gogh_page_has( 'gogh-wall' ) || gogh_page_has( 'gogh-brick' ) || gogh_page_has( 'gogh-crsl' ) ) {
		wp_add_inline_script( 'gogh-view',
			// carousel arrows + autoplay are VIEW-TIME: never stored, so saved
			// content stays pure core blocks (plugin off = clean snap strip)
			'(function(){var bindLightbox=function(container,slides){' .
			'var lbAt=-1;var lb=null;' .
			'var lbShow=function(k){lbAt=(k+slides.length)%slides.length;var im=slides[lbAt].querySelector("img");var cp=slides[lbAt].querySelector("figcaption");' .
			'lb.querySelector("img").src=im?im.src:"";lb.querySelector("figcaption").textContent=cp?cp.textContent:"";};' .
			'var lbKeys;var lbClose=function(){if(lb){lb.remove();lb=null;document.removeEventListener("keydown",lbKeys);}};' .
			'lbKeys=function(ev){if(ev.key==="Escape")lbClose();if(ev.key==="ArrowRight")lbShow(lbAt+1);if(ev.key==="ArrowLeft")lbShow(lbAt-1);};' .
			'var lbOpen=function(k){lb=document.createElement("div");lb.className="gogh-lbx";lb.setAttribute("role","dialog");lb.setAttribute("aria-label","Image viewer");' .
			'lb.innerHTML=\'<img alt=""/><figcaption></figcaption>\'+' .
			'\'<button type="button" class="gogh-crsl-btn gogh-lbx-l" aria-label="Previous">\u2039</button>\'+' .
			'\'<button type="button" class="gogh-crsl-btn gogh-lbx-r" aria-label="Next">\u203a</button>\'+' .
			'\'<button type="button" class="gogh-crsl-btn gogh-lbx-x" aria-label="Close">\u2715</button>\';' .
			'lb.addEventListener("click",function(ev){if(ev.target===lb)lbClose();});' .
			'lb.querySelector(".gogh-lbx-l").addEventListener("click",function(){lbShow(lbAt-1);});' .
			'lb.querySelector(".gogh-lbx-r").addEventListener("click",function(){lbShow(lbAt+1);});' .
			'lb.querySelector(".gogh-lbx-x").addEventListener("click",lbClose);' .
			'document.addEventListener("keydown",lbKeys);document.body.appendChild(lb);lbShow(k);};' .
			'slides.forEach(function(sl,k){var im=sl.querySelector("img");if(!im)return;im.style.cursor="zoom-in";' .
			'im.addEventListener("click",function(){lbOpen(k);});});};' .
			'function init(){' .
			'document.querySelectorAll(".gogh-wall.gogh-crsl-light").forEach(function(wall){' .
			'if(wall.__gogh)return;wall.__gogh=1;' .
			'bindLightbox(wall,[].slice.call(wall.querySelectorAll(".gogh-brick")));});' .
			'document.querySelectorAll(".gogh-carousel").forEach(function(strip){' .
			'if(strip.__gogh)return;strip.__gogh=1;' .
			'var slides=[].slice.call(strip.querySelectorAll(".gogh-slide"));if(slides.length<2)return;' .
			'var shell=strip.parentElement;' .
			'if(!shell||!shell.classList.contains("gogh-crsl-shell")){shell=document.createElement("div");shell.className="gogh-crsl-shell";' .
			// the shell must WEAR the strip's alignment or constrained layout
			// squeezes a wide carousel back into the text column
			'["alignwide","alignfull"].forEach(function(a){if(strip.classList.contains(a))shell.classList.add(a);});' .
			'strip.parentNode.insertBefore(shell,strip);shell.appendChild(strip);}' .
			'if(shell.querySelector(".gogh-crsl-nav"))return;' .
			'var nav=document.createElement("div");nav.className="gogh-crsl-nav";' .
			'var go=function(k){var s0=slides[Math.max(0,Math.min(slides.length-1,k))];if(s0)strip.scrollTo({left:s0.offsetLeft-strip.offsetLeft-(strip.clientWidth-s0.clientWidth)/2,behavior:"smooth"});};' .
			'var current=function(){var mid=strip.scrollLeft+strip.clientWidth/2,best=0,bd=1e9;slides.forEach(function(sl,k){var c=sl.offsetLeft-strip.offsetLeft+sl.clientWidth/2,d=Math.abs(c-mid);if(d<bd){bd=d;best=k;}});return best;};' .
			'var prev=document.createElement("button");prev.type="button";prev.className="gogh-crsl-btn";prev.setAttribute("aria-label","Previous slide");prev.textContent="\u2039";' .
			'prev.addEventListener("click",function(){var c=current();go(c<=0?slides.length-1:c-1);});nav.appendChild(prev);' .
			'var dots=document.createElement("div");dots.className="gogh-crsl-dots";' .
			'slides.forEach(function(sl,k){var d=document.createElement("button");d.type="button";d.className="gogh-crsl-dot"+(k===0?" is-here":"");d.setAttribute("aria-label","Slide "+(k+1));' .
			'd.addEventListener("click",function(){go(k);});dots.appendChild(d);});nav.appendChild(dots);' .
			'var next=document.createElement("button");next.type="button";next.className="gogh-crsl-btn";next.setAttribute("aria-label","Next slide");next.textContent="\u203a";' .
			'next.addEventListener("click",function(){var c=current();go(c>=slides.length-1?0:c+1);});nav.appendChild(next);' .
			'shell.appendChild(nav);' .
			'var navMode=strip.classList.contains("gogh-crsl-nav-sides")?"sides":strip.classList.contains("gogh-crsl-nav-both")?"both":"below";' .
			'if(navMode!=="below"){["l","r"].forEach(function(sd){var b=document.createElement("button");b.type="button";' .
			'b.className="gogh-crsl-btn gogh-crsl-side gogh-crsl-side-"+sd;b.setAttribute("aria-label",sd==="l"?"Previous slide":"Next slide");' .
			'b.textContent=sd==="l"?"\u2039":"\u203a";' .
			'b.addEventListener("click",function(){var c=current();go(sd==="l"?(c<=0?slides.length-1:c-1):(c>=slides.length-1?0:c+1));});' .
			'shell.insertBefore(b,strip);' .
			'var fit=function(){b.style.top=(strip.offsetTop+strip.clientHeight/2)+"px";b.style.transform="translateY(-50%)";};fit();' .
			'if(window.ResizeObserver)new ResizeObserver(fit).observe(strip);});' .
			'if(navMode==="sides")nav.querySelectorAll(".gogh-crsl-btn").forEach(function(b2){b2.remove();});}' .
			'if(strip.classList.contains("gogh-crsl-light"))bindLightbox(strip,slides);' .
			'var syncT=null;strip.addEventListener("scroll",function(){if(syncT)return;syncT=requestAnimationFrame(function(){syncT=null;var c=current();' .
			'[].forEach.call(dots.children,function(d,k){d.classList.toggle("is-here",k===c);});});},{passive:true});' .
			'if(strip.classList.contains("gogh-crsl-auto")&&!matchMedia("(prefers-reduced-motion: reduce)").matches){' .
			'var hold=0;["pointerenter","pointerdown","focusin"].forEach(function(t){shell.addEventListener(t,function(){hold=Date.now();});});' .
			'shell.addEventListener("pointerleave",function(){hold=0;});' .
			'setInterval(function(){if(document.hidden||(hold&&Date.now()-hold<6000))return;' .
			'var c=current();go(c>=slides.length-1?0:c+1);},4200);}' .
			'});}' .
			// exposed so the write room can wake splashes it inserts or rebuilds
			// — auditioning a carousel should not require publishing first
			'window.__goghViewInit=init;' .
			// smooth accordion + tab reveals ("kinda harsh and janky"). WAAPI on
			// the just-revealed panel, AFTER core's toggle flips the hidden attr —
			// CSS transitions and animations both freeze inside the accordion's
			// content-visibility-skipped panel, but element.animate on a visible
			// element is immune. Open animates (height sweep for the accordion, a
			// fade-rise for tabs); close stays instant, which reads as snappy.
			'if(!matchMedia("(prefers-reduced-motion: reduce)").matches){' .
			'var ease="cubic-bezier(0.4, 0, 0.2, 1)";' .
			// bubble phase, so core has already flipped hidden; queueMicrotask (not
			// rAF — paused in hidden tabs, and the flip is synchronous anyway)
			'document.addEventListener("click",function(ev){' .
			'var accBtn=ev.target.closest&&ev.target.closest(".wp-block-accordion-heading button");' .
			'if(accBtn){queueMicrotask(function(){' .
			'var item=accBtn.closest(".wp-block-accordion-item");' .
			'var p=item&&item.querySelector(".wp-block-accordion-panel");' .
			'if(!p||p.hidden||!p.animate)return;' .
			'var h=p.getBoundingClientRect().height;if(!h)return;' .
			'p.style.overflow="clip";' .
			'var a=p.animate([{height:"0px",opacity:0.35},{height:h+"px",opacity:1}],{duration:300,easing:ease});' .
			'a.onfinish=a.oncancel=function(){p.style.overflow="";};' .
			'});return;}' .
			'var tabBtn=ev.target.closest&&ev.target.closest(".wp-block-tab-list button, .wp-block-tab-list [role=\'tab\']");' .
			'if(tabBtn){queueMicrotask(function(){' .
			'var tabs=tabBtn.closest(".wp-block-tabs");' .
			'var p2=tabs&&tabs.querySelector(".wp-block-tab-panel:not([hidden])");' .
			'if(p2&&p2.animate)p2.animate([{opacity:0,translate:"0 8px"},{opacity:1,translate:"0 0"}],{duration:260,easing:ease});' .
			'});}' .
			'},false);}' .
			'if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();})();'
		);
	}
	wp_enqueue_style( 'gogh-base' );
	// (reading looks + motion moved to the ungated 'gogh-looks' style — the
	// gogh-base gate was hiding them from logged-out readers on splash-less
	// posts: a post wearing Magazine read as the theme default to visitors)
	wp_add_inline_style( 'gogh-base',
		// full-bleed sections use 100vw, which includes the scrollbar — once
		// a vertical scrollbar exists they overflow sideways and the canvas
		// wobbles left-right. Clip horizontal overflow at the root (clip, not
		// hidden: no new scroll container, inner scrollers unaffected).
		'html { overflow-x: clip; }' .
		// the theme's root block-gap leaves a pale strip between the header,
		// the content, and the footer ("this weird gap above the header and
		// content") — gogh's painted bands should TOUCH. Zero the template-
		// level margins only; in-content block gaps stay the theme's business.
		'.wp-site-blocks > header, .wp-site-blocks > main, .wp-site-blocks > footer, .wp-site-blocks > .wp-block-template-part { margin-block: 0 !important; }' .
		'.gogh-wrap { margin-block: 0 !important; min-width: 100%; }' .
		'.entry-content:has(> .gogh-wrap) { margin-block: 0 !important; }' .
		// pages saved before this rule shipped: image placeholders must not
		// inherit theme Group padding
		'.gogh-section > .wp-block-group { padding: 0 !important; box-sizing: border-box; }' .
		'.gogh-section > * { box-sizing: border-box; }' .
		// video backgrounds: the loop sits under everything; its poster (the
		// section image) shows until it plays, and whenever motion is off
		'.gogh-section > .gogh-bgvideo { position: absolute; inset: 0; z-index: -1; margin: 0 !important; padding: 0 !important; pointer-events: none; overflow: hidden; }' .
		'.gogh-section > .gogh-bgvideo video { width: 100%; height: 100%; object-fit: cover; display: block; }' .
		'.gogh-bgvideo-btn { position: absolute; right: 14px; bottom: 14px; z-index: 60; width: 36px; height: 36px; border-radius: 50%; border: 0; padding: 0; cursor: pointer; background: rgba(15,23,42,0.55); color: #fff; display: grid; place-items: center; opacity: 0.72; transition: opacity 0.2s; }' .
		'.gogh-bgvideo-btn:hover, .gogh-bgvideo-btn:focus-visible { opacity: 1; }' .
		'.gogh-bgvideo-btn svg { width: 14px; height: 14px; display: block; }' .
		'@media (prefers-reduced-motion: reduce) { .gogh-section > .gogh-bgvideo, .gogh-bgvideo-btn { display: none; } }' .
		// the video element: the frame is the design's, the player fills it
		'.gogh-section > .gogh-vid { overflow: hidden; overflow: clip; }' .
		'.gogh-section > .gogh-vid video, .gogh-section > .gogh-vid iframe { width: 100%; height: 100%; object-fit: cover; display: block; border: 0; border-radius: inherit; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper { position: relative; height: 100%; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper::before { content: none !important; padding: 0 !important; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper iframe { position: absolute; inset: 0; }' .
		// pasted-HTML sections: full bleed with zero vertical margins for
		// every visitor — the theme's block-gap must not band between them
		'.gogh-section-html { box-sizing: border-box !important; width: 100vw !important; max-width: 100vw !important; margin-inline: calc(50% - 50vw) !important; margin-block: 0 !important; }' .
		gogh_splash_css() .
		'.gogh-crsl-shell { position: relative; }' .
		// ONE centred control row under the strip: arrows flank clickable
		// dots (James: "align arrows horizontally centered" + "these should
		// be clickable right?"). Ours, everywhere — the Chrome-only pseudo
		// markers are retired.
		'.gogh-crsl-nav { display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 14px; }' .
		'.gogh-crsl-btn { width: 34px; height: 34px; border-radius: 50%; border: 0; display: flex; align-items: center; justify-content: center; font-size: 21px; line-height: 1; cursor: pointer; background: color-mix(in srgb, var(--wp--preset--color--contrast, #16181c) 8%, transparent); color: var(--wp--preset--color--contrast, #16181c); transition: background 0.15s ease, scale 0.15s ease; user-select: none; }' .
		'.gogh-crsl-btn:hover { background: color-mix(in srgb, var(--wp--preset--color--contrast, #16181c) 16%, transparent); scale: 1.08; }' .
		'.gogh-crsl-dots { display: flex; gap: 9px; }' .
		'.gogh-crsl-dot { width: 9px; height: 9px; border-radius: 50%; border: 0; padding: 0; cursor: pointer; background: currentColor; opacity: 0.22; transition: opacity 0.15s ease, scale 0.15s ease; }' .
		'.gogh-crsl-dot.is-here { opacity: 0.9; scale: 1.15; }' .
		// ✦ Splash motion + bleed plumbing (the LOOK is gogh_splash_css above)
		// full bleed means the VIEWPORT, not the content column — themes
		// pad alignfull unevenly, so the splash claims its own edges
		// full bleed rides WP's OWN generated container rules (they emit
		// literal negative margins per padded container, direct children
		// only — which is also why the write room's wrapper must wear
		// .alignfull itself). vw math is banned: vw includes scrollbar
		// width, which shoved everything 30px sideways.
		// on phones any stray overflow inflates the layout viewport, and then
		// 100vw resolves against the inflated width — a self-sustaining 30px
		// shove. Clipping the root pins vw to the device and ends the loop.
		// ---- a one-page site ----
		// A section that carries an id is a DESTINATION: the menu links to it,
		// the page glides there instead of jumping, and the landing stops clear
		// of a sticky header rather than underneath it. Never while EDITING —
		// smooth on the root would animate the canvas's own scrolling.
		'html:not(.gogh-editing):has(.gogh-section[id]) { scroll-behavior: smooth; }' .
		// how far down the landing stops: past the admin bar always, and past
		// a PINNED header when there is one — otherwise the section arrives
		// underneath the very menu that sent you there
		'.gogh-section[id] { scroll-margin-top: calc(var(--wp-admin--admin-bar--height, 0px) + var(--gogh-anchor-offset, 1.5rem)); }' .
		':root:has(header .gogh-sticky) { --gogh-anchor-offset: 8.5rem; }' .
		// motion is a garnish, never a requirement
		'@media (prefers-reduced-motion: reduce) { html:has(.gogh-section[id]) { scroll-behavior: auto; } }' .
		'html:has(.gogh-splash-break, .gogh-splash-glasswrap) { overflow-x: clip; }' .
		// consecutive full-bleed bands touch: the root block gap otherwise
		// leaves a pale slit between painted sections (the white wedge law)
		'.entry-content > .gogh-wrap + .alignfull, .entry-content > .alignfull + .gogh-wrap, .entry-content > .alignfull + .alignfull { margin-block-start: 0; }' .
		'@supports (animation-timeline: view()) { .gogh-splash-break img { scale: 1.16; animation: gogh-bkpx linear both; animation-timeline: view(); } @keyframes gogh-bkpx { from { translate: 0 -5%; } to { translate: 0 5%; } } }' .
		// breakout images (wide/full figures in prose) parallax by default —
		// James: "i kinda love paralax". Gentler than the Break splash: the
		// photo keeps its natural height (no crop), a 1.08 scale buys the
		// headroom the ±3% drift spends, and overflow:clip keeps the frame.
		// The Break splash opts out here — it has its own stronger treatment.
		'@supports (animation-timeline: view()) { ' .
		'.entry-content figure.wp-block-image.alignwide:not(.gogh-splash-break), .entry-content figure.wp-block-image.alignfull:not(.gogh-splash-break) { overflow: clip; } ' .
		'.entry-content figure.wp-block-image.alignwide:not(.gogh-splash-break) img, .entry-content figure.wp-block-image.alignfull:not(.gogh-splash-break) img { scale: 1.08; animation: gogh-wfpx linear both; animation-timeline: view(); } ' .
		'@keyframes gogh-wfpx { from { translate: 0 -3%; } to { translate: 0 3%; } } }' .
		// motion is a garnish, never a requirement
		'@media (prefers-reduced-motion: reduce) { .gogh-splash-break img, .entry-content figure.wp-block-image.alignwide img, .entry-content figure.wp-block-image.alignfull img { animation: none; scale: 1; translate: none; } }' .
		'.gogh-crsl-side { position: absolute; z-index: 2; width: 40px; height: 40px; font-size: 24px; background: color-mix(in srgb, var(--wp--preset--color--base, #fff) 85%, transparent); box-shadow: 0 6px 18px -6px rgba(0,0,0,0.35); backdrop-filter: blur(6px); top: calc(50% - 24px); transform: translateY(-50%); }' .
		'.gogh-crsl-side-l { left: 10px; } .gogh-crsl-side-r { right: 10px; }' .
		// gogh's lightbox: walkable, unlike core's single frame
		'.gogh-lbx { position: fixed; inset: 0; z-index: 100000; display: flex; align-items: center; justify-content: center; background: color-mix(in srgb, #0c0c10 82%, transparent); backdrop-filter: blur(10px); }' .
		'.gogh-lbx img { max-width: min(92vw, 1400px); max-height: 84vh; object-fit: contain; border-radius: 10px; box-shadow: 0 30px 90px -20px rgba(0,0,0,0.7); }' .
		'.gogh-lbx figcaption { position: absolute; left: 0; right: 0; bottom: 26px; text-align: center; color: #fff; opacity: 0.85; font-size: 15px; }' .
		'.gogh-lbx .gogh-crsl-btn { position: absolute; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; font-size: 26px; background: rgba(255,255,255,0.14); color: #fff; }' .
		'.gogh-lbx .gogh-lbx-l { left: 22px; } .gogh-lbx .gogh-lbx-r { right: 22px; }' .
		'.gogh-lbx .gogh-lbx-x { position: absolute; top: 18px; right: 22px; transform: none; font-size: 20px; }' .
		'@media (prefers-reduced-motion: no-preference) { .gogh-lbx { animation: gogh-lbx-in 0.18s ease; } @keyframes gogh-lbx-in { from { opacity: 0; } } }' .
		// the transparent header floats over the first section: absolutely
		// positioned with a soft top scrim so white chrome reads on any hero
		// While a layout is AUDITIONING, the chosen layout lives in a
		// .gogh-chrome-preview box and the old content is merely HIDDEN — but
		// :has ignores display, so the hidden original's overlay class kept
		// the header transparent even while previewing a solid layout, so the
		// audition lied and switching away "did nothing" (the stuck-header
		// report). Rule: while previewing, ONLY the preview box governs;
		// otherwise (and always on the published page) the part's own content.
		// (the header's dressing ships site-wide with gogh-menu — see gogh_chrome_css)
		gogh_widget_css()
	);

	if ( ! current_user_can( 'edit_post', $post->ID ) ) {
		return;
	}

	// write mode owns the room: the canvas editor stays out ("lots of
	// distractions here?" — the ＋Section pill and convert buttons were
	// gate-crashing the clean canvas)
	if ( isset( $_GET['gogh-write'] ) ) {
		return;
	}

	// compose must be REGISTERED here too — a dependency on an
	// unregistered handle silently drops the whole editor script
	wp_register_script( 'gogh-compose', plugins_url( 'gogh-compose.js', __FILE__ ), array(), '0.99.650-chrome', true );
	wp_enqueue_script( 'gogh-editor', plugins_url( 'gogh-editor.js', __FILE__ ), array( 'gogh-compose' ), '0.99.650-chrome', true );
	wp_enqueue_style( 'gogh-editor', plugins_url( 'gogh-editor.css', __FILE__ ), array(), '0.99.650-chrome' );

	// WebMCP bridge: the page registers its editing verbs as agent tools.
	// OPT-IN only — add ?gogh-mcp=1 for a demo session (or enable sitewide
	// via the gogh_webmcp_enabled filter). Keeps future WebMCP-speaking
	// agents from discovering publish-capable tools uninvited.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only opt-in toggle; script is capability-gated above.
	// …and the help bot's show-me bridge rides the same verbs, so the
	// experiments flag loads them too (the bridge itself is origin-checked)
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only labs toggle
	$gogh_exp = isset( $_GET['gogh-test'] ) || ( isset( $_GET['gogh-experiments'] ) && '0' !== $_GET['gogh-experiments'] );
	if ( isset( $_GET['gogh-mcp'] ) || $gogh_exp || apply_filters( 'gogh_webmcp_enabled', false ) ) {
		wp_enqueue_script( 'gogh-webmcp', plugins_url( 'gogh-webmcp.js', __FILE__ ), array( 'gogh-editor' ), '0.99.650-chrome', true );
	}

	// regression suite: /page/?gogh-test (editors only, never saves)
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only toggle enqueuing a test script for capability-checked editors.
	if ( isset( $_GET['gogh-test'] ) ) {
		wp_enqueue_script( 'gogh-tests', plugins_url( 'gogh-tests.js', __FILE__ ), array( 'gogh-editor' ), '0.99.650-chrome', true );
	}
	// the user-test walk: /?gogh-edit=1&gogh-walk=1 on a DISPOSABLE Yellow
	// House (it publishes) — editors only, never shipped in the zip
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only toggle for capability-checked editors.
	if ( isset( $_GET['gogh-walk'] ) ) {
		wp_enqueue_script( 'gogh-walk', plugins_url( 'gogh-walk.js', __FILE__ ), array( 'gogh-editor' ), '0.99.650-chrome', true );
	}

	// products live outside wp/v2, so gogh carries its own save route for
	// them — registered UNDER wp/v2 deliberately: the editor derives the
	// REST root by splitting on 'wp/v2/'
	$rest_base = ( 'page' === $post->post_type ) ? 'pages' : ( 'product' === $post->post_type ? 'gogh-product' : ( 'gogh_panel' === $post->post_type ? 'gogh-panels' : 'posts' ) );
	wp_localize_script( 'gogh-editor', 'GOGH', array(
		'postId'   => $post->ID,
		// the SEO panel's search-preview card needs the page's public face
		'postType'   => $post->post_type,
		// a menu panel's canvas: its own shelf in the picker, and a way back
		'isPanel'    => 'gogh_panel' === $post->post_type,
		'isPanelWoo' => 'gogh_panel' === $post->post_type && function_exists( 'wc_get_products' ),
		'panelFor'   => get_the_title( $post ),
		'homeUrl'    => esc_url_raw( home_url( '/' ) ),
		'postStatus' => $post->post_status,
		'postTitle'  => get_the_title( $post ),
		'permalink'  => esc_url_raw( get_permalink( $post->ID ) ),
		'excerpt'    => (string) $post->post_excerpt,
		'build'    => '0.99.650-chrome',
		// two rooms, one landmark (same contract as the admin bar): on a POST
		// the corner pill opens the WRITING surface, not the freeform canvas
		'writeUrl' => is_singular( 'post' ) ? add_query_arg( 'gogh-write', '1', get_permalink( $post ) ) : null,
		// the first minute: three staged beats on their first section — shown
		// once per user, ever (design note: The First Minute)
		'firstMinute' => (bool) ( current_user_can( 'edit_posts' ) && ! get_user_meta( get_current_user_id(), '_gogh_first_minute', true ) ),
		// the design's named looks and its own sections (gogh_site_design_clean)
		'design'   => gogh_site_design_for_editor(),
		'menuStyle' => gogh_menu_style(),
		'restUrl'  => rest_url( 'wp/v2/' . $rest_base . '/' . $post->ID ),
		'mediaUrl' => rest_url( 'wp/v2/media' ),
		'canUpload' => current_user_can( 'upload_files' ),
		'canExp'   => current_user_can( 'upload_files' ) && current_user_can( 'unfiltered_html' ),
		// explore/html-only: static pieces publish as plain HTML, live parts as blocks
		'htmlOnly' => gogh_html_only(),
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only labs toggle
		// Make freeform ships on by default; &gogh-experiments=0 is the kill-switch,
		// bare &gogh-experiments opts into future experimental features.
		'canConvert' => apply_filters( 'gogh_convert_enabled', ! isset( $_GET['gogh-experiments'] ) || '0' !== $_GET['gogh-experiments'] ),
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only labs toggle
		'experiments' => isset( $_GET['gogh-test'] ) || ( isset( $_GET['gogh-experiments'] ) && '0' !== $_GET['gogh-experiments'] ),
		// the help bot: gogh's editor embeds it in a small sheet; empty URL
		// (via the filter) removes the ? button entirely
		'helpUrl'  => gogh_helper_url(),
		'abEdit'   => array( 'on' => gogh_ab_edit_label( true, 'post' === get_post_type( $post ) ), 'off' => gogh_ab_edit_label( false, 'post' === get_post_type( $post ) ) ),
		'brand'    => get_option( 'gogh_brand', null ) ?: null,
		'activeStyle' => get_option( 'gogh_active_style', '' ),
		'motion'   => get_option( 'gogh_motion', '' ),
		'askAI'    => (bool) ( gogh_ask_key() && gogh_labs_ask() ),
		'labsAsk'  => gogh_labs_ask(),
		'expAI'    => (bool) gogh_ask_key(),
		'canKey'   => current_user_can( 'manage_options' ),
		'typeScale' => (int) get_option( 'gogh_type_scale', 100 ),
		'hasWoo'   => class_exists( 'WooCommerce' ),
		'hasLogo' => (bool) get_theme_mod( 'custom_logo' ), // the header's identity: a logo only when a picture exists
		'adminUrl' => admin_url(),
		// a site definition waiting to be drawn (?gogh-build=1): the editor builds every page, then deletes it
		'siteDef'  => ( isset( $_GET['gogh-build'] ) && gogh_can_build_site() ) ? get_option( 'gogh_site_def', null ) : null,
		// block-gated pieces light up the day the block exists (7.1 brings tabs)
		'hasAccordion' => WP_Block_Type_Registry::get_instance()->is_registered( 'core/accordion' ),
		'hasTabs'  => WP_Block_Type_Registry::get_instance()->is_registered( 'core/tabs' ),
		'starters' => array_values( array_map( function ( $m ) {
			return array(
				'slug'        => $m['slug'],
				'name'        => $m['name'],
				'type'        => isset( $m['type'] ) ? $m['type'] : '', // the kind of site — the picker's first line
				'requires'    => isset( $m['requires'] ) ? $m['requires'] : '',
				'description' => isset( $m['description'] ) ? $m['description'] : '',
				'preview'     => isset( $m['preview'] ) ? $m['preview'] : null,
				'pages'       => array_map( function ( $pg ) {
					return array( 'slug' => isset( $pg['slug'] ) ? $pg['slug'] : ( isset( $pg['woo'] ) ? $pg['woo'] : '' ), 'title' => $pg['title'], 'woo' => isset( $pg['woo'] ) ? $pg['woo'] : '' );
				}, $m['pages'] ),
			);
		}, gogh_starters() ) ),
		'pageTemplate'  => get_page_template_slug( $post ) ?: '',
		'pageTemplates' => (function () use ( $post ) {
			$out = array();
			// includes gogh's registered Blank canvas (as 'blank-canvas') on WP 6.7+
			foreach ( (array) wp_get_theme()->get_page_templates( $post ) as $slug => $title ) {
				$out[] = array( 'slug' => (string) $slug, 'title' => (string) $title );
			}
			return $out;
		})(),
		'modified' => get_post_modified_time( 'Y-m-d\TH:i:s', true, $post ),
		'theme'    => get_stylesheet(),
		'themeName' => wp_get_theme()->get( 'Name' ),
		'gsId'     => ( class_exists( 'WP_Theme_JSON_Resolver' ) && current_user_can( 'edit_theme_options' ) )
			? WP_Theme_JSON_Resolver::get_user_global_styles_post_id() : 0,
		'palette'  => array_values( array_map(
			function ( $c ) { return array( 'slug' => $c['slug'] ); },
			(array) ( wp_get_global_settings( array( 'color', 'palette' ) )['theme'] ?? array() )
		) ),
		'nonce'    => wp_create_nonce( 'wp_rest' ),
	) );
} );

/**
 * Live-preview renderer: the core block-renderer returns bare markup with
 * none of the per-instance layout CSS (nav flex rules, container gaps), so
 * header/footer previews looked broken. This renders markup the way a real
 * page does and returns the generated styles + the block stylesheets the
 * markup needs.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'gogh/v1', '/render', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'callback'            => function ( $req ) {
			$content = (string) $req->get_param( 'content' );
			$html    = do_blocks( $content );
			// BOTH style-engine stores: with the Gutenberg plugin active its
			// namespaced store holds the layout/element rules and core's sits
			// empty — querying only core lost every justify/gap/colour rule
			// ("quite a few header layouts look a little broken")
			$css = '';
			if ( function_exists( 'gutenberg_style_engine_get_stylesheet_from_context' ) ) {
				$css .= (string) gutenberg_style_engine_get_stylesheet_from_context( 'block-supports' );
			}
			if ( function_exists( 'wp_style_engine_get_stylesheet_from_context' ) ) {
				$css .= (string) wp_style_engine_get_stylesheet_from_context( 'block-supports' );
			}
			$hrefs = array();
			$walk  = function ( $blocks ) use ( &$walk, &$hrefs ) {
				foreach ( $blocks as $b ) {
					if ( ! empty( $b['blockName'] ) ) {
						$bt = WP_Block_Type_Registry::get_instance()->get_registered( $b['blockName'] );
						if ( $bt ) {
							foreach ( (array) $bt->style_handles as $h ) {
								if ( $h && wp_style_is( $h, 'registered' ) ) {
									$obj = wp_styles()->registered[ $h ];
									if ( ! empty( $obj->src ) ) {
										$src = ( 0 === strpos( $obj->src, 'http' ) ) ? $obj->src : site_url( $obj->src );
										$hrefs[ $h ] = add_query_arg( 'ver', $obj->ver ? $obj->ver : get_bloginfo( 'version' ), $src );
									}
								}
							}
						}
					}
					if ( ! empty( $b['innerBlocks'] ) ) {
						$walk( $b['innerBlocks'] );
					}
				}
			};
			$walk( parse_blocks( $content ) );
			return array(
				'html'   => $html,
				'css'    => $css,
				'styles' => array_values( $hrefs ),
			);
		},
	) );
} );

/**
 * Editor contexts (post editor, site editor, pattern previews): a gogh
 * section's grid uses cqw units against the .gogh-wrap container. In
 * shrink-to-fit preview wrappers, inline-size containment collapses the wrap
 * to width 0 — every saved section needs the same width floor there.
 */
/**
 * The block editor's canvas rules for gogh sections — one source for the
 * plugin and for the keep-the-blocks helper it leaves behind on deactivation.
 */
function gogh_editor_canvas_css() {
	return
		'.gogh-wrap { min-width: 100%; margin-block: 0 !important; }' .
		'.gogh-section > .wp-block-group { padding: 0 !important; box-sizing: border-box; }' .
		'.gogh-section > * { box-sizing: border-box; }' .
		// video backgrounds: the loop sits under everything; its poster (the
		// section image) shows until it plays, and whenever motion is off
		'.gogh-section > .gogh-bgvideo { position: absolute; inset: 0; z-index: -1; margin: 0 !important; padding: 0 !important; pointer-events: none; overflow: hidden; }' .
		'.gogh-section > .gogh-bgvideo video { width: 100%; height: 100%; object-fit: cover; display: block; }' .
		'.gogh-bgvideo-btn { position: absolute; right: 14px; bottom: 14px; z-index: 60; width: 36px; height: 36px; border-radius: 50%; border: 0; padding: 0; cursor: pointer; background: rgba(15,23,42,0.55); color: #fff; display: grid; place-items: center; opacity: 0.72; transition: opacity 0.2s; }' .
		'.gogh-bgvideo-btn:hover, .gogh-bgvideo-btn:focus-visible { opacity: 1; }' .
		'.gogh-bgvideo-btn svg { width: 14px; height: 14px; display: block; }' .
		'@media (prefers-reduced-motion: reduce) { .gogh-section > .gogh-bgvideo, .gogh-bgvideo-btn { display: none; } }' .
		// the video element: the frame is the design's, the player fills it
		'.gogh-section > .gogh-vid { overflow: hidden; overflow: clip; }' .
		'.gogh-section > .gogh-vid video, .gogh-section > .gogh-vid iframe { width: 100%; height: 100%; object-fit: cover; display: block; border: 0; border-radius: inherit; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper { position: relative; height: 100%; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper::before { content: none !important; padding: 0 !important; }' .
		'.gogh-section > .gogh-vid .wp-block-embed__wrapper iframe { position: absolute; inset: 0; }' .
		// splashes are core blocks wearing gogh classes — without their
		// presentation the editor shows a wall as a stack and a carousel as
		// a pile ("kinda breaking in the gutenberg view"). Same CSS, both rooms.
		gogh_splash_css() .
		// the editor prefixes theme rules with .editor-styles-wrapper, which
		// out-specifies the shared height rule (its height:auto won, so the
		// break showed the photo's full natural height) — re-state the window
		// at editor specificity
		'.editor-styles-wrapper figure.wp-block-image.gogh-splash-break img { height: min(66vh, 640px); }' .
		// buttons: on the canvas they FILL their grid cell (width/height 100%
		// from the section CSS) — in Gutenberg, where container units can
		// resolve oddly (Playground especially), that fill balloons a button
		// into a wrapping blob. Natural pill size in the editor is faithful
		// AND unbreakable.
		'.editor-styles-wrapper .gogh-section .wp-block-button, .editor-styles-wrapper .gogh-section .wp-block-button__link { width: auto !important; height: auto !important; min-height: 0 !important; white-space: nowrap; }';
}
add_action( 'enqueue_block_assets', function () {
	if ( ! is_admin() ) {
		return;
	}
	wp_register_style( 'gogh-editor-base', false, array(), GOGH_VERSION . '-chrome' );
	wp_enqueue_style( 'gogh-editor-base' );
	wp_add_inline_style( 'gogh-editor-base', gogh_editor_canvas_css() );
} );

/**
 * Admin-bar entry point: "Edit with gogh" on any front-end page the user can
 * edit. On a page with no gogh content yet, the editor bootstraps a section.
 */
/**
 * The admin bar's edit label, in one place: PHP renders it on load and the
 * editor flips it live when the mode changes without a reload. One source,
 * so the label never changes under the person's eyes while the page boots
 * (James saw a 'Done' flash before 'Exit gogh editor' took over).
 */
function gogh_ab_edit_label( $editing, $is_post ) {
	$pen = '<svg class="gogh-ab-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
	$pal = '<svg class="gogh-ab-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r="2.1"/><circle cx="18.5" cy="12" r="2.1"/><circle cx="8.5" cy="7.5" r="2.1"/><circle cx="6" cy="13" r="2.1"/><path d="M12 22a10 10 0 1 1 10-10c0 2.2-1.8 3-3.5 3H16a2.5 2.5 0 0 0-2 4c.5.7 0 3-2 3z"/></svg>';
	if ( $editing ) {
		// 'View site', not 'Exit gogh editor': the old words described leaving
		// and sounded like quitting an app; these describe where you arrive,
		// and they are the words WordPress already uses (James, 2026-09-19).
		// The unsaved-changes dialog stays: this is the live site, not a
		// preview of unpublished work.
		$eye = '<svg class="gogh-ab-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
		return $eye . esc_html__( 'View site', 'gogh-editor' );
	}
	// one word, as a solid button (James, 2026-09-21: 'i like the simplicity
	// of edit / view site'): the bar's left holds the way in and the way out,
	// in the same spot, the way Squarespace does it. The palette icon went
	// with the words: a solid Edit needs no badge to say what it is.
	return $is_post ? $pen . esc_html__( 'Edit post', 'gogh-editor' ) : esc_html__( 'Edit', 'gogh-editor' );
}
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( is_admin() || ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( ! $post || ! current_user_can( 'edit_post', $post->ID ) ) {
		return;
	}
	// two rooms, one landmark: pages open the CANVAS, posts open the
	// WRITING surface — the bar knows which room you are in
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only mode check
	$editing = isset( $_GET['gogh-edit'] ) || isset( $_GET['gogh-write'] );
	$is_post = 'post' === get_post_type( $post );
	$bar->add_node( array(
		'id'    => 'gogh-edit',
		'title' => gogh_ab_edit_label( $editing, $is_post ),
		'meta'  => $editing ? array() : array( 'class' => 'gogh-ab-solid', 'title' => __( 'Edit this page with gogh', 'gogh-editor' ) ),
		'href'  => $editing
			? ( 'gogh_panel' === get_post_type( $post ) ? home_url( '/' ) : get_permalink( $post ) ) // a panel's only door is back to the site
			: add_query_arg( $is_post ? 'gogh-write' : 'gogh-edit', '1', get_permalink( $post ) ),
	) );
}, 90 );

// a little ? in the admin bar, just left of Howdy, on every screen: in the
// editor it opens the help sheet (gogh-editor.js takes the click); anywhere
// else it opens the helper in a new tab (James: 'a little help icon which
// launches our help in the admin toolbar, just to the left of howdy')
add_action( 'admin_bar_menu', function ( $bar ) {
	$url = gogh_helper_url();
	if ( ! $url || ! is_user_logged_in() ) {
		return;
	}
	$q = '<svg class="gogh-ab-ic" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M9.3 9.5a2.8 2.8 0 1 1 3.9 2.6c-.8.4-1.2 1-1.2 1.9"/><path d="M12 17h.01"/></svg>';
	$bar->add_node( array(
		'parent' => 'top-secondary',
		'id'     => 'gogh-help',
		'title'  => $q . '<span class="screen-reader-text">' . esc_html__( 'gogh help', 'gogh-editor' ) . '</span>',
		'href'   => esc_url( $url ),
		'meta'   => array( 'title' => __( 'gogh help', 'gogh-editor' ), 'target' => '_blank', 'rel' => 'noopener' ),
	) );
}, 100 );

/**
 * v1 posture: the front-end admin bar shows ONE way to edit — gogh. The
 * native entry points (Site Editor, Edit Page, +New, comments) return with
 * the experiments flag for the curious.
 */
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( is_admin() ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only mode check
	if ( isset( $_GET['gogh-experiments'] ) || isset( $_GET['gogh-test'] ) ) {
		return;
	}
	// the front-end bar is a CREATION surface, not a dashboard: the WP
	// logo menu, update counters and search live in wp-admin where they
	// belong ("how can we make this nicer / simpler for folks")
	foreach ( array( 'site-editor', 'edit-site', 'customize', 'comments', 'new-content', 'edit', 'wp-logo', 'updates', 'search' ) as $id ) {
		$bar->remove_node( $id );
	}
	// products: a tiny layout menu — pick one of a few fixed layouts,
	// never edit a template
	if ( is_singular( 'product' ) && function_exists( 'gogh_product_layouts' ) ) {
		$pid = get_queried_object_id();
		if ( $pid && current_user_can( 'edit_post', $pid ) ) {
			$current = get_page_template_slug( $pid );
			$layouts = gogh_product_layouts();
			if ( ! isset( $layouts[ $current ] ) ) {
				$current = '';
			}
			$bar->add_node( array(
				'id'    => 'gogh-product-layout',
				'title' => '🎨 Product layout',
			) );
			foreach ( $layouts as $slug => $label ) {
				$bar->add_node( array(
					'id'     => 'gogh-product-layout-' . ( $slug ? $slug : 'classic' ),
					'parent' => 'gogh-product-layout',
					'title'  => ( $slug === $current ? '✓ ' : '' ) . $label,
					'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_product_layout&id=' . $pid . '&layout=' . rawurlencode( $slug ) ), 'gogh_product_layout_' . $pid ),
				) );
			}
			// one more click stamps the catalogue — individual products can
			// still be changed afterwards, one at a time
			$current_label = preg_replace( '/\s+—.*$/u', '', $layouts[ $current ] );
			// the layouts are one kind of thing; what follows is another — a
			// secondary group sets them apart (James: 'any elegant way of
			// differentiating the show option here? its kinda a different thing')
			$bar->add_group( array(
				'id'     => 'gogh-product-layout-extras',
				'parent' => 'gogh-product-layout',
				'meta'   => array( 'class' => 'ab-sub-secondary' ),
			) );
			$bar->add_node( array(
				'id'     => 'gogh-product-layout-all',
				'parent' => 'gogh-product-layout-extras',
				'title'  => sprintf( __( 'Apply “%s” to all products', 'gogh-editor' ), $current_label ),
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_product_layout_all&id=' . $pid ), 'gogh_product_layout_all' ),
			) );
			$related_on = '0' !== (string) get_option( 'gogh_product_related', '1' );
			$bar->add_node( array(
				'id'     => 'gogh-product-related',
				'parent' => 'gogh-product-layout-extras',
				// a verb, not a tick: it says what the click will do
				'title'  => $related_on ? __( 'Hide “You might also like”', 'gogh-editor' ) : __( 'Show “You might also like”', 'gogh-editor' ),
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_product_related&back=' . rawurlencode( get_permalink( $pid ) ) ), 'gogh_product_related' ),
			) );
		}
	}
	// posts: the same tiny menu for the reading looks (James: 'i really
	// like the way you have product layout in the admin toolbar - we should
	// do that for our blog layout options')
	if ( is_singular( 'post' ) ) {
		$post_id = get_queried_object_id();
		if ( $post_id && current_user_can( 'edit_post', $post_id ) ) {
			$looks   = gogh_post_layouts();
			$cur_look = (string) get_post_meta( $post_id, '_gogh_post_style', true );
			if ( ! isset( $looks[ $cur_look ] ) ) {
				$cur_look = '';
			}
			$bar->add_node( array(
				'id'    => 'gogh-post-layout',
				'title' => '🎨 Post layout',
			) );
			foreach ( $looks as $slug => $label ) {
				$bar->add_node( array(
					'id'     => 'gogh-post-layout-' . ( $slug ? $slug : 'theme' ),
					'parent' => 'gogh-post-layout',
					'title'  => ( $slug === $cur_look ? '✓ ' : '' ) . $label,
					'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_post_layout&id=' . $post_id . '&layout=' . rawurlencode( $slug ) ), 'gogh_post_layout_' . $post_id ),
				) );
			}
			$cur_label = preg_replace( '/\s+—.*$/u', '', $looks[ $cur_look ] );
			$bar->add_group( array(
				'id'     => 'gogh-post-layout-extras',
				'parent' => 'gogh-post-layout',
				'meta'   => array( 'class' => 'ab-sub-secondary' ),
			) );
			$bar->add_node( array(
				'id'     => 'gogh-post-layout-all',
				'parent' => 'gogh-post-layout-extras',
				'title'  => sprintf( __( 'Apply “%s” to all posts', 'gogh-editor' ), $cur_label ),
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_post_layout_all&id=' . $post_id ), 'gogh_post_layout_all' ),
			) );
		}
	}
	// the blog page: the Blog style as the same tiny menu (the floating pill
	// keeps its hover auditions; the bar is the door people already know)
	if ( ( is_home() || is_category() || is_tag() || is_author() ) && current_user_can( 'edit_theme_options' ) ) {
		$blog_cur   = get_option( 'gogh_blog_style', '' );
		$blog_looks = array(
			''       => __( 'Default — the theme\'s own list', 'gogh-editor' ),
			'list'   => __( 'List — tidied flow, hairlines, dates right', 'gogh-editor' ),
			'cards'  => __( 'Cards — image-led grid', 'gogh-editor' ),
			'cover'  => __( 'Cover — newest post huge, the rest in a grid', 'gogh-editor' ),
			'ledger' => __( 'Ledger — dense editorial index', 'gogh-editor' ),
		);
		if ( ! isset( $blog_looks[ $blog_cur ] ) ) {
			$blog_cur = '';
		}
		$bar->add_node( array(
			'id'    => 'gogh-blog-layout',
			'title' => '🎨 Blog layout',
		) );
		foreach ( $blog_looks as $slug => $label ) {
			$bar->add_node( array(
				'id'     => 'gogh-blog-layout-' . ( $slug ? $slug : 'theme' ),
				'parent' => 'gogh-blog-layout',
				'title'  => ( $slug === $blog_cur ? '✓ ' : '' ) . $label,
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_blog_layout&layout=' . rawurlencode( $slug ) . '&back=' . rawurlencode( home_url( add_query_arg( array() ) ) ) ), 'gogh_blog_layout' ),
			) );
		}
	}
	// the shop page and category pages: their looks, from the same door
	$shop_kind = function_exists( 'gogh_shop_look_kind' ) ? gogh_shop_look_kind() : '';
	if ( $shop_kind && current_user_can( 'edit_theme_options' ) ) {
		$shop_cur   = gogh_shop_look_active( $shop_kind );
		$shop_looks = gogh_shop_looks();
		$shop_id    = 'gogh-' . $shop_kind . '-layout';
		$bar->add_node( array(
			'id'    => $shop_id,
			'title' => 'shop' === $shop_kind ? '🎨 Shop layout' : '🎨 Category layout',
		) );
		$shop_term = 'category' === $shop_kind ? (int) get_queried_object_id() : 0;
		$shop_back = rawurlencode( home_url( add_query_arg( array() ) ) );
		foreach ( $shop_looks as $slug => $label ) {
			$bar->add_node( array(
				'id'     => $shop_id . '-' . ( $slug ? $slug : 'classic' ),
				'parent' => $shop_id,
				'title'  => ( $slug === $shop_cur ? '✓ ' : '' ) . $label,
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_shop_layout&kind=' . $shop_kind . '&layout=' . rawurlencode( $slug ) . ( $shop_term ? '&term=' . $shop_term : '' ) . '&back=' . $shop_back ), 'gogh_shop_layout' ),
			) );
		}
		if ( $shop_term ) {
			// this category chose above; one more click stamps every category
			$shop_cur_label = preg_replace( '/\s+—.*$/u', '', $shop_looks[ $shop_cur ] );
			$bar->add_group( array(
				'id'     => $shop_id . '-extras',
				'parent' => $shop_id,
				'meta'   => array( 'class' => 'ab-sub-secondary' ),
			) );
			$bar->add_node( array(
				'id'     => $shop_id . '-all',
				'parent' => $shop_id . '-extras',
				'title'  => sprintf( __( 'Apply “%s” to all categories', 'gogh-editor' ), $shop_cur_label ),
				'href'   => wp_nonce_url( admin_url( 'admin-post.php?action=gogh_shop_layout&kind=category&all=1&layout=' . rawurlencode( $shop_cur ) . '&back=' . $shop_back ), 'gogh_shop_layout' ),
			) );
		}
	}
	// one thing beginners DO need from the old menu: a new page — and it
	// goes straight into gogh
	// which room is this? posts and the blog index are the WRITING room;
	// everything else is the design studio — the bar only offers the verbs
	// that belong to the room ("this is really the site designer")
	$has_blog     = 'posts' === get_option( 'show_on_front' ) || (int) get_option( 'page_for_posts' ) > 0;
	$plus         = '<svg class="gogh-ab-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>';
	$pen2         = '<svg class="gogh-ab-ic" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
	$new_page = array(
		'id'    => 'gogh-new-page',
		'title' => $plus . 'New page',
		// the front door: blank draft, canvas, first minute — the nameplate
		// and the publish gate own naming now (the old name-first modal and
		// its instantly-published empty page retired with them)
		'href'  => admin_url( 'post-new.php?post_type=page' ),
	);
	$new_post = array(
		'id'    => 'gogh-write',
		'title' => $pen2 . 'New post',
		'href'  => add_query_arg( 'gogh-new-post', '1', home_url( '/' ) ),
		'meta'  => array( 'title' => 'A clean canvas and space to think' ),
	);
	// one door per room: on a SINGLE post the door is Edit post — New post
	// rides top-level only on the blog index, where there is nothing to
	// edit ("we need to remove new post from here"); it stays under the
	// site-name menu everywhere as the safety net
	if ( is_home() && $has_blog && current_user_can( 'edit_posts' ) ) {
		$bar->add_node( $new_post );
	}
	// New page rides only in the site menu now ("maybe lets remove this") —
	// the bar on a page keeps a single door: Edit
	// the safety net: both creations live quietly under the site name, so
	// nothing is ever unreachable from the wrong room
	if ( current_user_can( 'publish_pages' ) ) {
		$bar->add_node( array_merge( $new_page, array( 'id' => 'gogh-new-page-menu', 'parent' => 'site-name' ) ) );
	}
	if ( $has_blog && current_user_can( 'edit_posts' ) ) {
		$bar->add_node( array_merge( $new_post, array( 'id' => 'gogh-write-menu', 'parent' => 'site-name' ) ) );
	}
	// wp-admin plumbing leaves the site menu — Dashboard stays as the
	// escape hatch; Plugins and Themes are not site-making
	foreach ( array( 'plugins', 'themes', 'widgets', 'menus', 'appearance' ) as $noise ) {
		$bar->remove_node( $noise );
	}
	// the edit/exit landmark closes the cluster: re-adding sends it last
	$edit_node = $bar->get_node( 'gogh-edit' );
	if ( $edit_node ) {
		$bar->remove_node( 'gogh-edit' );
		$bar->add_node( (array) $edit_node );
	}
}, 999 );

/**
 * EXPERIMENT (&gogh-experiments): "+ New → Page" from the front-end admin
 * bar creates the page and lands straight in gogh, not the block editor.
 */
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( is_admin() ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only mode check
	if ( ! ( isset( $_GET['gogh-experiments'] ) || isset( $_GET['gogh-test'] ) ) ) {
		return;
	}
	$node = $bar->get_node( 'new-page' );
	if ( $node ) {
		$node->href = admin_url( 'post-new.php?post_type=page' );
		$bar->add_node( (array) $node );
	}
}, 1000 );
/**
 * No page title by default — for EVERY new page, however it's created
 * (gogh's New page, wp-admin, REST). A freeform canvas carries its own
 * title typography; the theme's auto title above it just duplicates
 * ('should no page title be the default with gogh?'). Page style brings
 * it back per page; pages that already chose a template are untouched.
 */
add_action( 'wp_insert_post', function ( $post_id, $post, $update ) {
	if ( $update || 'page' !== $post->post_type ) {
		return;
	}
	if ( ! get_page_template_slug( $post_id ) ) {
		update_post_meta( $post_id, '_wp_page_template', 'page-no-title' );
	}
}, 10, 3 );

/**
 * The editor-only rules a gogh section needs inside the block editor —
 * the inner-blocks wrapper flattened into the grid, full canvas width, no
 * appenders in decorative groups. One source for the plugin and for the
 * keep-the-blocks helper it leaves behind on deactivation.
 */
function gogh_editor_flatten_css() {
	// Editor-only adjustments:
	// 1. The group block's inner-blocks wrappers would break the grid —
	//    promote grandchildren into the grid with display:contents.
	// 2. Hide the leading Custom HTML block that carries the style + model.
	return "\n"
		. '.gogh-section > .block-editor-inner-blocks,'
		. '.gogh-section > div:not([class]),'
		// empty groups (gogh boxes/shapes) get an extra CLASS-LESS wrapper from
		// the editor — promote it too, or the anonymous div becomes the grid
		// item: auto-placed, zero-height, shape invisible
		. '.gogh-section .block-editor-block-list__layout > div:not([class]),'
		. '.gogh-section .block-editor-inner-blocks > .block-editor-block-list__layout { display: contents; }' . "\n"
		. '.is-root-container > [data-type="core/html"]:first-child { display: none; }' . "\n"
		// gogh/section blocks span the full editor canvas, like the front end
		. '.editor-styles-wrapper [data-type="gogh/section"],'
		. '.editor-styles-wrapper .wp-block:has(> .wp-block-gogh-section) {'
		. ' max-width: none !important; width: auto;'
		// kill the editor's block-gap margins so sections sit flush, like the front end
		. ' margin-block: 0 !important;'
		. ' margin-left: calc(-1 * var(--wp--style--root--padding-left, 0px)) !important;'
		. ' margin-right: calc(-1 * var(--wp--style--root--padding-right, 0px)) !important; }' . "\n"
		. '.gogh-wrap { margin-block: 0 !important; }' . "\n"
		// empty image/decoration groups: suppress Gutenberg's layout variation
		// picker and appender so the div renders with its gogh background
		. '.gogh-section .block-editor-block-variation-picker,'
		. '.gogh-section .wp-block-group__placeholder > .components-placeholder,'
		. '.gogh-section .block-list-appender { display: none !important; }';
}
/**
 * Backend parity: inject the page's own generated gogh CSS into the block
 * editor iframe so the editor canvas renders the section like the front end.
 */
add_filter( 'block_editor_settings_all', function ( $settings, $context ) {
	$post = isset( $context->post ) ? $context->post : null;
	if ( ! $post || false === strpos( $post->post_content, 'gogh-section' ) ) {
		return $settings;
	}
	if ( ! preg_match_all( '/<style class="gogh-style">(.*?)<\/style>/s', $post->post_content, $m ) ) {
		return $settings;
	}

	$css = implode( "\n", $m[1] );

	$css .= gogh_editor_flatten_css();
	$settings['styles'][] = array( 'css' => $css );
	return $settings;
}, 10, 2 );
